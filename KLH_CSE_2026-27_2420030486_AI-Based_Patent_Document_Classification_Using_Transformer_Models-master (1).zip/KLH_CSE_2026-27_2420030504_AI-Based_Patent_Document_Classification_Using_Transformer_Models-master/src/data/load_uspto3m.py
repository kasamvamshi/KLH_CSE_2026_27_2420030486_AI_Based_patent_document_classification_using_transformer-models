"""Loader for the USPTO-3M dataset."""
from __future__ import annotations

import logging
from typing import Any, Iterator

from datasets import load_dataset, Dataset, IterableDataset

logger = logging.getLogger(__name__)


def load_uspto3m_stream(
    dataset_name: str = "AI-Growth-Lab/Patent_Classification_USPTO_3M",
    split: str = "train",
) -> IterableDataset:
    """Load USPTO-3M in streaming mode for inspection without heavy download.
    
    Args:
        dataset_name: Hugging Face dataset name.
        split: Dataset split to load.
        
    Returns:
        IterableDataset.
    """
    logger.info(f"Loading {dataset_name} ({split}) in streaming mode")
    try:
        # Some datasets don't have a 'train' split by default if it's not structured.
        # This will attempt to load the streaming version.
        ds = load_dataset(dataset_name, split=split, streaming=True, trust_remote_code=True)
        return ds
    except Exception as e:
        logger.error(f"Failed to load {dataset_name}: {e}")
        raise


def get_uspto3m_schema(
    dataset_name: str = "AI-Growth-Lab/Patent_Classification_USPTO_3M"
) -> dict[str, Any]:
    """Get dataset features/schema without downloading."""
    try:
        from datasets import get_dataset_config_info
        info = get_dataset_config_info(dataset_name, trust_remote_code=True)
        return {
            "description": info.description,
            "features": info.features,
            "splits": list(info.splits.keys()) if info.splits else [],
        }
    except Exception as e:
        logger.error(f"Could not fetch schema for {dataset_name}: {e}")
        return {"error": str(e)}
