import os
import json
import logging
from typing import Tuple
from pathlib import Path
from datasets import load_dataset, Dataset, DatasetDict

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Ensure paths
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

def clean_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    # Simple cleaning (a more robust text cleaner might exist in src/preprocessing)
    text = text.replace("<SOH>", "").replace("<EOH>", "")
    text = " ".join(text.split())
    return text

def parse_labels(label_str) -> list:
    if not isinstance(label_str, str):
        return []
    # If multiple labels are comma separated or similar
    labels = [l.strip() for l in label_str.split(',') if l.strip()]
    return labels

def validate_and_preprocess(batch):
    # Normalize columns and clean text
    processed = {
        "id": [],
        "title": [],
        "abstract": [],
        "claims": [],
        "description": [],
        "cpc_label": [],
        "valid": []
    }
    
    for i in range(len(batch['patent_number'])):
        pid = str(batch['patent_number'][i])
        title = clean_text(batch.get('title', [''])[i])
        abstract = clean_text(batch.get('abstract', [''])[i])
        claims = clean_text(batch.get('claims', [''])[i])
        desc = clean_text(batch.get('description', [''])[i])
        label_raw = batch.get('cpc_label', [''])[i]
        
        labels = parse_labels(label_raw)
        
        # Validation checks
        is_valid = True
        if not title and not abstract and not claims and not desc:
            is_valid = False
        if not labels:
            is_valid = False
            
        processed["id"].append(pid)
        processed["title"].append(title)
        processed["abstract"].append(abstract)
        processed["claims"].append(claims)
        processed["description"].append(desc)
        processed["cpc_label"].append(labels)
        processed["valid"].append(is_valid)
        
    return processed

def load_real_dataset() -> Tuple[Dataset, Dataset, Dataset]:
    """Loads, validates, cleans and returns the HUPD dataset."""
    
    # Check if processed exists
    processed_path = PROCESSED_DIR / "hupd_sample"
    if processed_path.exists():
        logger.info(f"Loading processed dataset from {processed_path}")
        ds = DatasetDict.load_from_disk(str(processed_path))
        return ds["train"], ds["validation"], ds.get("test", ds["validation"])

    logger.info("Downloading/Loading raw HUPD dataset (sample)...")
    # Using HUPD sample to keep processing time reasonable, but real data nonetheless
    raw_ds = load_dataset('HUPD/hupd', name='sample', trust_remote_code=True, uniform_split=True)
    
    # Preprocess
    logger.info("Validating and preprocessing dataset...")
    # We will map over the train and validation splits
    
    processed_ds_dict = {}
    
    for split_name in raw_ds.keys():
        split_ds = raw_ds[split_name]
        logger.info(f"Processing split: {split_name} ({len(split_ds)} records)")
        
        # Apply transformation
        mapped_ds = split_ds.map(
            validate_and_preprocess,
            batched=True,
            batch_size=1000,
            remove_columns=split_ds.column_names,
            desc=f"Cleaning {split_name}"
        )
        
        # Filter valid records
        valid_ds = mapped_ds.filter(lambda x: x["valid"])
        valid_ds = valid_ds.remove_columns(["valid"])
        
        # Remove duplicates based on ID
        # Since huggingface datasets don't have a direct drop_duplicates by column easily, we use pandas
        df = valid_ds.to_pandas()
        initial_len = len(df)
        df = df.drop_duplicates(subset=["id"])
        dropped = initial_len - len(df)
        if dropped > 0:
            logger.info(f"Dropped {dropped} duplicate records from {split_name}.")
            
        final_split_ds = Dataset.from_pandas(df, preserve_index=False)
        processed_ds_dict[split_name] = final_split_ds
        
    final_ds_dict = DatasetDict(processed_ds_dict)
    
    logger.info(f"Saving processed dataset to {processed_path}")
    final_ds_dict.save_to_disk(str(processed_path))
    
    # Print audit
    logger.info("=== Dataset Audit Report ===")
    for split, ds in final_ds_dict.items():
        logger.info(f"Split: {split}")
        logger.info(f" - Records: {len(ds)}")
        logger.info(f" - Columns: {ds.column_names}")
        
        # Calc some stats
        all_labels = [lbl for labels in ds['cpc_label'] for lbl in labels]
        unique_labels = set(all_labels)
        logger.info(f" - Unique CPC labels: {len(unique_labels)}")
        
        if len(ds) > 0:
            avg_title_len = sum(len(x.split()) for x in ds['title']) / len(ds)
            logger.info(f" - Avg Title length (words): {avg_title_len:.1f}")
            avg_abs_len = sum(len(x.split()) for x in ds['abstract']) / len(ds)
            logger.info(f" - Avg Abstract length (words): {avg_abs_len:.1f}")
    
    test_ds = final_ds_dict.get("test")
    if not test_ds:
        # If no test split is provided, we can split validation later or just return val twice for now
        test_ds = final_ds_dict.get("validation", final_ds_dict["train"])
        
    return final_ds_dict["train"], final_ds_dict["validation"], test_ds

if __name__ == "__main__":
    load_real_dataset()
