import re
import json
import logging
from pathlib import Path
from datasets import DatasetDict
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
INPUT_DIR = PROJECT_ROOT / "data" / "processed" / "hupd_sample"
OUTPUT_DIR = PROJECT_ROOT / "data" / "processed" / "hupd_preprocessed"

def advanced_clean_text(text: str) -> str:
    """Removes HTML/XML, normalizes whitespace, cleans special characters."""
    if not text or not isinstance(text, str):
        return ""
    # Remove HTML/XML tags
    text = re.sub(r'<[^>]+>', ' ', text)
    # Remove special control characters but keep patent terminology (like chemical formulas)
    text = re.sub(r'[\n\t\r]', ' ', text)
    # Normalize whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def preprocess_record(record):
    """Formats a record according to the strict requested schema."""
    title = advanced_clean_text(record.get('title', ''))
    abstract = advanced_clean_text(record.get('abstract', ''))
    claims = advanced_clean_text(record.get('claims', ''))
    desc = advanced_clean_text(record.get('description', ''))
    
    # Empty section handling
    title = title if title else "NO_TITLE"
    abstract = abstract if abstract else "NO_ABSTRACT"
    claims = claims if claims else "NO_CLAIMS"
    desc = desc if desc else "NO_DESCRIPTION"
    
    # Section ordering
    full_text = f"{title}. {abstract} {claims} {desc}".strip()
    
    return {
        "patent_id": record.get("id", "UNKNOWN"),
        "title": title,
        "abstract": abstract,
        "claims": claims,
        "description": desc,
        "full_text": full_text,
        "cpc_labels": record.get("cpc_label", []),
        "full_text_len": len(full_text.split())
    }

def run_preprocessing():
    if not INPUT_DIR.exists():
        logger.error(f"Input directory not found: {INPUT_DIR}. Run load_dataset.py first.")
        return
        
    logger.info(f"Loading dataset from {INPUT_DIR}")
    ds_dict = DatasetDict.load_from_disk(str(INPUT_DIR))
    
    preprocessed_dict = {}
    stats_report = {}
    
    for split in ds_dict.keys():
        logger.info(f"Preprocessing split: {split}")
        # Apply formatting
        processed_ds = ds_dict[split].map(
            preprocess_record, 
            remove_columns=ds_dict[split].column_names,
            desc=f"Preprocessing {split}"
        )
        preprocessed_dict[split] = processed_ds
        
        # Calculate statistics
        lengths = processed_ds["full_text_len"]
        stats_report[split] = {
            "num_records": len(processed_ds),
            "avg_text_length": sum(lengths) / len(lengths) if lengths else 0,
            "min_text_length": min(lengths) if lengths else 0,
            "max_text_length": max(lengths) if lengths else 0
        }
        
    final_ds = DatasetDict(preprocessed_dict)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # Save the transformed dataset
    # We will remove the 'full_text_len' helper column before final save to match schema exactly
    def remove_len(x):
        return {k: v for k, v in x.items() if k != "full_text_len"}
    
    for split in final_ds.keys():
        final_ds[split] = final_ds[split].remove_columns(["full_text_len"])
        
    final_ds.save_to_disk(str(OUTPUT_DIR))
    logger.info(f"Preprocessed dataset saved to {OUTPUT_DIR}")
    
    # Print Validation Report
    logger.info("=== PREPROCESSING VALIDATION REPORT ===")
    for split, stats in stats_report.items():
        logger.info(f"Split: {split}")
        logger.info(f" - Total Records: {stats['num_records']}")
        logger.info(f" - Min Words: {stats['min_text_length']}")
        logger.info(f" - Max Words: {stats['max_text_length']}")
        logger.info(f" - Avg Words: {stats['avg_text_length']:.1f}")
        
    # Verify Schema
    sample = final_ds["train"][0]
    logger.info(f"Sample Schema keys: {list(sample.keys())}")
    
if __name__ == "__main__":
    run_preprocessing()
