"""Unified PyTorch Dataset for PatentClass-HAT."""
import logging
from typing import Dict, Any, Optional

import torch
from torch.utils.data import IterableDataset as TorchIterableDataset
from datasets import IterableDataset as HFIterableDataset

from src.preprocessing import clean_patent_text, extract_sections, CPCLabelEncoder, Chunker

logger = logging.getLogger(__name__)

class PatentDataset(TorchIterableDataset):
    """Unified dataset wrapper mapping diverse datasets to the standard schema."""
    
    def __init__(
        self,
        hf_dataset: HFIterableDataset,
        dataset_name: str,
        label_encoder: CPCLabelEncoder,
        chunker: Optional[Chunker] = None,
        max_text_length: int = 100000,
    ):
        """
        Args:
            hf_dataset: The Hugging Face IterableDataset stream.
            dataset_name: Source dataset name ("uspto3m", "hupd", "bigpatent").
            label_encoder: Fitted CPCLabelEncoder.
            chunker: Optional Chunker instance for splitting text.
            max_text_length: Truncation length for safety.
        """
        self.hf_dataset = hf_dataset
        self.dataset_name = dataset_name.lower()
        self.label_encoder = label_encoder
        self.chunker = chunker
        self.max_text_length = max_text_length
        
    def __iter__(self):
        worker_info = torch.utils.data.get_worker_info()
        # Handle multiprocessing in dataloader (shard the dataset if needed, 
        # though HF IterableDataset handles some of this natively if configured)
        # For simplicity, we just iterate. If num_workers > 0, HF requires 
        # specific sharding logic which we omit for this basic implementation.
        
        for raw_row in self.hf_dataset:
            processed = self._process_row(raw_row)
            if processed is not None:
                yield processed
                
    def _process_row(self, row: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Map a raw row to the unified schema."""
        try:
            # 1. Map fields based on dataset source
            if "uspto3m" in self.dataset_name:
                doc_id = str(row.get("id", ""))
                raw_text = clean_patent_text(row.get("text", ""), max_length=self.max_text_length)
                sections = extract_sections(raw_text)
                raw_labels = row.get("cpc_ids", "")
                
            elif "hupd" in self.dataset_name:
                doc_id = str(row.get("patent_number", ""))
                sections = {
                    "title": clean_patent_text(row.get("title", ""), max_length=self.max_text_length),
                    "abstract": clean_patent_text(row.get("abstract", ""), max_length=self.max_text_length),
                    "claims": clean_patent_text(row.get("claims", ""), max_length=self.max_text_length),
                    "description": clean_patent_text(row.get("description", ""), max_length=self.max_text_length)
                }
                raw_labels = row.get("cpc_label", [])
                
            elif "bigpatent" in self.dataset_name:
                doc_id = "bp_" + str(hash(row.get("description", "")[:50]))
                sections = {
                    "title": "",
                    "abstract": clean_patent_text(row.get("abstract", ""), max_length=self.max_text_length),
                    "claims": "",
                    "description": clean_patent_text(row.get("description", ""), max_length=self.max_text_length)
                }
                raw_labels = [] # BigPatent lacks row-level CPC
                
            else:
                raise ValueError(f"Unknown dataset name: {self.dataset_name}")
                
            # 2. Encode Labels
            # 2. Encode Labels
            labels_dict = {}
            if self.label_encoder and getattr(self.label_encoder, "is_fitted", False):
                encoded = self.label_encoder.encode(raw_labels)
                if isinstance(encoded, dict):
                    # Hierarchical encoder
                    labels_dict = {k: torch.tensor(v, dtype=torch.float32) for k, v in encoded.items()}
                else:
                    # Flat encoder
                    labels_dict = {"labels": torch.tensor(encoded, dtype=torch.float32)}
            else:
                labels_dict = {"labels": torch.empty(0)}
                
            # 3. Apply Chunking (if enabled)
            if self.chunker:
                for sec_name in ["abstract", "claims", "description"]:
                    sections[f"{sec_name}_chunks"] = self.chunker.chunk_text(sections[sec_name])
                    
            return {
                "doc_id": doc_id,
                "title": sections["title"],
                "abstract": sections["abstract"],
                "claims": sections["claims"],
                "description": sections["description"],
                **labels_dict,
                # Include chunks if they exist
                **({f"{k}_chunks": sections[f"{k}_chunks"] for k in ["abstract", "claims", "description"] if f"{k}_chunks" in sections})
            }
            
        except Exception as e:
            logger.warning(f"Skipping row due to processing error: {e}")
            return None
