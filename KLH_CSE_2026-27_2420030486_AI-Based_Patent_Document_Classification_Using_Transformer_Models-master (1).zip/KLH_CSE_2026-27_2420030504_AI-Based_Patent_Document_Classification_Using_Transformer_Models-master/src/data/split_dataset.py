import os
import json
import logging
from collections import Counter
from pathlib import Path
from datasets import DatasetDict, concatenate_datasets

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
INPUT_DIR = PROJECT_ROOT / "data" / "processed" / "hupd_preprocessed"
OUTPUT_DIR = PROJECT_ROOT / "data" / "processed" / "hupd_final"

def split_and_validate():
    if not INPUT_DIR.exists():
        logger.error(f"Input directory not found: {INPUT_DIR}")
        return
        
    logger.info("Loading preprocessed dataset...")
    ds_dict = DatasetDict.load_from_disk(str(INPUT_DIR))
    
    # Combine all splits to create a fresh 80/10/10 split
    all_ds = concatenate_datasets([ds_dict[split] for split in ds_dict.keys()])
    total_records = len(all_ds)
    logger.info(f"Total records before split: {total_records}")
    
    # Check for duplicates before split
    all_ids = all_ds['patent_id']
    if len(all_ids) != len(set(all_ids)):
        logger.warning(f"Found {len(all_ids) - len(set(all_ids))} duplicate IDs in total dataset!")
    
    # Perform reproducible split (80/10/10) with fixed seed
    # First split 80 train / 20 test+val
    train_test_split = all_ds.train_test_split(test_size=0.2, seed=42)
    train_ds = train_test_split['train']
    temp_test_ds = train_test_split['test']
    
    # Split the 20% evenly into 10% val / 10% test
    val_test_split = temp_test_ds.train_test_split(test_size=0.5, seed=42)
    val_ds = val_test_split['train']
    test_ds = val_test_split['test']
    
    final_dict = DatasetDict({
        "train": train_ds,
        "validation": val_ds,
        "test": test_ds
    })
    
    # Save split dataset
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    final_dict.save_to_disk(str(OUTPUT_DIR))
    logger.info(f"Saved final split dataset to {OUTPUT_DIR}")
    
    # ==========================
    # Validation & Analytics
    # ==========================
    logger.info("=== Dataset Split Validation Report ===")
    
    train_ids = set(train_ds['patent_id'])
    val_ids = set(val_ds['patent_id'])
    test_ids = set(test_ds['patent_id'])
    
    overlap_train_val = len(train_ids.intersection(val_ids))
    overlap_train_test = len(train_ids.intersection(test_ids))
    overlap_val_test = len(val_ids.intersection(test_ids))
    
    logger.info(f"Overlap Train/Val: {overlap_train_val}")
    logger.info(f"Overlap Train/Test: {overlap_train_test}")
    logger.info(f"Overlap Val/Test: {overlap_val_test}")
    
    if overlap_train_val > 0 or overlap_train_test > 0 or overlap_val_test > 0:
        logger.error("DATA LEAKAGE DETECTED: Overlapping Patent IDs!")
    else:
        logger.info("No data leakage detected.")
        
    def analyze_labels(ds, name):
        all_labels = [lbl for sublist in ds['cpc_labels'] for lbl in sublist]
        unique = len(set(all_labels))
        counts = Counter(all_labels)
        top_20 = counts.most_common(20)
        
        # Categorize into head, middle, tail
        freqs = list(counts.values())
        freqs.sort(reverse=True)
        head_thresh = max(10, len(freqs)//20) # heuristic
        head_labels = sum(1 for c in counts.values() if c > 100)
        tail_labels = sum(1 for c in counts.values() if c <= 5)
        
        logger.info(f"--- {name.upper()} SPLIT STATS ---")
        logger.info(f"Records: {len(ds)}")
        logger.info(f"Unique Labels: {unique}")
        logger.info(f"Head Labels (>100 freq): {head_labels}")
        logger.info(f"Tail Labels (<=5 freq): {tail_labels}")
        logger.info(f"Top 20 Labels: {top_20}")
        
    analyze_labels(train_ds, "train")
    analyze_labels(val_ds, "validation")
    analyze_labels(test_ds, "test")
    
if __name__ == "__main__":
    split_and_validate()
