"""Loader for the HUPD dataset."""
from __future__ import annotations

import logging
from typing import Any

from datasets import load_dataset, IterableDataset

logger = logging.getLogger(__name__)


def load_hupd_stream(
    dataset_name: str = "HUPD/hupd",
    split: str = "train",
    name: str = "sample", # HUPD requires a config name, e.g., 'sample' or a year
) -> IterableDataset:
    """Load HUPD in streaming mode for inspection.
    
    Args:
        dataset_name: Hugging Face dataset name.
        split: Dataset split.
        name: Config name (HUPD usually requires this, e.g., 'sample').
        
    Returns:
        IterableDataset.
    """
    logger.info(f"Loading {dataset_name} (config: {name}, split: {split}) in streaming mode")
    try:
        ds = load_dataset(
            dataset_name, 
            name=name, 
            split=split, 
            streaming=False, 
            trust_remote_code=True,
            uniform_split=True
        )
        return ds
    except Exception as e:
        logger.error(f"Failed to load {dataset_name}: {e}")
        raise


def get_hupd_schema(
    dataset_name: str = "HUPD/hupd",
    name: str = "sample",
) -> dict[str, Any]:
    """Get dataset features/schema without downloading."""
    try:
        from datasets import get_dataset_config_info
        info = get_dataset_config_info(dataset_name, config_name=name, trust_remote_code=True)
        return {
            "description": info.description,
            "features": info.features,
            "splits": list(info.splits.keys()) if info.splits else [],
        }
    except Exception as e:
        logger.error(f"Could not fetch schema for {dataset_name}: {e}")
        return {"error": str(e)}
