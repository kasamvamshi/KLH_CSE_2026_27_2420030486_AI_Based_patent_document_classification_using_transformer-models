"""Loader for the BIGPATENT dataset."""
from __future__ import annotations

import logging
from typing import Any

from datasets import load_dataset, IterableDataset

logger = logging.getLogger(__name__)


def load_bigpatent_stream(
    dataset_name: str = "big_patent",
    split: str = "train",
    name: str = "all", # big_patent requires a config name, e.g. 'all' or 'a' to 'y'
) -> IterableDataset:
    """Load BIGPATENT in streaming mode for inspection.
    
    Args:
        dataset_name: Hugging Face dataset name.
        split: Dataset split.
        name: Config name (CPC section or 'all').
        
    Returns:
        IterableDataset.
    """
    logger.info(f"Loading {dataset_name} (config: {name}, split: {split}) in streaming mode")
    try:
        ds = load_dataset(
            dataset_name, 
            name=name,
            split=split, 
            streaming=True, 
            trust_remote_code=True
        )
        return ds
    except Exception as e:
        logger.error(f"Failed to load {dataset_name}: {e}")
        raise


def get_bigpatent_schema(
    dataset_name: str = "big_patent",
    name: str = "all",
) -> dict[str, Any]:
    """Get dataset features/schema without downloading."""
    try:
        from datasets import get_dataset_config_info
        info = get_dataset_config_info(dataset_name, config_name=name, trust_remote_code=True)
        return {
            "description": info.description,
            "features": info.features,
            "splits": list(info.splits.keys()) if info.splits else [],
        }
    except Exception as e:
        logger.error(f"Could not fetch schema for {dataset_name}: {e}")
        return {"error": str(e)}
