"""Regex-based section extractor for monolithic patent texts."""
import re
from typing import Dict

def extract_sections(text: str) -> Dict[str, str]:
    """Extract standard sections from a unified patent text.
    
    If the dataset (e.g., USPTO-3M) provides a single monolithic string,
    this attempts to heuristically split it into title, abstract, claims,
    and description.
    
    Args:
        text: Full patent document text.
        
    Returns:
        Dictionary with keys: 'title', 'abstract', 'claims', 'description'.
    """
    if not text:
        return {"title": "", "abstract": "", "claims": "", "description": ""}

    sections = {
        "title": "",
        "abstract": "",
        "claims": "",
        "description": ""
    }
    
    # Heuristic markers commonly found in patent texts.
    # Note: Real parsing requires complex regex. This is a robust fallback.
    markers = {
        "abstract": re.compile(r'\b(?:ABSTRACT|Abstract|abstract)\b[:\-\s\n]*'),
        "claims": re.compile(r'\b(?:WHAT IS CLAIMED IS|What is claimed is|We claim|CLAIMS|Claims)\b[:\-\s\n]*'),
        "description": re.compile(r'\b(?:BACKGROUND OF THE INVENTION|Background of the Invention|BACKGROUND|DETAILED DESCRIPTION|Detailed Description)\b[:\-\s\n]*')
    }

    # Find earliest occurrences of these markers
    pos_abstract = markers["abstract"].search(text)
    pos_claims = markers["claims"].search(text)
    pos_desc = markers["description"].search(text)
    
    # Determine the boundaries
    boundaries = []
    if pos_abstract: boundaries.append((pos_abstract.start(), 'abstract', pos_abstract.end()))
    if pos_claims: boundaries.append((pos_claims.start(), 'claims', pos_claims.end()))
    if pos_desc: boundaries.append((pos_desc.start(), 'description', pos_desc.end()))
    
    boundaries.sort(key=lambda x: x[0])
    
    # If no markers found, treat the whole thing as description
    if not boundaries:
        sections["description"] = text
        return sections

    # Title is usually before the first marker
    first_boundary = boundaries[0][0]
    if first_boundary > 0:
        sections["title"] = text[:first_boundary].strip()
        
    # Extract the rest
    for i in range(len(boundaries)):
        start_idx = boundaries[i][2]
        sec_name = boundaries[i][1]
        
        if i < len(boundaries) - 1:
            end_idx = boundaries[i+1][0]
            sections[sec_name] = text[start_idx:end_idx].strip()
        else:
            sections[sec_name] = text[start_idx:].strip()
            
    return sections
