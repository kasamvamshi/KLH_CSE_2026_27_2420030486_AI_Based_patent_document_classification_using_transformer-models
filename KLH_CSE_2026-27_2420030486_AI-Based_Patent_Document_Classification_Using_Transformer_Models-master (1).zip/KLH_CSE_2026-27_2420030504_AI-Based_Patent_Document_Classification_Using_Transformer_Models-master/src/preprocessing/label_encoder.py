"""Hierarchical CPC Label Encoder."""
import json
import logging
from collections import Counter
from pathlib import Path
from typing import Dict, List, Set, Union, Optional

import numpy as np

logger = logging.getLogger(__name__)

class CPCLabelEncoder:
    """Encodes raw CPC strings into multi-hot hierarchical tensors."""
    
    def __init__(self, min_frequency: int = 10, primary_level: str = "subclass"):
        self.min_frequency = min_frequency
        self.primary_level = primary_level
        self.vocab: Dict[str, int] = {}
        self.idx_to_label: Dict[int, str] = {}
        self.is_fitted = False
        
    def _parse_raw_cpc(self, raw_cpc: Union[str, List[str]]) -> Set[str]:
        """Parse raw CPC string or list into standardized codes.
        
        Example: "G06N3/08, G06F17/00" -> {"G06N", "G06F"} (if level="subclass")
        """
        if not raw_cpc:
            return set()
            
        if isinstance(raw_cpc, str):
            # USPTO-3M format: comma separated
            codes = [c.strip() for c in raw_cpc.split(",") if c.strip()]
        else:
            # HUPD format: list of strings
            codes = [c.strip() for c in raw_cpc if c.strip()]
            
        extracted = set()
        for code in codes:
            # Basic parsing logic for CPC.
            # Section: 1 char (e.g., G)
            # Class: 3 chars (e.g., G06)
            # Subclass: 4 chars (e.g., G06N)
            if self.primary_level == "section":
                extracted.add(code[:1])
            elif self.primary_level == "class":
                extracted.add(code[:3])
            elif self.primary_level == "subclass":
                extracted.add(code[:4])
            else:
                # Default to full string (main_group or subgroup)
                extracted.add(code)
                
        return {c for c in extracted if len(c) > 0}
        
    def fit(self, labels_list: List[Union[str, List[str]]]):
        """Build vocabulary from dataset labels."""
        counter = Counter()
        for raw_cpc in labels_list:
            parsed = self._parse_raw_cpc(raw_cpc)
            counter.update(parsed)
            
        # Filter by min frequency
        valid_labels = [label for label, count in counter.items() if count >= self.min_frequency]
        valid_labels.sort()
        
        self.vocab = {label: idx for idx, label in enumerate(valid_labels)}
        self.idx_to_label = {idx: label for label, idx in self.vocab.items()}
        self.is_fitted = True
        logger.info(f"Fitted CPCLabelEncoder. Vocab size: {len(self.vocab)}")
        
    def encode(self, raw_cpc: Union[str, List[str]]) -> np.ndarray:
        """Encode a single label into multi-hot vector."""
        if not self.is_fitted:
            raise ValueError("Encoder must be fitted before calling encode.")
            
        parsed = self._parse_raw_cpc(raw_cpc)
        vector = np.zeros(len(self.vocab), dtype=np.float32)
        
        for code in parsed:
            if code in self.vocab:
                vector[self.vocab[code]] = 1.0
                
        return vector

    def save(self, path: Union[str, Path]):
        """Save the vocabulary."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            json.dump({
                "min_frequency": self.min_frequency,
                "primary_level": self.primary_level,
                "vocab": self.vocab,
                "idx_to_label": self.idx_to_label
            }, f, indent=2)
            
    def load(self, path: Union[str, Path]):
        """Load the vocabulary."""
        with open(path, 'r') as f:
            data = json.load(f)
        self.min_frequency = data["min_frequency"]
        self.primary_level = data["primary_level"]
        self.vocab = data["vocab"]
        # Convert JSON string keys back to int
        self.idx_to_label = {int(k): v for k, v in data["idx_to_label"].items()}
        self.is_fitted = True
