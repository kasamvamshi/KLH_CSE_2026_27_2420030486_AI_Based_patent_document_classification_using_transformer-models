"""Text cleaning utilities for patent documents."""
import re
from typing import Optional

def clean_patent_text(
    text: Optional[str],
    remove_html: bool = True,
    normalize_whitespace: bool = True,
    remove_control_chars: bool = True,
    lowercase: bool = False,
    max_length: Optional[int] = 100000,
) -> str:
    """Clean and normalize patent text.
    
    Args:
        text: Raw patent text.
        remove_html: Whether to strip HTML tags.
        normalize_whitespace: Whether to collapse multiple spaces/newlines.
        remove_control_chars: Whether to remove non-printable control characters.
        lowercase: Whether to convert text to lowercase.
        max_length: Maximum allowed characters (truncated if longer).
        
    Returns:
        Cleaned string.
    """
    if text is None:
        return ""
        
    if not isinstance(text, str):
        text = str(text)
        
    # Remove HTML tags (patents often have <b>, <i>, <br>, etc.)
    if remove_html:
        text = re.sub(r'<[^>]+>', ' ', text)
        
    # Remove control characters (except common ones like \n, \t)
    if remove_control_chars:
        # Keep printable chars + tab + newline + carriage return
        text = re.sub(r'[^\x20-\x7E\t\n\r]', ' ', text)
        
    # Normalize whitespace
    if normalize_whitespace:
        text = re.sub(r'\s+', ' ', text).strip()
        
    if lowercase:
        text = text.lower()
        
    if max_length and len(text) > max_length:
        text = text[:max_length]
        
    return text.strip()
