"""Hierarchical CPC Label Encoder managing multiple granularities."""
import logging
from typing import Dict, List, Union
from pathlib import Path
import numpy as np

from .label_encoder import CPCLabelEncoder

logger = logging.getLogger(__name__)

class HierarchicalCPCLabelEncoder:
    """Manages 3 CPCLabelEncoders to produce Section, Class, and Subclass targets simultaneously."""
    
    def __init__(self, min_frequency: int = 1):
        self.min_frequency = min_frequency
        self.encoders = {
            "section": CPCLabelEncoder(min_frequency=min_frequency, primary_level="section"),
            "class": CPCLabelEncoder(min_frequency=min_frequency, primary_level="class"),
            "subclass": CPCLabelEncoder(min_frequency=min_frequency, primary_level="subclass")
        }
        self.is_fitted = False
        
    def fit(self, labels_list: List[Union[str, List[str]]]):
        """Fit all 3 encoders."""
        for level, encoder in self.encoders.items():
            encoder.fit(labels_list)
        self.is_fitted = True
        logger.info(f"Fitted HierarchicalCPCLabelEncoder. Vocab sizes: "
                    f"Sec={len(self.encoders['section'].vocab)}, "
                    f"Cls={len(self.encoders['class'].vocab)}, "
                    f"Sub={len(self.encoders['subclass'].vocab)}")
        
    def encode(self, raw_cpc: Union[str, List[str]]) -> Dict[str, np.ndarray]:
        """Encode a single label into 3 multi-hot vectors."""
        if not self.is_fitted:
            raise ValueError("HierarchicalCPCLabelEncoder must be fitted before calling encode.")
            
        return {
            "labels_section": self.encoders["section"].encode(raw_cpc),
            "labels_class": self.encoders["class"].encode(raw_cpc),
            "labels_subclass": self.encoders["subclass"].encode(raw_cpc)
        }
        
    def save(self, filepath: Union[str, Path]):
        import json
        data = {
            "min_frequency": self.min_frequency,
            "encoders": {
                "section": {"vocab": self.encoders["section"].vocab},
                "class": {"vocab": self.encoders["class"].vocab},
                "subclass": {"vocab": self.encoders["subclass"].vocab}
            }
        }
        with open(filepath, "w") as f:
            json.dump(data, f, indent=4)

