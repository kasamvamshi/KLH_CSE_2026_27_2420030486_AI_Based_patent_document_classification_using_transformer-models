"""Document Chunking for Long Sequences."""
from typing import List

class Chunker:
    """Splits long text into overlapping chunks."""
    
    def __init__(self, max_length: int = 512, overlap: int = 50, use_words: bool = True):
        """
        Args:
            max_length: Maximum tokens (or words/chars) per chunk.
            overlap: Overlap between chunks to preserve context.
            use_words: If True, chunk by words (split by space). If False, chunk by chars.
                       (In a real pipeline, this would use a tokenizer).
        """
        self.max_length = max_length
        self.overlap = overlap
        self.use_words = use_words
        
    def chunk_text(self, text: str) -> List[str]:
        """Split text into chunks."""
        if not text:
            return [""]
            
        if self.use_words:
            tokens = text.split()
        else:
            tokens = list(text) # characters
            
        if len(tokens) <= self.max_length:
            return [text]
            
        chunks = []
        stride = self.max_length - self.overlap
        if stride <= 0:
            stride = self.max_length # Fallback if overlap is too large
            
        for i in range(0, len(tokens), stride):
            chunk_tokens = tokens[i : i + self.max_length]
            
            if self.use_words:
                chunks.append(" ".join(chunk_tokens))
            else:
                chunks.append("".join(chunk_tokens))
                
        return chunks
