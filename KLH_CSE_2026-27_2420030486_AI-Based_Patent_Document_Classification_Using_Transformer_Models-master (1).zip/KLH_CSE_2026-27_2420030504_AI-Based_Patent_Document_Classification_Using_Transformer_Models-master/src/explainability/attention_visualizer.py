"""Native Attention Extraction for PatentClass-HAT."""
import torch
import numpy as np
from typing import Dict, Any

class NativeAttentionVisualizer:
    """Extracts and aggregates fusion attention weights from PatentClassHAT."""
    
    def __init__(self, model: torch.nn.Module):
        self.model = model
        self.model.eval()
        
    def extract_fusion_attention(self, batch: Dict[str, Any]) -> np.ndarray:
        """Runs a forward pass and extracts the Section-Aware Fusion Attention weights.
        
        Args:
            batch: Dictionary of tensors required by the model.
            
        Returns:
            np.ndarray of shape (batch_size, 4, 4) representing the attention matrix.
            The rows represent queries (sections), columns represent keys (sections).
            Indices: 0=Title, 1=Abstract, 2=Claims, 3=Description.
        """
        # Ensure all tensors are on the same device as the model
        device = next(self.model.parameters()).device
        batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
        
        with torch.no_grad():
            outputs = self.model(**batch)
            
        # Extract fusion_attention from outputs
        if "fusion_attention" not in outputs:
            raise ValueError("Model outputs do not contain 'fusion_attention'. Make sure you are using PatentClassHAT.")
            
        attn_weights = outputs["fusion_attention"]
        
        # attn_weights from nn.MultiheadAttention with batch_first=True
        # is typically (batch_size, tgt_len, src_len). Here, (batch_size, 4, 4).
        return attn_weights.cpu().numpy()
        
    def get_aggregate_section_importance(self, attn_matrix: np.ndarray) -> np.ndarray:
        """Aggregates a (batch, 4, 4) matrix into a (batch, 4) vector of section importance.
        
        A common heuristic is to average the attention received by each section (columns).
        """
        # Mean across the query dimension (rows) to see how much attention each section (column) received overall
        # Shape becomes (batch_size, 4)
        return attn_matrix.mean(axis=1)
