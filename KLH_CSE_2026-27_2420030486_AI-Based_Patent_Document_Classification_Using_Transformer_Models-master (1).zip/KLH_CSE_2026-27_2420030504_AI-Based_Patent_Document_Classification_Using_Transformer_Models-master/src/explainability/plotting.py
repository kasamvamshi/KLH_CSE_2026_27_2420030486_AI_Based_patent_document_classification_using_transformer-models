"""Plotting utilities for Explainability."""
import os
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from pathlib import Path

def plot_section_attention_heatmap(attn_matrix: np.ndarray, save_path: str):
    """Plots a heatmap of the 4x4 section attention matrix for a single document.
    
    Args:
        attn_matrix: (4, 4) numpy array.
        save_path: File path to save the .png
    """
    sections = ["Title", "Abstract", "Claims", "Description"]
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(
        attn_matrix, 
        annot=True, 
        cmap="YlGnBu", 
        xticklabels=sections, 
        yticklabels=sections,
        vmin=0.0,
        vmax=1.0
    )
    plt.title("Section-Aware Cross Attention Matrix")
    plt.xlabel("Key (Attended Section)")
    plt.ylabel("Query (Attending Section)")
    
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close()

def plot_attention_distribution(attn_vectors: np.ndarray, save_path: str):
    """Plots a bar chart showing average section importance across a batch/dataset.
    
    Args:
        attn_vectors: (batch_size, 4) numpy array.
        save_path: File path to save the .png
    """
    sections = ["Title", "Abstract", "Claims", "Description"]
    
    # Calculate means and standard deviations
    means = attn_vectors.mean(axis=0)
    stds = attn_vectors.std(axis=0)
    
    plt.figure(figsize=(8, 5))
    x_pos = np.arange(len(sections))
    
    plt.bar(x_pos, means, yerr=stds, align='center', alpha=0.7, ecolor='black', capsize=10, color='skyblue')
    plt.xticks(x_pos, sections)
    plt.ylabel('Average Attention Score')
    plt.title('Average Section Importance Across Batch')
    
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close()
