"""Advanced Loss Functions for Multi-Label Imbalance."""
import torch
import torch.nn as nn
import torch.nn.functional as F

class FocalLoss(nn.Module):
    """Focal Loss for Multi-Label Classification."""
    
    def __init__(self, gamma=2.0, alpha=0.25, reduction="mean"):
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, logits, targets):
        """
        Args:
            logits: (batch_size, num_labels)
            targets: (batch_size, num_labels)
        """
        p = torch.sigmoid(logits)
        ce_loss = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
        
        p_t = p * targets + (1 - p) * (1 - targets)
        loss = ce_loss * ((1 - p_t) ** self.gamma)
        
        if self.alpha >= 0:
            alpha_t = self.alpha * targets + (1 - self.alpha) * (1 - targets)
            loss = alpha_t * loss
            
        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss

class AsymmetricLoss(nn.Module):
    """Asymmetric Loss (ASL) for Multi-Label Classification.
    
    Reference: 'Asymmetric Loss For Multi-Label Classification' (ICCV 2021)
    """
    
    def __init__(self, gamma_neg=4.0, gamma_pos=1.0, clip=0.05, eps=1e-8, reduction="mean"):
        super().__init__()
        self.gamma_neg = gamma_neg
        self.gamma_pos = gamma_pos
        self.clip = clip
        self.eps = eps
        self.reduction = reduction

    def forward(self, logits, targets):
        """
        Args:
            logits: (batch_size, num_labels)
            targets: (batch_size, num_labels)
        """
        # Calculate probabilities
        x = torch.sigmoid(logits)
        
        # Split into positive and negative probabilities
        xs_pos = x
        xs_neg = 1.0 - x

        # Basic CE calculation
        los_pos = targets * torch.log(xs_pos.clamp(min=self.eps))
        los_neg = (1 - targets) * torch.log(xs_neg.clamp(min=self.eps))
        
        # Asymmetric Clipping
        if self.clip > 0:
            xs_neg = (xs_neg + self.clip).clamp(max=1.0)
            
        # Asymmetric Focusing
        los_pos = los_pos * ((1 - xs_pos) ** self.gamma_pos)
        los_neg = los_neg * ((1 - xs_neg) ** self.gamma_neg)
        
        loss = -(los_pos + los_neg)
        
        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss
