"""Custom PyTorch Training Loop."""
import logging
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Callable, Optional
from tqdm import tqdm

logger = logging.getLogger(__name__)

class Trainer:
    """Custom trainer for PatentClass-HAT models."""
    
    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        device: torch.device,
        metrics_fn: Optional[Callable] = None,
        max_grad_norm: float = 1.0,
    ):
        self.model = model.to(device)
        self.optimizer = optimizer
        self.device = device
        self.metrics_fn = metrics_fn
        self.max_grad_norm = max_grad_norm
        
    def train_epoch(self, dataloader: DataLoader) -> float:
        self.model.train()
        total_loss = 0.0
        num_batches = 0
        
        pbar = tqdm(dataloader, desc="Training")
        for batch in pbar:
            # Move all tensors to device
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
            
            self.optimizer.zero_grad()
            
            outputs = self.model(**batch)
            
            loss = outputs["loss"]
            loss.backward()
            
            if self.max_grad_norm > 0:
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                
            self.optimizer.step()
            
            total_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.4f}"})
            
        return total_loss / max(1, num_batches)
        
    def evaluate(self, dataloader: DataLoader) -> dict:
        self.model.eval()
        total_loss = 0.0
        num_batches = 0
        
        all_preds = []
        all_labels = []
        
        pbar = tqdm(dataloader, desc="Evaluating")
        with torch.no_grad():
            for batch in pbar:
                batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
                
                outputs = self.model(**batch)
                
                if "labels" in batch:
                    labels = batch["labels"]
                    logits = outputs["logits"]
                else:
                    labels = batch["labels_subclass"]
                    logits = outputs["logits_subclass"]
                
                loss = outputs["loss"]
                total_loss += loss.item()
                num_batches += 1
                
                # Logits to probabilities
                probs = torch.sigmoid(logits)
                
                all_preds.append(probs.cpu())
                all_labels.append(labels.cpu())
                
                pbar.set_postfix({"loss": f"{loss.item():.4f}"})
                
        metrics = {"val_loss": total_loss / max(1, num_batches)}
        
        if self.metrics_fn and all_preds:
            y_probs = torch.cat(all_preds, dim=0).numpy()
            y_true = torch.cat(all_labels, dim=0).numpy()
            clf_metrics = self.metrics_fn(y_true, y_probs)
            metrics.update(clf_metrics)
            
        return metrics
