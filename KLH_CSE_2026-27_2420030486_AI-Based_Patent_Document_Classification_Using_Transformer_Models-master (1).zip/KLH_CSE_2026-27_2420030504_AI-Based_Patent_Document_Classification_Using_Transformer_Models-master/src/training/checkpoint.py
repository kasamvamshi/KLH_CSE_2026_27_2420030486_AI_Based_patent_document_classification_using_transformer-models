"""Checkpoint Manager for saving and loading model state."""
import logging
from pathlib import Path
from typing import Optional
import torch

logger = logging.getLogger(__name__)

def save_checkpoint(
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    metrics: dict,
    path: str
):
    """Save a training checkpoint.
    
    Args:
        model: The PyTorch model.
        optimizer: The optimizer.
        epoch: Current epoch number.
        metrics: Dictionary of metrics at this checkpoint.
        path: File path to save the checkpoint.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    checkpoint = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "metrics": metrics
    }
    
    torch.save(checkpoint, path)
    logger.info(f"Checkpoint saved to {path} (epoch {epoch})")

def load_checkpoint(
    model: torch.nn.Module,
    optimizer: Optional[torch.optim.Optimizer],
    path: str,
    device: torch.device = torch.device("cpu")
) -> dict:
    """Load a training checkpoint.
    
    Args:
        model: The PyTorch model to load weights into.
        optimizer: The optimizer to load state into (optional).
        path: File path to load the checkpoint from.
        device: Device to map the checkpoint to.
        
    Returns:
        Dictionary with 'epoch' and 'metrics' from the checkpoint.
    """
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    
    model.load_state_dict(checkpoint["model_state_dict"])
    if optimizer is not None and "optimizer_state_dict" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        
    logger.info(f"Checkpoint loaded from {path} (epoch {checkpoint['epoch']})")
    
    return {
        "epoch": checkpoint["epoch"],
        "metrics": checkpoint.get("metrics", {})
    }
