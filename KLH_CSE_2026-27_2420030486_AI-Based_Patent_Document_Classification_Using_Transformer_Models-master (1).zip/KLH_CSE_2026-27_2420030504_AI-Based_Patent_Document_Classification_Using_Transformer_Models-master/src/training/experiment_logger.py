"""Experiment Logger with JSON-first strategy and optional MLflow."""
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)

class ExperimentLogger:
    """Logs experiment hyperparameters and metrics to JSON (and optionally MLflow)."""
    
    def __init__(self, experiment_name: str, log_dir: str = "experiments/logs"):
        self.experiment_name = experiment_name
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        self.run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = self.log_dir / f"{experiment_name}_{self.run_id}.json"
        
        self.record = {
            "experiment_name": experiment_name,
            "run_id": self.run_id,
            "start_time": datetime.now().isoformat(),
            "hyperparameters": {},
            "epochs": [],
            "final_metrics": {},
            "status": "running"
        }
        
        # Try to initialize MLflow
        self.mlflow = None
        try:
            import mlflow
            self.mlflow = mlflow
            mlflow.set_experiment(experiment_name)
            mlflow.start_run(run_name=self.run_id)
            logger.info("MLflow tracking enabled.")
        except ImportError:
            logger.info("MLflow not installed. Using JSON-only logging.")
        except Exception as e:
            logger.warning(f"MLflow init failed: {e}. Using JSON-only logging.")
            
    def log_hyperparameters(self, params: dict):
        """Log hyperparameters."""
        self.record["hyperparameters"] = params
        if self.mlflow:
            self.mlflow.log_params(params)
        self._save()
        
    def log_epoch(self, epoch: int, train_loss: float, val_metrics: dict):
        """Log metrics for one epoch."""
        epoch_record = {
            "epoch": epoch,
            "train_loss": train_loss,
            **val_metrics
        }
        self.record["epochs"].append(epoch_record)
        
        if self.mlflow:
            self.mlflow.log_metric("train_loss", train_loss, step=epoch)
            for k, v in val_metrics.items():
                self.mlflow.log_metric(k, v, step=epoch)
                
        self._save()
        
    def log_final(self, metrics: dict):
        """Log final results."""
        self.record["final_metrics"] = metrics
        self.record["status"] = "completed"
        self.record["end_time"] = datetime.now().isoformat()
        
        if self.mlflow:
            for k, v in metrics.items():
                self.mlflow.log_metric(f"final_{k}", v)
            self.mlflow.end_run()
            
        self._save()
        logger.info(f"Experiment log saved to {self.log_file}")
        
    def _save(self):
        """Write current record to JSON."""
        with open(self.log_file, "w") as f:
            json.dump(self.record, f, indent=2)
