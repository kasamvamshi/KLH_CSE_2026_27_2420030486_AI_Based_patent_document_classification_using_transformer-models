#!/usr/bin/env python3
"""
REAL DATA TRAINING SMOKE TEST
==============================
This is NOT full training. It verifies that the complete pipeline
(data → tokenizer → model → loss → backward → optimizer) works
on actual patent documents with real CPC labels.
"""
import sys
import logging
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from transformers import AutoTokenizer
from datasets import DatasetDict

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.preprocessing import CPCLabelEncoder
from src.data.dataset import PatentDataset
from src.models.baseline_transformer import FlatTransformerBaseline

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

FINAL_DATA_DIR = PROJECT_ROOT / "data" / "processed" / "hupd_final"


def _adapt_row_for_patent_dataset(row):
    """Adapt a preprocessed row back to HUPD-schema keys expected by PatentDataset."""
    return {
        "patent_number": row["patent_id"],
        "title": row["title"],
        "abstract": row["abstract"],
        "claims": row["claims"],
        "description": row["description"],
        "cpc_label": row["cpc_labels"],
    }


class AdaptedIterator:
    """Wraps a HF Dataset and yields rows adapted to HUPD schema."""
    def __init__(self, ds, max_rows=None):
        self.ds = ds
        self.max_rows = max_rows

    def __iter__(self):
        for i, row in enumerate(self.ds):
            if self.max_rows and i >= self.max_rows:
                break
            yield _adapt_row_for_patent_dataset(row)


def run_smoke_test():
    logger.info("=" * 60)
    logger.info("  REAL DATA TRAINING SMOKE TEST")
    logger.info("=" * 60)

    # ── 1. Device ──────────────────────────────────────────────
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Device: {device}")
    if device.type == "cuda":
        logger.info(f"GPU: {torch.cuda.get_device_name(0)}")
        logger.info(f"VRAM Total: {torch.cuda.get_device_properties(0).total_mem / 1e9:.2f} GB")

    # ── 2. Load Real Dataset ───────────────────────────────────
    if not FINAL_DATA_DIR.exists():
        logger.error(f"Final dataset not found at {FINAL_DATA_DIR}. Run split_dataset.py first.")
        return False

    logger.info(f"Loading final dataset from {FINAL_DATA_DIR}")
    ds_dict = DatasetDict.load_from_disk(str(FINAL_DATA_DIR))
    train_ds = ds_dict["train"]
    val_ds = ds_dict["validation"]
    logger.info(f"Train records: {len(train_ds)}, Validation records: {len(val_ds)}")

    # ── 3. Fit Label Encoder on REAL labels ────────────────────
    logger.info("Fitting CPCLabelEncoder on real training labels...")
    encoder = CPCLabelEncoder(min_frequency=1, primary_level="subclass")
    # Fit on a sample of real labels (first 500 for speed)
    sample_labels = [train_ds[i]["cpc_labels"] for i in range(min(500, len(train_ds)))]
    encoder.fit(sample_labels)
    num_labels = len(encoder.vocab)
    logger.info(f"Num labels (subclass vocab): {num_labels}")

    if num_labels == 0:
        logger.error("Label encoder fitted with 0 labels! Check dataset labels.")
        return False

    # ── 4. Create PatentDataset (real data, limited rows) ──────
    SMOKE_ROWS = 8  # Only 8 records for smoke test
    train_iter = AdaptedIterator(train_ds, max_rows=SMOKE_ROWS)
    train_pds = PatentDataset(train_iter, "hupd", encoder, chunker=None)

    # ── 5. Tokenizer ──────────────────────────────────────────
    model_name = "prajjwal1/bert-tiny"
    logger.info(f"Loading tokenizer: {model_name}")
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    def collate_fn(batch):
        texts = []
        labels = []
        for item in batch:
            text = f"{item['title']} {item['abstract']} {item['claims']} {item['description']}"
            texts.append(text.strip()[:2000])  # Truncate for safety
            labels.append(item["labels"])

        enc = tokenizer(texts, padding=True, truncation=True, max_length=128, return_tensors="pt")
        return {
            "input_ids": enc["input_ids"],
            "attention_mask": enc["attention_mask"],
            "labels": torch.stack(labels),
        }

    batch_size = 4
    train_loader = DataLoader(train_pds, batch_size=batch_size, collate_fn=collate_fn)

    # ── 6. Model ──────────────────────────────────────────────
    logger.info(f"Loading model: {model_name} with {num_labels} labels")
    model = FlatTransformerBaseline(model_name=model_name, num_labels=num_labels)
    model.to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-5)

    # ── 7. Forward + Backward Pass ────────────────────────────
    model.train()
    batch_count = 0
    losses = []

    for batch in train_loader:
        batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}

        logger.info(f"Batch {batch_count + 1}:")
        logger.info(f"  input_ids shape:      {batch['input_ids'].shape}")
        logger.info(f"  attention_mask shape:  {batch['attention_mask'].shape}")
        logger.info(f"  labels shape:          {batch['labels'].shape}")
        logger.info(f"  device:                {batch['input_ids'].device}")

        # Forward
        outputs = model(**batch)
        loss = outputs["loss"]
        logits = outputs["logits"]
        logger.info(f"  logits shape:          {logits.shape}")
        logger.info(f"  loss value:            {loss.item():.6f}")

        # Checks
        assert torch.isfinite(loss), "Loss is NaN or Inf!"

        # Backward
        optimizer.zero_grad()
        loss.backward()

        # Check gradients
        grad_ok = True
        for name, p in model.named_parameters():
            if p.grad is not None and not torch.isfinite(p.grad).all():
                logger.error(f"  NaN gradient in {name}")
                grad_ok = False
                break
        assert grad_ok, "Gradient contains NaN!"
        logger.info("  Gradients: OK (all finite)")

        # Optimizer step
        optimizer.step()
        logger.info("  Optimizer step: OK")

        losses.append(loss.item())
        batch_count += 1

        if device.type == "cuda":
            alloc = torch.cuda.memory_allocated(0) / 1e6
            reserved = torch.cuda.memory_reserved(0) / 1e6
            logger.info(f"  GPU Memory — Allocated: {alloc:.1f} MB, Reserved: {reserved:.1f} MB")

    # ── 8. Summary ────────────────────────────────────────────
    logger.info("=" * 60)
    logger.info("  SMOKE TEST SUMMARY")
    logger.info("=" * 60)
    logger.info(f"  Batches processed:   {batch_count}")
    logger.info(f"  Batch size:          {batch_size}")
    logger.info(f"  Num labels:          {num_labels}")
    logger.info(f"  Device:              {device}")
    logger.info(f"  Model:               {model_name}")
    logger.info(f"  Loss (first batch):  {losses[0]:.6f}")
    logger.info(f"  Loss (last batch):   {losses[-1]:.6f}")
    logger.info(f"  DataLoader:          PASS")
    logger.info(f"  Tokenizer:           PASS")
    logger.info(f"  Model Forward:       PASS")
    logger.info(f"  Loss Computation:    PASS")
    logger.info(f"  Backward Pass:       PASS")
    logger.info(f"  Gradients:           PASS (finite)")
    logger.info(f"  Optimizer Step:      PASS")
    if device.type == "cuda":
        logger.info(f"  GPU Memory:          STABLE")
    logger.info("=" * 60)
    logger.info("  RESULT: ALL CHECKS PASSED")
    logger.info("=" * 60)
    return True


if __name__ == "__main__":
    success = run_smoke_test()
    sys.exit(0 if success else 1)
