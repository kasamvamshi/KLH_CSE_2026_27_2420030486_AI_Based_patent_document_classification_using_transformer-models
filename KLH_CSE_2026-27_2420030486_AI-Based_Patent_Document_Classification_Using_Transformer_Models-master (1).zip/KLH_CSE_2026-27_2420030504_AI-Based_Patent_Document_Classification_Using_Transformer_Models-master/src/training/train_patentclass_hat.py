#!/usr/bin/env python3
"""
PatentClass-HAT — Full Training Script
=======================================
Reads configs/train_config.yaml, loads real data, trains, evaluates,
saves checkpoints and label mappings. Supports both Baseline and HAT models.

Usage:
    python -m src.training.train_patentclass_hat
    python -m src.training.train_patentclass_hat --config configs/train_config.yaml
"""
import sys
import json
import argparse
import logging
from pathlib import Path

import yaml
import torch
import numpy as np
from torch.utils.data import DataLoader
from transformers import AutoTokenizer
from datasets import DatasetDict

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.preprocessing import CPCLabelEncoder, HierarchicalCPCLabelEncoder, Chunker
from src.data.dataset import PatentDataset
from src.models.baseline_transformer import FlatTransformerBaseline
from src.models.hierarchical_transformer import PatentClassHAT
from src.training.trainer import Trainer
from src.training.checkpoint import save_checkpoint
from src.training.experiment_logger import ExperimentLogger
from src.evaluation.metrics import compute_multilabel_metrics

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
logger = logging.getLogger(__name__)

FINAL_DATA_DIR = PROJECT_ROOT / "data" / "processed" / "hupd_final"


def _adapt_row(row):
    return {
        "patent_number": row["patent_id"],
        "title": row["title"],
        "abstract": row["abstract"],
        "claims": row["claims"],
        "description": row["description"],
        "cpc_label": row["cpc_labels"],
    }


class AdaptedIterator:
    def __init__(self, ds, max_rows=None):
        self.ds = ds
        self.max_rows = max_rows

    def __iter__(self):
        for i, row in enumerate(self.ds):
            if self.max_rows and i >= self.max_rows:
                break
            yield _adapt_row(row)


def load_config(config_path: str) -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def main():
    parser = argparse.ArgumentParser(description="PatentClass-HAT Training")
    parser.add_argument("--config", type=str, default=str(PROJECT_ROOT / "configs" / "train_config.yaml"))
    args = parser.parse_args()

    cfg = load_config(args.config)
    logger.info(f"Loaded config from {args.config}")

    seed = cfg.get("seed", 42)
    torch.manual_seed(seed)
    np.random.seed(seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Device: {device}")

    if not FINAL_DATA_DIR.exists():
        logger.error(f"Dataset not found at {FINAL_DATA_DIR}. Run split_dataset.py first.")
        return

    logger.info(f"Loading dataset from {FINAL_DATA_DIR}")
    ds_dict = DatasetDict.load_from_disk(str(FINAL_DATA_DIR))
    train_ds = ds_dict["train"]
    val_ds = ds_dict["validation"]
    
    is_hierarchical = (cfg.get("model_type") == "hierarchical")
    
    # ── Label Encoder ─────────────────────────────────────────
    if is_hierarchical:
        encoder = HierarchicalCPCLabelEncoder(min_frequency=cfg.get("min_label_frequency", 1))
    else:
        encoder = CPCLabelEncoder(
            min_frequency=cfg.get("min_label_frequency", 1),
            primary_level=cfg.get("label_level", "subclass"),
        )
        
    logger.info("Fitting label encoder on training data...")
    all_train_labels = [train_ds[i]["cpc_labels"] for i in range(len(train_ds))]
    encoder.fit(all_train_labels)
    
    if is_hierarchical:
        num_labels = len(encoder.encoders["subclass"].vocab) # Used for logging mostly
        hierarchical_dims = {
            "num_sections": len(encoder.encoders["section"].vocab),
            "num_classes": len(encoder.encoders["class"].vocab),
            "num_subclasses": len(encoder.encoders["subclass"].vocab)
        }
    else:
        num_labels = len(encoder.vocab)
        hierarchical_dims = None
        
    output_dir = Path(cfg.get("output_dir", "outputs/models/baseline_run"))
    output_dir.mkdir(parents=True, exist_ok=True)

    # ── Tokenizer & Chunker ───────────────────────────────────
    model_name = cfg.get("model_name", "prajjwal1/bert-tiny")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    max_length = cfg.get("max_length", 256)
    
    chunker = None
    if is_hierarchical:
        # Long documents chunking
        chunker = Chunker(max_length=max_length, overlap=16, use_words=True)

    # ── Collate Function ──────────────────────────────────────
    def collate_flat(batch):
        texts, labels = [], []
        for item in batch:
            t = f"{item['title']} {item['abstract']} {item['claims']} {item['description']}"
            texts.append(t.strip()[:10000])
            labels.append(item["labels"])
        enc = tokenizer(texts, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
        return {
            "input_ids": enc["input_ids"],
            "attention_mask": enc["attention_mask"],
            "labels": torch.stack(labels),
        }
        
    def pad_chunk_sequence(chunks_list, max_chunks):
        # chunks_list is list of lists of strings
        # We need to pad to max_chunks
        padded = []
        for chunks in chunks_list:
            if not chunks:
                chunks = [""]
            chunks = chunks[:max_chunks]
            while len(chunks) < max_chunks:
                chunks.append("")
            padded.append(chunks)
        return padded

    def collate_hierarchical(batch):
        titles = [item['title'] for item in batch]
        abstracts = [item['abstract'] for item in batch]
        
        # Determine max chunks for this batch
        max_c_claims = min(16, max(len(item.get('claims_chunks', [''])) for item in batch))
        max_c_desc = min(32, max(len(item.get('description_chunks', [''])) for item in batch))
        
        claims = pad_chunk_sequence([item.get('claims_chunks', ['']) for item in batch], max_c_claims)
        descriptions = pad_chunk_sequence([item.get('description_chunks', ['']) for item in batch], max_c_desc)
        
        # Flatten chunks for tokenization, then reshape
        flat_claims = [c for doc in claims for c in doc]
        flat_desc = [c for doc in descriptions for c in doc]
        
        enc_title = tokenizer(titles, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
        enc_abs = tokenizer(abstracts, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
        enc_claims = tokenizer(flat_claims, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
        enc_desc = tokenizer(flat_desc, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
        
        bsz = len(batch)
        c_seq = enc_claims["input_ids"].size(1)
        d_seq = enc_desc["input_ids"].size(1)
        
        return {
            "title_input_ids": enc_title["input_ids"],
            "title_attention_mask": enc_title["attention_mask"],
            "abstract_input_ids": enc_abs["input_ids"],
            "abstract_attention_mask": enc_abs["attention_mask"],
            
            "claims_input_ids": enc_claims["input_ids"].view(bsz, max_c_claims, c_seq),
            "claims_attention_mask": enc_claims["attention_mask"].view(bsz, max_c_claims, c_seq),
            
            "desc_input_ids": enc_desc["input_ids"].view(bsz, max_c_desc, d_seq),
            "desc_attention_mask": enc_desc["attention_mask"].view(bsz, max_c_desc, d_seq),
            
            "labels_section": torch.stack([item["labels_section"] for item in batch]),
            "labels_class": torch.stack([item["labels_class"] for item in batch]),
            "labels_subclass": torch.stack([item["labels_subclass"] for item in batch]),
        }

    collate_fn = collate_hierarchical if is_hierarchical else collate_flat

    # ── Model ─────────────────────────────────────────────────
    logger.info(f"Loading model: {model_name} (type: {cfg.get('model_type')})")
    if is_hierarchical:
        model = PatentClassHAT(
            model_name=model_name,
            hierarchical_dims=hierarchical_dims,
            chunk_pooling="attention",
            classifier_type="hierarchical"
        )
    else:
        model = FlatTransformerBaseline(model_name=model_name, num_labels=num_labels)

    # ── Optimizer ─────────────────────────────────────────────
    lr = cfg.get("learning_rate", 2e-5)
    wd = cfg.get("weight_decay", 0.01)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=wd)

    # ── Trainer ───────────────────────────────────────────────
    trainer = Trainer(
        model=model,
        optimizer=optimizer,
        device=device,
        metrics_fn=compute_multilabel_metrics,
        max_grad_norm=cfg.get("max_grad_norm", 1.0),
    )

    exp_logger = ExperimentLogger(experiment_name=f"patentclass_{cfg.get('model_type', 'flat')}")
    exp_logger.log_hyperparameters({
        "model_name": model_name,
        "model_type": cfg.get("model_type", "flat"),
        "batch_size": cfg.get("batch_size", 2),
        "lr": lr,
        "epochs": cfg.get("epochs", 1),
    })

    # ── Training Loop ─────────────────────────────────────────
    epochs = cfg.get("epochs", 1)
    batch_size = cfg.get("batch_size", 2)
    patience = cfg.get("patience", 3)
    best_metric = -float("inf")
    patience_counter = 0
    ckpt_dir = Path(cfg.get("checkpoint_dir", "experiments/checkpoints"))
    
    max_train = cfg.get("max_train_samples")
    max_val = cfg.get("max_val_samples")

    for epoch in range(1, epochs + 1):
        logger.info(f"=== Epoch {epoch}/{epochs} ===")

        train_pds = PatentDataset(AdaptedIterator(train_ds, max_train), "hupd", encoder, chunker=chunker)
        val_pds = PatentDataset(AdaptedIterator(val_ds, max_val), "hupd", encoder, chunker=chunker)
        train_loader = DataLoader(train_pds, batch_size=batch_size, collate_fn=collate_fn)
        val_loader = DataLoader(val_pds, batch_size=batch_size, collate_fn=collate_fn)

        train_loss = trainer.train_epoch(train_loader)
        val_metrics = trainer.evaluate(val_loader)

        logger.info(f"Epoch {epoch} — Train Loss: {train_loss:.4f} | Val: {val_metrics}")
        exp_logger.log_epoch(epoch, train_loss, val_metrics)

        # Checkpointing
        monitor = cfg.get("monitor_metric", "val_micro_f1")
        current = val_metrics.get(monitor.replace("val_", ""), val_metrics.get("micro_f1", 0.0))

        if current > best_metric:
            best_metric = current
            patience_counter = 0
            save_checkpoint(model, optimizer, epoch, val_metrics, str(ckpt_dir / "best_model.pt"))
            tokenizer.save_pretrained(str(output_dir / "tokenizer"))
        else:
            patience_counter += 1
            if cfg.get("early_stopping", True) and patience_counter >= patience:
                logger.info("Early stopping triggered.")
                break

    exp_logger.log_final(val_metrics)
    torch.save(model.state_dict(), output_dir / "model_weights.pt")
    encoder.save(output_dir / "label_encoder.json")
    logger.info("Training complete.")


if __name__ == "__main__":
    main()
