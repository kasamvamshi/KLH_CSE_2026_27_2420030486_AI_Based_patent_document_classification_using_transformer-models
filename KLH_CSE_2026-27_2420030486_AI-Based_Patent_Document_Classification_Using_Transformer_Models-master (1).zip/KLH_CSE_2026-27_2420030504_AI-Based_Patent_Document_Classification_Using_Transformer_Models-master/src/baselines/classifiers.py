"""Multi-label classic ML classifiers (Logistic Regression, SVM)."""
import logging
from typing import Optional
from pathlib import Path
import joblib

import numpy as np
import scipy.sparse as sp
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import f1_score, precision_score, recall_score, classification_report

logger = logging.getLogger(__name__)

class SklearnBaselineModel:
    """Wrapper for scikit-learn multi-label baseline models."""
    
    def __init__(self, model_type: str = "logistic", random_state: int = 42):
        """
        Args:
            model_type: "logistic" or "svm"
            random_state: Seed for reproducibility
        """
        self.model_type = model_type
        if model_type == "logistic":
            base_estimator = LogisticRegression(solver="liblinear", random_state=random_state)
        elif model_type == "svm":
            base_estimator = LinearSVC(random_state=random_state)
        else:
            raise ValueError(f"Unknown model_type: {model_type}")
            
        self.model = OneVsRestClassifier(base_estimator, n_jobs=-1)
        self.is_fitted = False
        
    def fit(self, X: sp.csr_matrix, y: np.ndarray):
        """Fit the multi-label classifier.
        
        Args:
            X: Sparse feature matrix (e.g., from TF-IDF) [n_samples, n_features]
            y: Binary multi-hot label matrix [n_samples, n_classes]
        """
        logger.info(f"Training {self.model_type.upper()} baseline on {X.shape[0]} samples with {y.shape[1]} classes...")
        self.model.fit(X, y)
        self.is_fitted = True
        logger.info("Training complete.")
        
    def predict(self, X: sp.csr_matrix) -> np.ndarray:
        """Predict multi-hot labels."""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction.")
        return self.model.predict(X)
        
    def predict_proba(self, X: sp.csr_matrix) -> np.ndarray:
        """Predict probabilities (only supported by logistic)."""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction.")
        if self.model_type != "logistic":
            raise NotImplementedError("predict_proba only supported for logistic regression.")
        return self.model.predict_proba(X)
        
    def evaluate(self, X: sp.csr_matrix, y_true: np.ndarray, target_names: Optional[list] = None) -> dict:
        """Evaluate the model and return metrics."""
        y_pred = self.predict(X)
        
        # Micro metrics (aggregate across all samples/classes equally)
        micro_f1 = f1_score(y_true, y_pred, average="micro", zero_division=0)
        micro_p = precision_score(y_true, y_pred, average="micro", zero_division=0)
        micro_r = recall_score(y_true, y_pred, average="micro", zero_division=0)
        
        # Macro metrics (unweighted average across classes)
        macro_f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
        
        metrics = {
            "micro_f1": float(micro_f1),
            "micro_precision": float(micro_p),
            "micro_recall": float(micro_r),
            "macro_f1": float(macro_f1)
        }
        
        # Also print detailed report
        report = classification_report(y_true, y_pred, target_names=target_names, zero_division=0)
        logger.info("\n" + report)
        
        return metrics

    def save(self, path: str):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self.model, path)
        
    def load(self, path: str):
        self.model = joblib.load(path)
        self.is_fitted = True
