"""TF-IDF feature extraction pipeline for baseline models."""
import logging
from typing import List, Iterable
import joblib
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
import scipy.sparse as sp

logger = logging.getLogger(__name__)


class TFIDFFeaturizer:
    """Extracts TF-IDF features from text for baseline classifiers."""
    
    def __init__(self, max_features: int = 10000, ngram_range: tuple = (1, 2)):
        """
        Args:
            max_features: Maximum vocabulary size.
            ngram_range: n-grams to extract.
        """
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            stop_words="english",
            lowercase=True
        )
        self.is_fitted = False
        
    def _combine_sections(self, texts: List[dict]) -> List[str]:
        """Combines title, abstract, claims, and description into one string per document."""
        combined = []
        for t in texts:
            # Safely get each section, falling back to empty string
            title = t.get("title", "")
            abstract = t.get("abstract", "")
            claims = t.get("claims", "")
            description = t.get("description", "")
            # Join with space
            combined.append(f"{title} {abstract} {claims} {description}".strip())
        return combined

    def fit(self, dataset_dicts: Iterable[dict]):
        """Fit the vectorizer on an iterable of dictionary rows from the Dataset."""
        logger.info("Fitting TF-IDF vectorizer...")
        # Since it's a generator, we need to collect the text.
        # Warning: For massive datasets, this might OOM. 
        # In a real pipeline, we'd use HashingVectorizer for streaming or fit on a subset.
        texts = self._combine_sections(list(dataset_dicts))
        self.vectorizer.fit(texts)
        self.is_fitted = True
        logger.info(f"TF-IDF fitted with vocab size: {len(self.vectorizer.vocabulary_)}")
        
    def transform(self, dataset_dicts: Iterable[dict]) -> sp.csr_matrix:
        """Transform text dictionaries into TF-IDF sparse matrices."""
        if not self.is_fitted:
            raise ValueError("TFIDFFeaturizer must be fitted before transforming.")
        
        texts = self._combine_sections(list(dataset_dicts))
        return self.vectorizer.transform(texts)
        
    def save(self, path: str):
        """Save vectorizer to disk."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self.vectorizer, path)
        
    def load(self, path: str):
        """Load vectorizer from disk."""
        self.vectorizer = joblib.load(path)
        self.is_fitted = True
