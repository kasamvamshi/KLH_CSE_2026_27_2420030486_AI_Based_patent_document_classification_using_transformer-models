import torch

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def check_device():
    if torch.cuda.is_available():
        print("Using GPU:", torch.cuda.get_device_name(0))
        print("CUDA version:", torch.version.cuda)
        print(f"Total VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
    else:
        print("Using CPU (CUDA unavailable)")

def run_tensor_test():
    try:
        # Create a tensor
        a = torch.randn(100, 100).to(DEVICE)
        b = torch.randn(100, 100).to(DEVICE)
        
        # Perform matrix multiplication
        c = torch.matmul(a, b)
        
        # Move back to CPU
        c_cpu = c.to('cpu')
        
        print(f"Tensor test passed on device: {DEVICE}")
        return True
    except Exception as e:
        print(f"Tensor test failed: {e}")
        return False

if __name__ == "__main__":
    check_device()
    run_tensor_test()
