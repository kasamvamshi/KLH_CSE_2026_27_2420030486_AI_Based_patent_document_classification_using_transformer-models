"""Hierarchical Classifier Cascade for CPC labels."""
import torch
import torch.nn as nn
from typing import Dict, Optional

class HierarchicalClassifier(nn.Module):
    """Predicts Section, Class, and Subclass hierarchically.
    
    The prediction of coarser levels is concatenated to the document embedding
    to inform the finer levels.
    """
    def __init__(self, hidden_size: int, num_sections: int, num_classes: int, num_subclasses: int, dropout: float = 0.1):
        super().__init__()
        
        self.dropout = nn.Dropout(dropout)
        
        # Level 1: Section
        self.section_classifier = nn.Linear(hidden_size, num_sections)
        
        # Level 2: Class (informed by Section prediction)
        self.class_classifier = nn.Linear(hidden_size + num_sections, num_classes)
        
        # Level 3: Subclass (informed by Class prediction)
        self.subclass_classifier = nn.Linear(hidden_size + num_classes, num_subclasses)
        
    def forward(self, doc_embedding: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            doc_embedding: (batch_size, hidden_size)
        Returns:
            Dictionary of logits for section, class, and subclass.
        """
        doc_embedding = self.dropout(doc_embedding)
        
        # Predict Section
        logits_section = self.section_classifier(doc_embedding)
        
        # Predict Class
        class_input = torch.cat([doc_embedding, logits_section], dim=-1)
        logits_class = self.class_classifier(class_input)
        
        # Predict Subclass
        subclass_input = torch.cat([doc_embedding, logits_class], dim=-1)
        logits_subclass = self.subclass_classifier(subclass_input)
        
        return {
            "logits_section": logits_section,
            "logits_class": logits_class,
            "logits_subclass": logits_subclass
        }

def compute_hierarchical_loss(
    logits_dict: Dict[str, torch.Tensor], 
    labels_dict: Dict[str, torch.Tensor],
    loss_fn: nn.Module
) -> torch.Tensor:
    """Computes joint loss across all hierarchical levels."""
    loss_sec = loss_fn(logits_dict["logits_section"], labels_dict["labels_section"])
    loss_cls = loss_fn(logits_dict["logits_class"], labels_dict["labels_class"])
    loss_sub = loss_fn(logits_dict["logits_subclass"], labels_dict["labels_subclass"])
    return loss_sec + loss_cls + loss_sub
