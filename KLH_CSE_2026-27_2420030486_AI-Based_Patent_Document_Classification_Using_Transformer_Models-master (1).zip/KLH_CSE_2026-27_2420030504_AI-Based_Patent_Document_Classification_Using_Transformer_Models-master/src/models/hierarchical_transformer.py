"""Section-Aware Hierarchical Attention Transformer (PatentClass-HAT)."""
import logging
import torch
import torch.nn as nn
from transformers import AutoModel, PreTrainedModel

logger = logging.getLogger(__name__)

class PatentClassHAT(nn.Module):
    """Hierarchical Attention Transformer for Section-Aware Patent Classification."""
    
    def __init__(
        self, 
        model_name: str, 
        num_labels: int = None,
        hierarchical_dims: dict = None,
        chunk_pooling: str = "mean",
        dropout: float = 0.1,
        loss_fn: nn.Module = None,
        classifier_type: str = "flat"
    ):
        """
        Args:
            model_name: Hugging Face backbone.
            num_labels: Number of output labels (for flat classifier).
            hierarchical_dims: Dict with num_sections, num_classes, num_subclasses (for hierarchical).
            chunk_pooling: Pooling strategy for long sections ("mean", "max", "attention").
            dropout: Dropout probability.
            loss_fn: Optional custom loss function.
            classifier_type: "flat" or "hierarchical".
        """
        super().__init__()
        self.classifier_type = classifier_type
        self.chunk_pooling = chunk_pooling
        
        logger.info(f"Loading shared backbone: {model_name}")
        # We share the backbone across all 4 streams to prevent OOM
        self.shared_encoder: PreTrainedModel = AutoModel.from_pretrained(model_name)
        self.hidden_size = self.shared_encoder.config.hidden_size
        
        # Section-Aware Fusion Module (Self-Attention over the 4 section vectors)
        # We project the 4 vectors into Q, K, V and apply standard Multi-Head Attention
        self.fusion_attention = nn.MultiheadAttention(
            embed_dim=self.hidden_size, 
            num_heads=4, 
            dropout=dropout,
            batch_first=True
        )
        
        # We can also learn a Section Type Embedding to help the fusion layer
        # 0: Title, 1: Abstract, 2: Claims, 3: Description
        self.section_type_embeddings = nn.Embedding(4, self.hidden_size)
        
        if self.chunk_pooling == "attention":
            self.chunk_attention = nn.Linear(self.hidden_size, 1)
            
        self.dropout = nn.Dropout(dropout)
        
        # Final classification
        if self.classifier_type == "hierarchical":
            from .hierarchical_head import HierarchicalClassifier
            self.classifier = HierarchicalClassifier(
                hidden_size=self.hidden_size,
                num_sections=hierarchical_dims["num_sections"],
                num_classes=hierarchical_dims["num_classes"],
                num_subclasses=hierarchical_dims["num_subclasses"],
                dropout=dropout
            )
        else:
            self.classifier = nn.Linear(self.hidden_size, num_labels)
            
        self.loss_fn = loss_fn if loss_fn is not None else nn.BCEWithLogitsLoss()
        
    def _encode_short_section(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        """Encode a short section (title, abstract). Returns (batch_size, hidden_size)."""
        outputs = self.shared_encoder(input_ids=input_ids, attention_mask=attention_mask)
        if hasattr(outputs, "pooler_output") and outputs.pooler_output is not None:
            return outputs.pooler_output
        return outputs.last_hidden_state[:, 0, :]
        
    def _encode_long_section(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        """Encode a chunked section (claims, description). Returns (batch_size, hidden_size)."""
        batch_size, num_chunks, seq_len = input_ids.size()
        
        flat_input_ids = input_ids.view(-1, seq_len)
        flat_attention_mask = attention_mask.view(-1, seq_len)
        
        outputs = self.shared_encoder(input_ids=flat_input_ids, attention_mask=flat_attention_mask)
        
        if hasattr(outputs, "pooler_output") and outputs.pooler_output is not None:
            chunk_embeddings = outputs.pooler_output
        else:
            chunk_embeddings = outputs.last_hidden_state[:, 0, :]
            
        chunk_embeddings = chunk_embeddings.view(batch_size, num_chunks, -1)
        chunk_mask = (attention_mask.sum(dim=-1) > 0).float()
        
        if self.chunk_pooling == "mean":
            chunk_embeddings = chunk_embeddings * chunk_mask.unsqueeze(-1)
            sum_embeddings = chunk_embeddings.sum(dim=1)
            valid_chunks = chunk_mask.sum(dim=1, keepdim=True).clamp(min=1.0)
            return sum_embeddings / valid_chunks
            
        elif self.chunk_pooling == "max":
            masked = chunk_embeddings.masked_fill(chunk_mask.unsqueeze(-1) == 0, -1e9)
            doc_embedding, _ = masked.max(dim=1)
            return doc_embedding
            
        elif self.chunk_pooling == "attention":
            scores = self.chunk_attention(chunk_embeddings).squeeze(-1)
            scores = scores.masked_fill(chunk_mask == 0, -1e9)
            attn_weights = torch.softmax(scores, dim=1)
            doc_embedding = torch.bmm(attn_weights.unsqueeze(1), chunk_embeddings).squeeze(1)
            return doc_embedding
            
    def forward(
        self,
        title_input_ids: torch.Tensor, title_attention_mask: torch.Tensor,
        abstract_input_ids: torch.Tensor, abstract_attention_mask: torch.Tensor,
        claims_input_ids: torch.Tensor, claims_attention_mask: torch.Tensor,
        desc_input_ids: torch.Tensor, desc_attention_mask: torch.Tensor,
        **kwargs
    ) -> dict:
        
        batch_size = title_input_ids.size(0)
        
        # 1. Encode all 4 streams independently
        # (batch_size, hidden_size)
        v_title = self._encode_short_section(title_input_ids, title_attention_mask)
        v_abstract = self._encode_short_section(abstract_input_ids, abstract_attention_mask)
        v_claims = self._encode_long_section(claims_input_ids, claims_attention_mask)
        v_desc = self._encode_long_section(desc_input_ids, desc_attention_mask)
        
        # 2. Stack into sequence: (batch_size, 4, hidden_size)
        section_embs = torch.stack([v_title, v_abstract, v_claims, v_desc], dim=1)
        
        # 3. Add Section Type Embeddings
        # Indices 0,1,2,3 mapped across the batch
        section_ids = torch.arange(4, device=section_embs.device).unsqueeze(0).expand(batch_size, 4)
        section_type_feats = self.section_type_embeddings(section_ids)
        section_embs = section_embs + section_type_feats
        
        # 4. Section-Aware Fusion (Self-Attention)
        # MultiheadAttention expects batch_first=True
        fused_embs, attn_weights = self.fusion_attention(
            query=section_embs,
            key=section_embs,
            value=section_embs
        )
        # fused_embs is (batch_size, 4, hidden_size)
        
        # 5. Final pooling (Mean pool the fused vectors)
        doc_vector = fused_embs.mean(dim=1)
        
        # 6. Classification
        if self.classifier_type == "hierarchical":
            logits_dict = self.classifier(doc_vector)
            result = {"fusion_attention": attn_weights, **logits_dict}
            
            # Optionally compute loss if all labels are provided
            if all(k in kwargs for k in ["labels_section", "labels_class", "labels_subclass"]):
                from .hierarchical_head import compute_hierarchical_loss
                labels_dict = {
                    "labels_section": kwargs["labels_section"],
                    "labels_class": kwargs["labels_class"],
                    "labels_subclass": kwargs["labels_subclass"]
                }
                loss = compute_hierarchical_loss(logits_dict, labels_dict, self.loss_fn)
                result["loss"] = loss
        else:
            doc_vector = self.dropout(doc_vector)
            logits = self.classifier(doc_vector)
            result = {"logits": logits, "fusion_attention": attn_weights}
            
            if "labels" in kwargs:
                loss = self.loss_fn(logits, kwargs["labels"])
                result["loss"] = loss
            
        return result
