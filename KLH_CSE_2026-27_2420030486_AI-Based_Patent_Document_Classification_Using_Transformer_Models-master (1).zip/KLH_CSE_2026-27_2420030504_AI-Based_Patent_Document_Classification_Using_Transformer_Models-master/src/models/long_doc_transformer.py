"""Hierarchical Long-Document Transformer."""
import logging
import torch
import torch.nn as nn
from transformers import AutoModel, PreTrainedModel

logger = logging.getLogger(__name__)

class LongDocTransformer(nn.Module):
    """Encodes long documents by chunking and aggregating."""
    
    def __init__(
        self, 
        model_name: str, 
        num_labels: int, 
        pooling_strategy: str = "mean",
        dropout: float = 0.1,
        loss_fn: nn.Module = None
    ):
        """
        Args:
            model_name: Hugging Face model string (e.g., 'prajjwal1/bert-tiny')
            num_labels: Number of classes.
            pooling_strategy: "mean", "max", or "attention"
            dropout: Dropout probability.
        """
        super().__init__()
        self.num_labels = num_labels
        self.pooling_strategy = pooling_strategy
        
        logger.info(f"Loading AutoModel backbone: {model_name}")
        self.encoder: PreTrainedModel = AutoModel.from_pretrained(model_name)
        
        hidden_size = self.encoder.config.hidden_size
        
        if self.pooling_strategy == "attention":
            self.attention_weights = nn.Linear(hidden_size, 1)
            
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_size, num_labels)
        
        self.loss_fn = loss_fn if loss_fn is not None else nn.BCEWithLogitsLoss()
        
    def forward(
        self, 
        input_ids: torch.Tensor, 
        attention_mask: torch.Tensor, 
        labels: torch.Tensor = None
    ) -> dict:
        """
        Args:
            input_ids: (batch_size, num_chunks, seq_len)
            attention_mask: (batch_size, num_chunks, seq_len)
            labels: (batch_size, num_labels)
            
        Returns:
            dict containing 'logits' and optionally 'loss'
        """
        batch_size, num_chunks, seq_len = input_ids.size()
        
        # Flatten batch and chunks: (batch_size * num_chunks, seq_len)
        flat_input_ids = input_ids.view(-1, seq_len)
        flat_attention_mask = attention_mask.view(-1, seq_len)
        
        # Extract features using the backbone
        # We only care about the [CLS] token (or pooled output) for each chunk
        outputs = self.encoder(
            input_ids=flat_input_ids,
            attention_mask=flat_attention_mask,
        )
        
        # Depending on the model, we use pooler_output if available, else CLS token
        if hasattr(outputs, "pooler_output") and outputs.pooler_output is not None:
            chunk_embeddings = outputs.pooler_output
        else:
            chunk_embeddings = outputs.last_hidden_state[:, 0, :] # [CLS] token
            
        # Reshape back to chunks: (batch_size, num_chunks, hidden_size)
        chunk_embeddings = chunk_embeddings.view(batch_size, num_chunks, -1)
        
        # Chunk padding mask: If a chunk is entirely [PAD] tokens, its attention_mask sum is 0
        chunk_mask = (attention_mask.sum(dim=-1) > 0).float() # (batch_size, num_chunks)
        
        # Aggregate chunk embeddings
        if self.pooling_strategy == "mean":
            # Mask out empty chunks
            chunk_embeddings = chunk_embeddings * chunk_mask.unsqueeze(-1)
            # Sum and divide by number of valid chunks
            sum_embeddings = chunk_embeddings.sum(dim=1)
            valid_chunks = chunk_mask.sum(dim=1, keepdim=True).clamp(min=1.0)
            doc_embedding = sum_embeddings / valid_chunks
            
        elif self.pooling_strategy == "max":
            # Replace empty chunks with a large negative number before max pooling
            masked_embeddings = chunk_embeddings.masked_fill(chunk_mask.unsqueeze(-1) == 0, -1e9)
            doc_embedding, _ = masked_embeddings.max(dim=1)
            
        elif self.pooling_strategy == "attention":
            # Calculate attention scores for each chunk
            scores = self.attention_weights(chunk_embeddings).squeeze(-1) # (batch_size, num_chunks)
            # Mask empty chunks
            scores = scores.masked_fill(chunk_mask == 0, -1e9)
            # Softmax to get weights
            attn_weights = torch.softmax(scores, dim=1) # (batch_size, num_chunks)
            # Weighted sum
            doc_embedding = torch.bmm(attn_weights.unsqueeze(1), chunk_embeddings).squeeze(1)
            
        else:
            raise ValueError(f"Unknown pooling strategy: {self.pooling_strategy}")
            
        # Classification
        doc_embedding = self.dropout(doc_embedding)
        logits = self.classifier(doc_embedding)
        
        result = {"logits": logits}
        
        if labels is not None:
            loss = self.loss_fn(logits, labels)
            result["loss"] = loss
            
        return result
