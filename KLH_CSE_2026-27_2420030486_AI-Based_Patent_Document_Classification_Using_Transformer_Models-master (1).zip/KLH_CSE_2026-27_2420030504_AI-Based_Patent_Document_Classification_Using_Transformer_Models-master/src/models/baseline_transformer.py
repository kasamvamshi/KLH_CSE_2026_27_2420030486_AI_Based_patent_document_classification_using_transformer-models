"""Flat Transformer Baseline model."""
import logging
import torch
import torch.nn as nn
from transformers import AutoModelForSequenceClassification, PreTrainedModel

logger = logging.getLogger(__name__)

class FlatTransformerBaseline(nn.Module):
    """A standard flat Transformer for multi-label classification.
    
    Truncates inputs to max length (typically 512 tokens).
    Uses BCEWithLogitsLoss for multi-label setup.
    """
    
    def __init__(self, model_name: str, num_labels: int, dropout: float = 0.1, loss_fn: nn.Module = None):
        """
        Args:
            model_name: Hugging Face model string (e.g., 'microsoft/deberta-v3-small')
            num_labels: Number of classes.
            dropout: Dropout probability.
            loss_fn: Optional custom loss function.
        """
        super().__init__()
        self.num_labels = num_labels
        
        logger.info(f"Loading AutoModelForSequenceClassification for {model_name}")
        self.encoder: PreTrainedModel = AutoModelForSequenceClassification.from_pretrained(
            model_name,
            num_labels=num_labels,
            problem_type="multi_label_classification",
            ignore_mismatched_sizes=True # In case we are loading from a checkpoint with different num_labels
        )
        
        self.loss_fn = loss_fn if loss_fn is not None else nn.BCEWithLogitsLoss()
        
    def forward(
        self, 
        input_ids: torch.Tensor, 
        attention_mask: torch.Tensor, 
        labels: torch.Tensor = None
    ) -> dict:
        """
        Args:
            input_ids: (batch_size, seq_len)
            attention_mask: (batch_size, seq_len)
            labels: (batch_size, num_labels)
            
        Returns:
            dict containing 'logits' and optionally 'loss'
        """
        outputs = self.encoder(
            input_ids=input_ids,
            attention_mask=attention_mask,
        )
        
        logits = outputs.logits
        
        result = {"logits": logits}
        
        if labels is not None:
            loss = self.loss_fn(logits, labels)
            result["loss"] = loss
            
        return result
