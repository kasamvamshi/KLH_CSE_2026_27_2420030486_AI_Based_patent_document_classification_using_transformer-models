"""Evaluation metrics for multi-label classification."""
import numpy as np
from sklearn.metrics import f1_score, precision_score, recall_score

def compute_multilabel_metrics(y_true: np.ndarray, y_probs: np.ndarray, threshold: float = 0.5) -> dict:
    """Compute standard multi-label metrics.
    
    Args:
        y_true: Ground truth binary labels (batch_size, num_classes)
        y_probs: Predicted probabilities (batch_size, num_classes)
        threshold: Decision threshold for probabilities
        
    Returns:
        Dictionary of metrics.
    """
    y_pred = (y_probs >= threshold).astype(int)
    y_true = y_true.astype(int)
    
    micro_f1 = f1_score(y_true, y_pred, average="micro", zero_division=0)
    macro_f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
    micro_p = precision_score(y_true, y_pred, average="micro", zero_division=0)
    micro_r = recall_score(y_true, y_pred, average="micro", zero_division=0)
    
    return {
        "micro_f1": float(micro_f1),
        "macro_f1": float(macro_f1),
        "micro_precision": float(micro_p),
        "micro_recall": float(micro_r)
    }
