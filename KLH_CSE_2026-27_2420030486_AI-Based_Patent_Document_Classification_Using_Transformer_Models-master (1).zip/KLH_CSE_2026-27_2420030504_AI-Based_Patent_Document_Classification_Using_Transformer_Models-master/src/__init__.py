"""PatentClass-HAT source package.

This is the root package for all PatentClass-HAT source code.
Subpackages:
    - data: Dataset loaders and data utilities
    - preprocessing: Text cleaning, section extraction, label normalization
    - baselines: TF-IDF and other traditional ML baselines
    - models: Transformer and PatentClass-HAT model architectures
    - training: Training loops, optimizers, schedulers
    - evaluation: Metrics computation and result analysis
    - explainability: Attention visualization, SHAP, integrated gradients
    - inference: Model loading and prediction pipelines
    - utils: Configuration, logging, paths, seeds
"""

__version__ = "0.1.0"
