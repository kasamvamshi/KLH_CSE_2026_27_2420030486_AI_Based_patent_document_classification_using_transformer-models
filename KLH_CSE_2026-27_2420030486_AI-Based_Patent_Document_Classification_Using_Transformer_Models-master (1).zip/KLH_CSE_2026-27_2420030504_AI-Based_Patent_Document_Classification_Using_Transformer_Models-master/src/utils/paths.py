"""PatentClass-HAT centralized path management.

Provides a single source of truth for all project directory paths,
using `pathlib.Path`. Directories are created on first access if
they don't already exist.

Usage:
    from src.utils.paths import ProjectPaths

    paths = ProjectPaths()
    print(paths.data_raw)        # <project_root>/data/raw
    print(paths.outputs_models)  # <project_root>/outputs/models
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional


# ============================================================
# Resolve project root
# ============================================================
# The project root is three levels up from this file:
#   src/utils/paths.py → src/utils → src → project_root
_DEFAULT_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent


class ProjectPaths:
    """Centralized path constants for the PatentClass-HAT project.

    All paths are computed relative to the project root directory.
    The project root can be overridden via the PATENTCLASS_ROOT
    environment variable.

    Attributes:
        root: Project root directory.
        configs: Configuration files directory.
        data_raw: Raw (unprocessed) dataset storage.
        data_interim: Intermediate processing artifacts.
        data_processed: Final processed datasets.
        data_label_maps: CPC label-to-ID mappings.
        notebooks: Jupyter notebooks.
        src: Source code root.
        experiments: Experiment results.
        outputs_models: Saved model checkpoints.
        outputs_predictions: Prediction output files.
        outputs_explanations: Explainability outputs.
        outputs_plots: Generated plots and figures.
        outputs_reports: Generated reports.
        logs: Log files directory.
        api: API source code.
        frontend: Frontend source code.
        tests: Test files.
        docs: Documentation.
        scripts: Utility scripts.
    """

    def __init__(self, root: Optional[Path] = None) -> None:
        """Initialize project paths.

        Args:
            root: Project root directory. If None, uses the
                  PATENTCLASS_ROOT environment variable or
                  auto-detects from this file's location.
        """
        if root is not None:
            self.root = Path(root).resolve()
        else:
            env_root = os.environ.get("PATENTCLASS_ROOT")
            self.root = Path(env_root) if env_root else _DEFAULT_PROJECT_ROOT

        # --- Configuration ---
        self.configs = self.root / "configs"

        # --- Data ---
        self.data = self.root / "data"
        self.data_raw = self.data / "raw"
        self.data_raw_uspto3m = self.data_raw / "uspto3m"
        self.data_raw_hupd = self.data_raw / "hupd"
        self.data_raw_bigpatent = self.data_raw / "bigpatent"
        self.data_interim = self.data / "interim"
        self.data_processed = self.data / "processed"
        self.data_label_maps = self.data / "label_maps"

        # --- Notebooks ---
        self.notebooks = self.root / "notebooks"

        # --- Source ---
        self.src = self.root / "src"

        # --- Experiments ---
        self.experiments = self.root / "experiments"
        self.experiments_baseline = self.experiments / "baseline_results"
        self.experiments_transformer = self.experiments / "transformer_results"
        self.experiments_ablation = self.experiments / "ablation_results"
        self.experiments_external = self.experiments / "external_evaluation"

        # --- Outputs ---
        self.outputs = self.root / "outputs"
        self.outputs_models = self.outputs / "models"
        self.outputs_predictions = self.outputs / "predictions"
        self.outputs_explanations = self.outputs / "explanations"
        self.outputs_plots = self.outputs / "plots"
        self.outputs_reports = self.outputs / "reports"

        # --- Logs ---
        self.logs = self.root / "logs"

        # --- API ---
        self.api = self.root / "api"

        # --- Frontend ---
        self.frontend = self.root / "frontend"

        # --- Tests ---
        self.tests = self.root / "tests"

        # --- Docs ---
        self.docs = self.root / "docs"

        # --- Scripts ---
        self.scripts = self.root / "scripts"

    def ensure_dirs(self) -> None:
        """Create all project directories if they don't exist.

        This is safe to call multiple times — existing directories
        are not modified.
        """
        dirs_to_create = [
            self.configs,
            self.data_raw_uspto3m,
            self.data_raw_hupd,
            self.data_raw_bigpatent,
            self.data_interim,
            self.data_processed,
            self.data_label_maps,
            self.notebooks,
            self.experiments_baseline,
            self.experiments_transformer,
            self.experiments_ablation,
            self.experiments_external,
            self.outputs_models,
            self.outputs_predictions,
            self.outputs_explanations,
            self.outputs_plots,
            self.outputs_reports,
            self.logs,
            self.scripts,
        ]

        for directory in dirs_to_create:
            directory.mkdir(parents=True, exist_ok=True)

    def summary(self) -> dict[str, str]:
        """Return a dictionary of all paths for logging/debugging.

        Returns:
            Dictionary mapping path names to their resolved string values.
        """
        return {
            attr: str(getattr(self, attr))
            for attr in sorted(vars(self))
            if isinstance(getattr(self, attr), Path)
        }


# ============================================================
# Module-level convenience instance
# ============================================================
# Import this directly: from src.utils.paths import PATHS
PATHS = ProjectPaths()
