"""PatentClass-HAT configuration loader.

Loads and merges YAML configuration files into a single, type-safe
configuration object. Supports environment variable overrides.

Usage:
    from src.utils.config import load_config, get_device

    config = load_config()
    device = get_device(config)
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field


# ============================================================
# Configuration directory (relative to project root)
# ============================================================
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_CONFIG_DIR = _PROJECT_ROOT / "configs"


# ============================================================
# Pydantic models for type-safe configuration
# ============================================================

class LoggingConfig(BaseModel):
    """Logging settings."""
    level: str = "INFO"
    log_dir: str = "logs"
    console: bool = True
    file: bool = True
    format: str = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    date_format: str = "%Y-%m-%d %H:%M:%S"


class ProjectConfig(BaseModel):
    """Top-level project metadata."""
    name: str = "PatentClass-HAT"
    full_title: str = ""
    version: str = "0.1.0"
    description: str = ""


class TrackingConfig(BaseModel):
    """Experiment tracking settings."""
    backend: str = "mlflow"
    mlflow: dict[str, Any] = Field(default_factory=dict)
    tensorboard: dict[str, Any] = Field(default_factory=dict)


class BaseConfig(BaseModel):
    """Root configuration object that holds all merged settings.

    This is intentionally flexible (extra fields allowed) so that
    data_config, training_config, and model_config keys are all
    preserved after merging.
    """
    project: ProjectConfig = Field(default_factory=ProjectConfig)
    seed: int = 42
    device: str = "auto"
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    tracking: TrackingConfig = Field(default_factory=TrackingConfig)

    class Config:
        extra = "allow"  # Allow arbitrary keys from other configs


# ============================================================
# YAML loading helpers
# ============================================================

def _load_yaml(path: Path) -> dict[str, Any]:
    """Load a single YAML file and return its contents as a dict.

    Args:
        path: Absolute or relative path to the YAML file.

    Returns:
        Dictionary of configuration values.

    Raises:
        FileNotFoundError: If the YAML file does not exist.
        yaml.YAMLError: If the YAML is malformed.
    """
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    # yaml.safe_load returns None for empty files
    return data if data is not None else {}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge two dictionaries.

    Values in `override` take precedence. Nested dicts are merged
    recursively rather than replaced wholesale.

    Args:
        base: The base dictionary.
        override: The dictionary whose values take priority.

    Returns:
        A new merged dictionary.
    """
    merged = base.copy()
    for key, value in override.items():
        if (
            key in merged
            and isinstance(merged[key], dict)
            and isinstance(value, dict)
        ):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


# ============================================================
# Public API
# ============================================================

def load_config(
    config_dir: Optional[Path] = None,
    config_files: Optional[list[str]] = None,
) -> BaseConfig:
    """Load and merge all configuration files.

    Files are merged in order, with later files overriding earlier ones:
    1. base_config.yaml
    2. data_config.yaml
    3. training_config.yaml
    4. model_config.yaml

    Environment variable overrides:
        - PATENTCLASS_DEVICE  → config.device
        - PATENTCLASS_SEED    → config.seed

    Args:
        config_dir: Path to the configuration directory.
                    Defaults to <project_root>/configs.
        config_files: List of YAML filenames to load (in order).
                      Defaults to the standard four config files.

    Returns:
        A fully merged BaseConfig instance.
    """
    if config_dir is None:
        config_dir = _CONFIG_DIR

    if config_files is None:
        config_files = [
            "base_config.yaml",
            "data_config.yaml",
            "training_config.yaml",
            "model_config.yaml",
        ]

    # Merge all config files in order
    merged: dict[str, Any] = {}
    for filename in config_files:
        filepath = config_dir / filename
        if filepath.exists():
            file_data = _load_yaml(filepath)
            merged = _deep_merge(merged, file_data)

    # Apply environment variable overrides
    env_device = os.environ.get("PATENTCLASS_DEVICE")
    if env_device:
        merged["device"] = env_device

    env_seed = os.environ.get("PATENTCLASS_SEED")
    if env_seed:
        merged["seed"] = int(env_seed)

    return BaseConfig(**merged)


def get_device(config: Optional[BaseConfig] = None) -> str:
    """Resolve the compute device string.

    Args:
        config: Configuration object. If None, loads default config.

    Returns:
        "cuda" if available and requested, otherwise "cpu".
    """
    if config is None:
        config = load_config()

    device = config.device

    if device == "auto":
        try:
            import torch
            return "cuda" if torch.cuda.is_available() else "cpu"
        except ImportError:
            return "cpu"

    return device
