"""PatentClass-HAT reproducibility utilities.

Sets deterministic random seeds for Python, NumPy, and PyTorch to ensure
reproducible experiments. Also configures CUDA deterministic behavior
when available.

Usage:
    from src.utils.seed import set_seed

    set_seed(42)

Note:
    Full determinism on GPU requires `torch.use_deterministic_algorithms(True)`,
    which may cause errors with some operations (e.g., scatter, upsample).
    We enable it by default but provide a flag to disable it.
"""
from __future__ import annotations

import os
import random
import logging
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)


def set_seed(
    seed: int = 42,
    deterministic_cuda: bool = True,
    warn_only: bool = True,
) -> None:
    """Set random seeds for reproducibility across all frameworks.

    This function sets seeds for:
    - Python's built-in `random` module
    - NumPy's random number generator
    - PyTorch CPU and CUDA random number generators

    Args:
        seed: The random seed value. Must be a non-negative integer.
        deterministic_cuda: If True, enables CUDA deterministic algorithms.
            This may slow down training but ensures reproducible results.
        warn_only: If True, uses `warn_only` mode for deterministic algorithms
            (allows non-deterministic ops with a warning instead of an error).

    Raises:
        ValueError: If seed is negative.

    Example:
        >>> set_seed(42)
        >>> random.random()  # Always returns the same value
        0.6394267984578837
    """
    if seed < 0:
        raise ValueError(f"Seed must be non-negative, got {seed}")

    # Python built-in random
    random.seed(seed)

    # NumPy
    np.random.seed(seed)

    # Environment variable (used by some libraries)
    os.environ["PYTHONHASHSEED"] = str(seed)

    # PyTorch (optional import — project works without it for baselines)
    try:
        import torch

        torch.manual_seed(seed)

        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)
            torch.cuda.manual_seed_all(seed)  # For multi-GPU

            if deterministic_cuda:
                # Enable deterministic CUDA operations
                torch.backends.cudnn.deterministic = True
                torch.backends.cudnn.benchmark = False

                # PyTorch >= 1.8: use_deterministic_algorithms
                try:
                    torch.use_deterministic_algorithms(True, warn_only=warn_only)
                except TypeError:
                    # Older PyTorch versions don't have warn_only
                    torch.use_deterministic_algorithms(True)

                logger.debug(
                    "CUDA deterministic mode enabled (seed=%d, warn_only=%s)",
                    seed,
                    warn_only,
                )
            else:
                # Allow cuDNN auto-tuner for faster training
                torch.backends.cudnn.benchmark = True
                logger.debug(
                    "CUDA non-deterministic mode (benchmark=True, seed=%d)",
                    seed,
                )

        logger.info("Random seed set to %d (PyTorch available)", seed)

    except ImportError:
        logger.info("Random seed set to %d (PyTorch not installed)", seed)


def get_seed_info() -> dict:
    """Return current seed-related configuration for logging.

    Returns:
        Dictionary with seed-related environment and library info.
    """
    info = {
        "python_hash_seed": os.environ.get("PYTHONHASHSEED", "not set"),
    }

    try:
        import torch
        info["torch_initial_seed"] = torch.initial_seed()
        info["cuda_available"] = torch.cuda.is_available()
        if torch.cuda.is_available():
            info["cudnn_deterministic"] = torch.backends.cudnn.deterministic
            info["cudnn_benchmark"] = torch.backends.cudnn.benchmark
    except ImportError:
        info["torch_available"] = False

    return info
