"""PatentClass-HAT structured logging utilities.

Provides consistent, configurable logging with both console and file
handlers. Log files are timestamped and stored in the project's log
directory.

Usage:
    from src.utils.logging_utils import setup_logging, get_logger

    setup_logging()                    # Call once at application start
    logger = get_logger(__name__)      # Get a named logger
    logger.info("Training started")
"""
from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


# Track whether logging has been configured
_logging_configured = False


def setup_logging(
    level: str = "INFO",
    log_dir: Optional[str | Path] = None,
    console: bool = True,
    file: bool = True,
    log_format: Optional[str] = None,
    date_format: Optional[str] = None,
    log_filename: Optional[str] = None,
) -> None:
    """Configure the root logger with console and/or file handlers.

    This function should be called once at the start of the application.
    Subsequent calls will add additional handlers (use `reset_logging`
    first if reconfiguration is needed).

    Args:
        level: Logging level string (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        log_dir: Directory for log files. Defaults to <project_root>/logs.
        console: Whether to add a console (stderr) handler.
        file: Whether to add a file handler.
        log_format: Custom log format string.
        date_format: Custom date format string.
        log_filename: Custom log filename. Defaults to timestamped name.
    """
    global _logging_configured

    if log_format is None:
        log_format = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"

    if date_format is None:
        date_format = "%Y-%m-%d %H:%M:%S"

    # Resolve log level
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)

    # Create formatter
    formatter = logging.Formatter(fmt=log_format, datefmt=date_format)

    # --- Console handler ---
    if console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(numeric_level)
        console_handler.setFormatter(formatter)
        root_logger.addHandler(console_handler)

    # --- File handler ---
    if file:
        if log_dir is None:
            # Default: <project_root>/logs
            log_dir = Path(__file__).resolve().parent.parent.parent / "logs"
        else:
            log_dir = Path(log_dir)

        log_dir.mkdir(parents=True, exist_ok=True)

        if log_filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_filename = f"patentclass_hat_{timestamp}.log"

        log_path = log_dir / log_filename

        file_handler = logging.FileHandler(
            log_path, mode="a", encoding="utf-8"
        )
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    _logging_configured = True


def setup_logging_from_config(config: dict | object) -> None:
    """Configure logging from a configuration object or dict.

    Accepts either a dict (from YAML) or a Pydantic model with
    a `logging` attribute.

    Args:
        config: Configuration object with logging settings.
    """
    # Extract logging config
    if hasattr(config, "logging"):
        log_cfg = config.logging
        if hasattr(log_cfg, "model_dump"):
            log_cfg = log_cfg.model_dump()
        elif hasattr(log_cfg, "dict"):
            log_cfg = log_cfg.dict()
    elif isinstance(config, dict) and "logging" in config:
        log_cfg = config["logging"]
    else:
        log_cfg = {}

    setup_logging(
        level=log_cfg.get("level", "INFO"),
        log_dir=log_cfg.get("log_dir"),
        console=log_cfg.get("console", True),
        file=log_cfg.get("file", True),
        log_format=log_cfg.get("format"),
        date_format=log_cfg.get("date_format"),
    )


def get_logger(name: str) -> logging.Logger:
    """Get a named logger instance.

    If logging has not been configured yet, sets up a basic
    console-only configuration to avoid silent failures.

    Args:
        name: Logger name (typically ``__name__``).

    Returns:
        A configured logging.Logger instance.
    """
    global _logging_configured

    if not _logging_configured:
        # Fallback: basic console logging so messages aren't lost
        setup_logging(level="INFO", file=False)

    return logging.getLogger(name)


def reset_logging() -> None:
    """Remove all handlers from the root logger.

    Useful for testing or reconfiguring logging mid-run.
    """
    global _logging_configured

    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
        handler.close()

    _logging_configured = False
