"""Tests for environment validation (scripts/validate_env.py).

These tests verify that the current Python environment meets the
minimum requirements for running PatentClass-HAT.
"""
from __future__ import annotations

import sys
import importlib

import pytest


class TestPythonVersion:
    """Verify Python version requirements."""

    def test_python_3_10_or_higher(self) -> None:
        """Python version must be 3.10+."""
        assert sys.version_info >= (3, 10), (
            f"Python 3.10+ required, got {sys.version}"
        )

    def test_python_below_3_13(self) -> None:
        """Python version should be below 3.13 for compatibility."""
        assert sys.version_info < (3, 13), (
            f"Python 3.12 or below recommended, got {sys.version}"
        )


class TestCorePackages:
    """Verify that core packages are importable."""

    @pytest.mark.parametrize(
        "package_name",
        [
            "yaml",
            "pydantic",
            "numpy",
            "pandas",
        ],
    )
    def test_core_package_importable(self, package_name: str) -> None:
        """Core packages must be importable."""
        try:
            importlib.import_module(package_name)
        except ImportError:
            pytest.fail(f"Required package '{package_name}' is not installed")


class TestOptionalPackages:
    """Verify optional packages (skip if not installed)."""

    @pytest.mark.parametrize(
        "package_name",
        [
            "torch",
            "transformers",
            "sklearn",
            "matplotlib",
        ],
    )
    def test_optional_package(self, package_name: str) -> None:
        """Optional packages should be importable if installed."""
        try:
            importlib.import_module(package_name)
        except ImportError:
            pytest.skip(f"Optional package '{package_name}' not installed")
