"""Tests for preprocessing modules."""
import numpy as np
import pytest
from src.preprocessing import clean_patent_text, extract_sections, CPCLabelEncoder, Chunker

def test_clean_patent_text():
    raw = "  <br> This is <b>HTML</b> \n\t  and   spaces! \x00 "
    cleaned = clean_patent_text(raw, lowercase=True)
    assert cleaned == "this is html and spaces!"
    
    truncated = clean_patent_text("abcde", max_length=3)
    assert truncated == "abc"

def test_extract_sections():
    raw_text = (
        "My Patent Title\n"
        "ABSTRACT\nThis is the abstract.\n"
        "BACKGROUND OF THE INVENTION\nThis is the description.\n"
        "WHAT IS CLAIMED IS\n1. A method."
    )
    sections = extract_sections(raw_text)
    assert sections["title"] == "My Patent Title"
    assert sections["abstract"] == "This is the abstract."
    assert sections["description"] == "This is the description."
    assert sections["claims"] == "1. A method."
    
def test_extract_sections_fallback():
    raw_text = "Just a bunch of text without any headers."
    sections = extract_sections(raw_text)
    assert sections["title"] == ""
    assert sections["abstract"] == ""
    assert sections["claims"] == ""
    assert sections["description"] == "Just a bunch of text without any headers."

def test_cpc_label_encoder():
    encoder = CPCLabelEncoder(min_frequency=2, primary_level="subclass")
    
    # Mock labels list
    labels = [
        "G06N3/08, G06F",
        ["G06N", "H04L"],
        "G06N, A01B"
    ]
    
    encoder.fit(labels)
    # G06N appears 3 times -> kept
    # G06F appears 1 time -> dropped
    # H04L appears 1 time -> dropped
    # A01B appears 1 time -> dropped
    
    assert len(encoder.vocab) == 1
    assert "G06N" in encoder.vocab
    
    vector = encoder.encode("G06N, H04L")
    assert vector.shape == (1,)
    assert vector[encoder.vocab["G06N"]] == 1.0

def test_chunker():
    chunker = Chunker(max_length=3, overlap=1, use_words=True)
    text = "this is a long sentence for testing"
    chunks = chunker.chunk_text(text)
    
    assert chunks[0] == "this is a"
    assert chunks[1] == "a long sentence"
    assert chunks[2] == "sentence for testing"
    assert chunks[3] == "testing"
    assert len(chunks) == 4
