"""Tests for the path management utility (src.utils.paths)."""
from __future__ import annotations

from pathlib import Path

import pytest

from src.utils.paths import ProjectPaths, PATHS


class TestProjectPaths:
    """Tests for ProjectPaths."""

    def test_root_is_path(self) -> None:
        """Root is a Path object."""
        paths = ProjectPaths()
        assert isinstance(paths.root, Path)

    def test_data_subdirectories(self) -> None:
        """All data subdirectory paths are under data/."""
        paths = ProjectPaths()
        assert paths.data_raw.parent == paths.data
        assert paths.data_interim.parent == paths.data
        assert paths.data_processed.parent == paths.data
        assert paths.data_label_maps.parent == paths.data

    def test_dataset_paths(self) -> None:
        """Dataset-specific paths are under data/raw/."""
        paths = ProjectPaths()
        assert paths.data_raw_uspto3m.parent == paths.data_raw
        assert paths.data_raw_hupd.parent == paths.data_raw
        assert paths.data_raw_bigpatent.parent == paths.data_raw

    def test_custom_root(self, tmp_path: Path) -> None:
        """Custom root overrides all paths."""
        paths = ProjectPaths(root=tmp_path)
        assert paths.root == tmp_path
        assert paths.configs == tmp_path / "configs"
        assert paths.data == tmp_path / "data"

    def test_ensure_dirs_creates_missing(self, tmp_path: Path) -> None:
        """ensure_dirs creates all directories."""
        paths = ProjectPaths(root=tmp_path)
        paths.ensure_dirs()
        assert paths.data_raw_uspto3m.exists()
        assert paths.outputs_models.exists()
        assert paths.logs.exists()

    def test_ensure_dirs_idempotent(self, tmp_path: Path) -> None:
        """Calling ensure_dirs twice does not raise."""
        paths = ProjectPaths(root=tmp_path)
        paths.ensure_dirs()
        paths.ensure_dirs()  # Should not raise

    def test_summary_returns_dict(self) -> None:
        """summary() returns a non-empty dictionary of path strings."""
        paths = ProjectPaths()
        summary = paths.summary()
        assert isinstance(summary, dict)
        assert len(summary) > 0
        assert all(isinstance(v, str) for v in summary.values())

    def test_env_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """PATENTCLASS_ROOT env var overrides the default root."""
        monkeypatch.setenv("PATENTCLASS_ROOT", str(tmp_path))
        paths = ProjectPaths()
        assert paths.root == tmp_path


class TestGlobalPaths:
    """Tests for the module-level PATHS instance."""

    def test_paths_is_project_paths(self) -> None:
        """PATHS is a ProjectPaths instance."""
        assert isinstance(PATHS, ProjectPaths)

    def test_paths_root_exists(self) -> None:
        """PATHS root points to an existing directory."""
        # The root should exist since it's derived from this file's location
        assert PATHS.root.exists()
