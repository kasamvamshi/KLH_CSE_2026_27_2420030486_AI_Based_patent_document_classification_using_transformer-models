"""Tests for the seed utility (src.utils.seed)."""
from __future__ import annotations

import random

import numpy as np
import pytest

from src.utils.seed import set_seed, get_seed_info


class TestSetSeed:
    """Tests for set_seed."""

    def test_python_random_reproducibility(self) -> None:
        """Python random produces the same sequence after set_seed."""
        set_seed(42)
        values_a = [random.random() for _ in range(5)]

        set_seed(42)
        values_b = [random.random() for _ in range(5)]

        assert values_a == values_b

    def test_numpy_reproducibility(self) -> None:
        """NumPy random produces the same sequence after set_seed."""
        set_seed(42)
        arr_a = np.random.rand(5)

        set_seed(42)
        arr_b = np.random.rand(5)

        np.testing.assert_array_equal(arr_a, arr_b)

    def test_different_seeds_differ(self) -> None:
        """Different seeds produce different random sequences."""
        set_seed(42)
        val_a = random.random()

        set_seed(99)
        val_b = random.random()

        assert val_a != val_b

    def test_negative_seed_raises(self) -> None:
        """Negative seed raises ValueError."""
        with pytest.raises(ValueError, match="non-negative"):
            set_seed(-1)

    def test_zero_seed_works(self) -> None:
        """Zero is a valid seed value."""
        set_seed(0)  # Should not raise
        _ = random.random()


class TestGetSeedInfo:
    """Tests for get_seed_info."""

    def test_returns_dict(self) -> None:
        """get_seed_info returns a dictionary."""
        set_seed(42)
        info = get_seed_info()
        assert isinstance(info, dict)
        assert "python_hash_seed" in info

    def test_hash_seed_set(self) -> None:
        """PYTHONHASHSEED is set after calling set_seed."""
        set_seed(42)
        info = get_seed_info()
        assert info["python_hash_seed"] == "42"
