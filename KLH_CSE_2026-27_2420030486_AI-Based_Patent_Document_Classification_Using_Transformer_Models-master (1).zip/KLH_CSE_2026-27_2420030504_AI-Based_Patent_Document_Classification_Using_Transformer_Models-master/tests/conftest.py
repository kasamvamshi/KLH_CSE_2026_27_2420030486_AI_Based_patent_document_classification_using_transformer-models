"""Shared pytest fixtures for PatentClass-HAT tests."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Ensure the project root is on sys.path so that `src` is importable
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))


@pytest.fixture
def project_root() -> Path:
    """Return the project root directory."""
    return _PROJECT_ROOT


@pytest.fixture
def config_dir(project_root: Path) -> Path:
    """Return the configs directory."""
    return project_root / "configs"


@pytest.fixture
def tmp_config_dir(tmp_path: Path) -> Path:
    """Create a temporary config directory with minimal YAML files.

    Returns:
        Path to a temp directory containing test config files.
    """
    config_dir = tmp_path / "configs"
    config_dir.mkdir()

    # Minimal base config for testing
    base_yaml = config_dir / "base_config.yaml"
    base_yaml.write_text(
        "project:\n"
        "  name: TestProject\n"
        "  version: '0.0.1'\n"
        "seed: 123\n"
        "device: cpu\n"
        "logging:\n"
        "  level: DEBUG\n"
        "  console: true\n"
        "  file: false\n",
        encoding="utf-8",
    )

    # Minimal data config
    data_yaml = config_dir / "data_config.yaml"
    data_yaml.write_text(
        "datasets:\n"
        "  test_dataset:\n"
        "    name: TestData\n"
        "    role: test\n",
        encoding="utf-8",
    )

    return config_dir
