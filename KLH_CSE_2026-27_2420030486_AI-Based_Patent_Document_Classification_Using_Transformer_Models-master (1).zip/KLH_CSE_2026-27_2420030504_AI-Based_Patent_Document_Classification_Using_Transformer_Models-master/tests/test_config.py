"""Tests for the configuration loader (src.utils.config)."""
from __future__ import annotations

from pathlib import Path

import pytest

from src.utils.config import load_config, get_device, _deep_merge, _load_yaml


class TestDeepMerge:
    """Tests for the _deep_merge helper."""

    def test_flat_merge(self) -> None:
        """Non-overlapping keys are combined."""
        base = {"a": 1, "b": 2}
        override = {"c": 3}
        result = _deep_merge(base, override)
        assert result == {"a": 1, "b": 2, "c": 3}

    def test_override_value(self) -> None:
        """Override values replace base values."""
        base = {"a": 1}
        override = {"a": 99}
        result = _deep_merge(base, override)
        assert result["a"] == 99

    def test_nested_merge(self) -> None:
        """Nested dicts are merged recursively."""
        base = {"a": {"x": 1, "y": 2}}
        override = {"a": {"y": 99, "z": 3}}
        result = _deep_merge(base, override)
        assert result == {"a": {"x": 1, "y": 99, "z": 3}}

    def test_base_not_mutated(self) -> None:
        """Original base dict is not modified."""
        base = {"a": 1}
        override = {"a": 2}
        _deep_merge(base, override)
        assert base["a"] == 1


class TestLoadYaml:
    """Tests for _load_yaml."""

    def test_load_valid_yaml(self, tmp_path: Path) -> None:
        """Valid YAML file is loaded correctly."""
        yaml_file = tmp_path / "test.yaml"
        yaml_file.write_text("key: value\nnested:\n  a: 1\n", encoding="utf-8")
        result = _load_yaml(yaml_file)
        assert result == {"key": "value", "nested": {"a": 1}}

    def test_load_empty_yaml(self, tmp_path: Path) -> None:
        """Empty YAML file returns empty dict."""
        yaml_file = tmp_path / "empty.yaml"
        yaml_file.write_text("", encoding="utf-8")
        result = _load_yaml(yaml_file)
        assert result == {}

    def test_load_missing_file(self, tmp_path: Path) -> None:
        """Missing file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            _load_yaml(tmp_path / "nonexistent.yaml")


class TestLoadConfig:
    """Tests for load_config."""

    def test_loads_from_temp_dir(self, tmp_config_dir: Path) -> None:
        """Config loads successfully from a temp directory."""
        config = load_config(config_dir=tmp_config_dir)
        assert config.project.name == "TestProject"
        assert config.seed == 123
        assert config.device == "cpu"

    def test_default_config_loads(self, config_dir: Path) -> None:
        """Default project configs load without errors."""
        config = load_config(config_dir=config_dir)
        assert config.project.name == "PatentClass-HAT"
        assert config.seed == 42

    def test_env_override_device(
        self, tmp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """PATENTCLASS_DEVICE env var overrides config device."""
        monkeypatch.setenv("PATENTCLASS_DEVICE", "cpu")
        config = load_config(config_dir=tmp_config_dir)
        assert config.device == "cpu"

    def test_env_override_seed(
        self, tmp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """PATENTCLASS_SEED env var overrides config seed."""
        monkeypatch.setenv("PATENTCLASS_SEED", "999")
        config = load_config(config_dir=tmp_config_dir)
        assert config.seed == 999

    def test_missing_config_files_uses_defaults(self, tmp_path: Path) -> None:
        """When config files don't exist, defaults are used."""
        empty_dir = tmp_path / "empty_configs"
        empty_dir.mkdir()
        config = load_config(config_dir=empty_dir)
        assert config.project.name == "PatentClass-HAT"  # Pydantic default
        assert config.seed == 42


class TestGetDevice:
    """Tests for get_device."""

    def test_explicit_cpu(self, tmp_config_dir: Path) -> None:
        """Explicit 'cpu' device is returned as-is."""
        config = load_config(config_dir=tmp_config_dir)
        config.device = "cpu"
        assert get_device(config) == "cpu"

    def test_auto_resolves(self, tmp_config_dir: Path) -> None:
        """'auto' resolves to either 'cuda' or 'cpu'."""
        config = load_config(config_dir=tmp_config_dir)
        config.device = "auto"
        device = get_device(config)
        assert device in ("cuda", "cpu")
