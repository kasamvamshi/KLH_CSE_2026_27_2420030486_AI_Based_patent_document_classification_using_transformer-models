from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import torch
from transformers import AutoTokenizer
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.models.hierarchical_transformer import PatentClassHAT
from src.preprocessing.hierarchical_encoder import HierarchicalCPCLabelEncoder

app = FastAPI(title="PatentClass-HAT Inference API")

class PatentInput(BaseModel):
    title: str
    abstract: str
    claims: str
    description: str

class PredictResponse(BaseModel):
    predictions: dict
    attention_weights: dict

# Global state for lazy loading
model = None
tokenizer = None
encoder = None
device = torch.device("cpu")

def load_resources():
    global model, tokenizer, encoder
    if model is not None:
        return
        
    model_dir = PROJECT_ROOT / "checkpoints" / "debug_run_hierarchical"
    
    # Check if we have trained the hierarchical model
    if not (model_dir / "model_weights.pt").exists():
        raise RuntimeError(f"Trained model not found at {model_dir}. Run training first.")
        
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(model_dir / "tokenizer"))
    
    # Load Label Encoder
    with open(model_dir / "label_encoder.json", "r") as f:
        encoder_data = json.load(f)
    
    # Reconstruct the HierarchicalCPCLabelEncoder
    encoder = HierarchicalCPCLabelEncoder()
    # It requires 'min_frequency' etc. The saved JSON contains the state of the 3 encoders.
    # Since we don't have a direct load_state for Hierarchical, we instantiate them manually
    for level in ["section", "class", "subclass"]:
        encoder.encoders[level].vocab = encoder_data["encoders"][level]["vocab"]
        encoder.encoders[level].inverse_vocab = {v: k for k, v in encoder.encoders[level].vocab.items()}
    encoder.is_fitted = True
    
    hierarchical_dims = {
        "num_sections": len(encoder.encoders["section"].vocab),
        "num_classes": len(encoder.encoders["class"].vocab),
        "num_subclasses": len(encoder.encoders["subclass"].vocab)
    }
    
    # Load Model
    model = PatentClassHAT(
        model_name="prajjwal1/bert-tiny",
        hierarchical_dims=hierarchical_dims,
        chunk_pooling="attention",
        classifier_type="hierarchical"
    )
    model.load_state_dict(torch.load(model_dir / "model_weights.pt", map_location=device))
    model.eval()
    model.to(device)

def get_top_k(logits, vocab, k=3):
    probs = torch.sigmoid(logits).squeeze(0).cpu().numpy()
    top_indices = probs.argsort()[-k:][::-1]
    results = []
    inv_vocab = {v: k for k, v in vocab.items()}
    for idx in top_indices:
        if probs[idx] > 0.1: # Threshold
            results.append({"label": inv_vocab.get(idx, "UNK"), "score": float(probs[idx])})
    return results

@app.on_event("startup")
def startup_event():
    try:
        load_resources()
    except Exception as e:
        print(f"Warning: Failed to load model resources on startup: {e}")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict", response_model=PredictResponse)
def predict(patent: PatentInput):
    load_resources()
    
    max_length = 64 # From debug config
    
    # Tokenize short sections
    enc_title = tokenizer(patent.title, padding="max_length", truncation=True, max_length=max_length, return_tensors="pt")
    enc_abs = tokenizer(patent.abstract, padding="max_length", truncation=True, max_length=max_length, return_tensors="pt")
    
    # Simple chunking for long sections
    from src.preprocessing.chunking import Chunker
    chunker = Chunker(max_length=max_length, overlap=16, use_words=True)
    
    claims_chunks = chunker.chunk_text(patent.claims)[:16] or [""]
    desc_chunks = chunker.chunk_text(patent.description)[:32] or [""]
    
    enc_claims = tokenizer(claims_chunks, padding="max_length", truncation=True, max_length=max_length, return_tensors="pt")
    enc_desc = tokenizer(desc_chunks, padding="max_length", truncation=True, max_length=max_length, return_tensors="pt")
    
    # Format inputs for model (Batch size 1)
    # claims shape needs to be (1, num_chunks, seq_len)
    inputs = {
        "title_input_ids": enc_title["input_ids"],
        "title_attention_mask": enc_title["attention_mask"],
        "abstract_input_ids": enc_abs["input_ids"],
        "abstract_attention_mask": enc_abs["attention_mask"],
        "claims_input_ids": enc_claims["input_ids"].unsqueeze(0),
        "claims_attention_mask": enc_claims["attention_mask"].unsqueeze(0),
        "desc_input_ids": enc_desc["input_ids"].unsqueeze(0),
        "desc_attention_mask": enc_desc["attention_mask"].unsqueeze(0),
    }
    
    with torch.no_grad():
        outputs = model(**inputs)
        
    logits_section = outputs["logits_section"]
    logits_class = outputs["logits_class"]
    logits_subclass = outputs["logits_subclass"]
    attn_weights = outputs.get("fusion_attention")
    
    predictions = {
        "section": get_top_k(logits_section, encoder.encoders["section"].vocab, k=3),
        "class": get_top_k(logits_class, encoder.encoders["class"].vocab, k=3),
        "subclass": get_top_k(logits_subclass, encoder.encoders["subclass"].vocab, k=3),
    }
    
    attention = {}
    if attn_weights is not None:
        weights_list = attn_weights.cpu().numpy().tolist()[0]
        sections = ["Title", "Abstract", "Claims", "Description"]
        for q_idx, query_sec in enumerate(sections):
            attention[query_sec] = {}
            for k_idx, key_sec in enumerate(sections):
                attention[query_sec][key_sec] = weights_list[q_idx][k_idx]
                
    return PredictResponse(
        predictions=predictions,
        attention_weights=attention
    )
