# Known Limitations

## Current Limitations (Phase 0)

This section will be updated as limitations are discovered during development.

### Data Limitations
- Dataset schemas have not been inspected yet (Phase 1)
- CPC label availability in BIGPATENT is unverified
- Cross-dataset label alignment may be incomplete
- Patent family deduplication may not be fully achievable

### Model Limitations
- Transformer token limit (512) requires chunking, which may lose cross-chunk context
- Section attention assumes sections are available; missing sections require masking
- Hierarchical classification adds complexity and may not always improve over flat
- Rare CPC codes may remain difficult to predict despite imbalance handling

### Evaluation Limitations
- Micro-F1 can be dominated by frequent labels
- Macro-F1 can be unstable with very rare labels
- External evaluation depends on label compatibility between datasets
- Explainability faithfulness is difficult to measure objectively

### Engineering Limitations
- GPU memory constrains batch size and sequence length
- Full dataset training may require significant compute time
- Mixed precision may introduce numerical instabilities in edge cases

### Research Limitations
- No claim of state-of-the-art without thorough comparison
- Section attention is one of several possible approaches
- Results may vary with different encoder models
- Reproducibility depends on exact library versions
