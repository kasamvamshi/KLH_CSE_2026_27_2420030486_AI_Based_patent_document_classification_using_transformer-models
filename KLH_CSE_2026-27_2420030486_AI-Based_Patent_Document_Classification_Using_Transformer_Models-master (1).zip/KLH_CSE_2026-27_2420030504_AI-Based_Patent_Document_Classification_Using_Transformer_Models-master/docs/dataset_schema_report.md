# Phase 1: Dataset Acquisition & Schema Audit

This document contains the audit results for the three patent datasets used in PatentClass-HAT.

## 1. USPTO-3M
* **Source:** `MalavP/USPTO-3M` (Hugging Face)
* **Role:** Primary supervised training and testing.
* **Schema (Actual):**
  - `id` (string): Unique patent identifier
  - `date` (string): Publication date
  - `text` (string): The concatenated patent text
  - `cpc_ids` (string): Comma-separated CPC labels
* **Audit Findings:** The `text` field contains the full patent document. We will need to parse/regex this field to extract specific sections (Title, Abstract, Claims, Description) if they are not explicitly separated in the raw data, or use it as a unified long-document sequence.

## 2. HUPD (Harvard USPTO Patent Dataset)
* **Source:** `HUPD/hupd` (Hugging Face)
* **Role:** External evaluation and domain-shift testing.
* **Schema (Actual):**
  - `patent_number` (string): Unique identifier
  - `title`, `abstract`, `claims`, `background`, `summary`, `description` (strings): Explicitly separated patent sections.
  - `cpc_label` (list of strings): Hierarchical CPC labels.
  - `ipc_label` (list of strings): IPC labels.
  - `decision` (string): Accepted/Rejected status.
  - `filing_date`, `date_published` (strings): Timestamps.
* **Audit Findings:** HUPD is extremely well-structured for Section-Aware Attention, providing pre-chunked sections. We will use `title`, `abstract`, `claims`, and `description` to evaluate our section-aware architecture.

## 3. BIGPATENT
* **Source:** `NortheasternUniversity/big_patent` (Hugging Face)
* **Role:** Auxiliary / Domain-Adaptive Pretraining.
* **Schema (Actual):**
  - `description` (string): Full detailed description of the patent.
  - `abstract` (string): The summary abstract.
* **Audit Findings:** BIGPATENT **does not contain multi-label CPC trees** in its row schema. It only groups the dataset into 9 broad CPC sections ('a' through 'y') at the folder/config level. Therefore, **we cannot use BIGPATENT for supervised CPC classification** without significant external label mining. It will be restricted to domain-adaptive pretraining (MLM) or summarization tasks.

---

## Unified Schema Mapping

To process these heterogeneous datasets through the PatentClass-HAT data loaders, we will map all raw datasets into the following unified schema:

| Unified Field | Type | Mapped from USPTO-3M | Mapped from HUPD | Mapped from BIGPATENT |
|---|---|---|---|---|
| `doc_id` | str | `id` | `patent_number` | UUID (Generated) |
| `title` | str | Parsed from `text` | `title` | N/A |
| `abstract` | str | Parsed from `text` | `abstract` | `abstract` |
| `claims` | str | Parsed from `text` | `claims` | N/A |
| `description` | str | Parsed from `text` | `description` | `description` |
| `cpc_labels` | list[str] | Parsed from `cpc_ids` | `cpc_label` | Config Name (e.g., 'a') |

## Phase 1 Acceptance Criteria Verification
- [x] All available fields documented? Yes.
- [x] No field assumed without verification? Yes, exact fields confirmed via Hugging Face index.
- [x] BIGPATENT labels verified? Yes, discovered they are missing in the row-level schema.
- [x] HUPD evaluation role defined? Yes.
