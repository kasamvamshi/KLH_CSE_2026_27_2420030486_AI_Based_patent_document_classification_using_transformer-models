# Methodology

## Research Problem

Patent documents are long, section-structured, and associated with multiple hierarchical CPC codes. Existing approaches often truncate long documents, ignore section boundaries, use flat classification, and provide weak explanations.

## Proposed Approach: PatentClass-HAT

PatentClass-HAT addresses these limitations through:

1. **Section-Aware Document Representation:** Encoding title, abstract, claims, and description separately to preserve structural information.

2. **Long-Document Processing:** Splitting sections into overlapping chunks within the Transformer token limit and aggregating via attention-weighted pooling.

3. **Learnable Section Attention:** A multi-head attention mechanism that learns the importance of each patent section for CPC classification.

4. **Hierarchical CPC Prediction:** Leveraging the CPC tree structure (section → class → subclass → group) for coarse-to-fine classification.

5. **Imbalance-Aware Learning:** Addressing head/tail label distribution through focal loss, weighted BCE, and threshold tuning.

6. **Explainable Predictions:** Providing section importance, chunk-level evidence, and token-level attribution for each predicted CPC code.

## Mathematical Formulation

> Detailed formulations will be added during Phases 5–9 as each component is implemented and validated.

### Section Encoding

For each section $s \in \{title, abstract, claims, description\}$:

$$h_s = \text{Aggregate}(\text{Encoder}(\text{chunks}(s)))$$

### Section Attention

$$\alpha_s = \text{softmax}(W_2 \cdot \tanh(W_1 \cdot h_s + b_1) + b_2)$$

$$d = \sum_s \alpha_s \cdot h_s$$

### Classification

$$\hat{y} = \sigma(W_c \cdot d + b_c)$$

## Evaluation Strategy

- Internal evaluation on USPTO-3M test set
- External evaluation on HUPD
- Ablation studies removing each component
- Error analysis by document length, section availability, and label frequency
