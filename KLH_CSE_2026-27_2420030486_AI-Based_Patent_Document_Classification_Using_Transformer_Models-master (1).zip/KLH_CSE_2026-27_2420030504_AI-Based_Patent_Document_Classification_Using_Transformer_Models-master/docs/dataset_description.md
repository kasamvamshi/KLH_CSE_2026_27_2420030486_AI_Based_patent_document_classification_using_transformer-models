# Dataset Description

## Overview

PatentClass-HAT uses three patent datasets with distinct roles. No dataset fields are assumed — all schemas are inspected during Phase 1 (Dataset Audit).

## Dataset A: USPTO-3M

- **Role:** Main supervised dataset for CPC classification
- **Usage:** Training, validation, internal test
- **Expected content:** Patent documents with CPC codes
- **Status:** Schema inspection pending (Phase 1)
- **Citation:** [To be added after inspection]

## Dataset B: HUPD (Harvard USPTO Patent Dataset)

- **Role:** External evaluation and cross-dataset generalization
- **Usage:** Domain-shift analysis, missing-section experiments
- **Source:** `HUPD/hupd` on Hugging Face
- **Status:** Schema inspection pending (Phase 1)
- **Important:** Not merged with USPTO-3M. Source identity is preserved.
- **Citation:** [To be added after inspection]

## Dataset C: BIGPATENT

- **Role:** Optional domain-adaptive pretraining
- **Usage:** Patent-language representation learning
- **Source:** `big_patent` on Hugging Face
- **Status:** Schema inspection pending (Phase 1)
- **Important:** CPC label availability is NOT assumed. Must be verified.
- **Citation:** [To be added after inspection]

## Unified Schema

All datasets are normalized to this internal format:

```json
{
    "patent_id": "...",
    "title": "...",
    "abstract": "...",
    "claims": "...",
    "description": "...",
    "cpc_codes": [],
    "source_dataset": "USPTO-3M"
}
```

Missing fields use empty strings (text) or empty lists (labels).

## Dataset Statistics

> Statistics will be populated after Phase 1 dataset audit.

| Metric | USPTO-3M | HUPD | BIGPATENT |
|---|---|---|---|
| Total documents | — | — | — |
| With title | — | — | — |
| With abstract | — | — | — |
| With claims | — | — | — |
| With description | — | — | — |
| With CPC codes | — | — | — |
| Unique CPC codes | — | — | — |
| Avg. document length | — | — | — |
