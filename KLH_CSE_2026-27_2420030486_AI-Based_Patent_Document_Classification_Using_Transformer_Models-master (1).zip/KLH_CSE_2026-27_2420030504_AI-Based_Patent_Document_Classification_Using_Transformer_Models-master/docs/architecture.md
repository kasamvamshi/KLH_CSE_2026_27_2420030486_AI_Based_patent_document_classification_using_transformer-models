# PatentClass-HAT Architecture

## System Overview

**PatentClass-HAT** (Hierarchical Attention Transformer) is a section-aware hierarchical Transformer framework for explainable multi-label patent classification using CPC (Cooperative Patent Classification) codes.

## High-Level Pipeline

```
Patent Input (title, abstract, claims, description)
        │
        ▼
┌─────────────────────┐
│  Text Preprocessing  │  Clean HTML, normalize whitespace, extract sections
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Section Extraction  │  Separate title, abstract, claims, description
└─────────┬───────────┘
          │
          ▼
┌─────────────────────────┐
│  Long-Document Chunking  │  Split each section into ≤512 token chunks
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Transformer Encoding    │  BERT / DeBERTa / PatentBERT per chunk
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Chunk Aggregation       │  Attention-weighted pooling within sections
└─────────┬───────────────┘
          │
          ▼
┌──────────────────────────┐
│  Section-Aware Attention  │  Learnable weights across sections (NOVELTY)
└─────────┬────────────────┘
          │
          ▼
┌─────────────────────────────┐
│  Hierarchical Representation │  CPC section → class → subclass → group
└─────────┬───────────────────┘
          │
          ▼
┌──────────────────────────┐
│  Multi-Label CPC Classifier │  BCEWithLogitsLoss + threshold
└─────────┬────────────────┘
          │
          ▼
┌─────────────────────────┐
│  Confidence Estimation   │  Calibrated prediction probabilities
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Explainability Layer    │  Section attention + chunk importance + SHAP
└─────────┬───────────────┘
          │
          ▼
┌──────────────────────────┐
│  Prediction + Evidence    │  CPC codes, scores, evidence, explanation
└──────────────────────────┘
```

## Key Components

### 1. Section-Aware Attention (Main Novelty)
Each patent section (title, abstract, claims, description) is encoded separately. A learnable multi-head attention module computes importance weights across sections, producing a unified document representation that preserves section-level information.

### 2. Long-Document Chunking
Patents frequently exceed the 512-token Transformer limit. Each section is split into overlapping chunks, encoded independently, and aggregated via attention-weighted pooling.

### 3. Hierarchical CPC Classification
CPC codes have a tree structure (section → class → subclass → main group → subgroup). The classifier can operate in flat mode (predict all labels at once) or hierarchical mode (coarse-to-fine prediction).

### 4. Explainability
Predictions are accompanied by:
- Section importance weights (which section mattered most)
- Chunk-level importance (which part of a section)
- Token-level attribution (via Integrated Gradients / SHAP)

## Technology Stack

| Layer | Technology |
|---|---|
| Encoder | BERT / DeBERTa / PatentBERT |
| Framework | PyTorch |
| Config | YAML + Pydantic |
| API | FastAPI |
| Frontend | React + Tailwind CSS |
| Tracking | MLflow + TensorBoard |
| Explainability | Captum + SHAP |

## Datasets

| Dataset | Role |
|---|---|
| USPTO-3M | Main supervised training/testing |
| HUPD | External evaluation |
| BIGPATENT | Optional domain-adaptive pretraining |
