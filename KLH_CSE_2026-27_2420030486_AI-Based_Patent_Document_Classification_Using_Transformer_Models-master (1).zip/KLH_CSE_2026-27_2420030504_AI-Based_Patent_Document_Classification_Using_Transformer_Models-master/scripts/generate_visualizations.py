#!/usr/bin/env python3
"""Generate explainability visualizations using PatentClass-HAT."""
import sys
import logging
from pathlib import Path
import torch

# Ensure src is importable
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logging_utils import setup_logging
from src.models import PatentClassHAT
from src.explainability import NativeAttentionVisualizer, plot_section_attention_heatmap, plot_attention_distribution

logger = logging.getLogger(__name__)

def generate_dummy_batch(batch_size=4, seq_len=64, num_chunks=3):
    """Creates a dummy complex batch to feed into the model."""
    return {
        "title_input_ids": torch.randint(0, 1000, (batch_size, 32)),
        "title_attention_mask": torch.ones((batch_size, 32)),
        "abstract_input_ids": torch.randint(0, 1000, (batch_size, seq_len)),
        "abstract_attention_mask": torch.ones((batch_size, seq_len)),
        "claims_input_ids": torch.randint(0, 1000, (batch_size, num_chunks, seq_len)),
        "claims_attention_mask": torch.ones((batch_size, num_chunks, seq_len)),
        "desc_input_ids": torch.randint(0, 1000, (batch_size, num_chunks, seq_len)),
        "desc_attention_mask": torch.ones((batch_size, num_chunks, seq_len)),
    }

def main():
    setup_logging(level="INFO")
    logger.info("Starting Explainability Visualization Execution...")
    
    device = torch.device("cpu")
    
    # Initialize the model
    # We use a tiny backbone for quick initialization
    model_name = "prajjwal1/bert-tiny"
    num_labels = 5
    
    logger.info(f"Instantiating PatentClassHAT with {model_name}...")
    model = PatentClassHAT(model_name=model_name, num_labels=num_labels, chunk_pooling="mean")
    model.to(device)
    
    visualizer = NativeAttentionVisualizer(model)
    
    # Create dummy batch
    batch = generate_dummy_batch()
    
    # Extract attention
    logger.info("Extracting native fusion attention weights...")
    attn_matrix = visualizer.extract_fusion_attention(batch)
    
    # Shape should be (batch_size, 4, 4)
    logger.info(f"Attention Matrix Shape: {attn_matrix.shape}")
    
    # Save directory
    figures_dir = _PROJECT_ROOT / "experiments" / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)
    
    # 1. Plot Heatmap for the first document in the batch
    heatmap_path = figures_dir / "sample_doc_attention_heatmap.png"
    plot_section_attention_heatmap(attn_matrix[0], str(heatmap_path))
    logger.info(f"Saved single document heatmap to: {heatmap_path}")
    
    # 2. Plot Aggregate Bar Chart
    aggregate_scores = visualizer.get_aggregate_section_importance(attn_matrix)
    bar_chart_path = figures_dir / "aggregate_section_importance.png"
    plot_attention_distribution(aggregate_scores, str(bar_chart_path))
    logger.info(f"Saved aggregate bar chart to: {bar_chart_path}")

    logger.info("Explainability Visualization flow completed successfully.")

if __name__ == "__main__":
    main()
