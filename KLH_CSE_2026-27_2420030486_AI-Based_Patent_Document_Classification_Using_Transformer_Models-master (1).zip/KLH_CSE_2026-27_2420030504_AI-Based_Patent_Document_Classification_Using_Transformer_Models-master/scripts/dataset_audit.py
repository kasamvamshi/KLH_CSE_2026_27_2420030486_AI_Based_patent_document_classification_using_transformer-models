#!/usr/bin/env python3
"""Dataset Audit Script for PatentClass-HAT.

Streams a small subset of the USPTO-3M, HUPD, and BIGPATENT datasets to
inspect their actual schemas, check for missing values, analyze text lengths,
and verify CPC label availability without downloading the full massive datasets.

Usage:
    python scripts/dataset_audit.py
"""
from __future__ import annotations

import json
import logging
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

# Ensure src is importable
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logging_utils import setup_logging
from src.data.load_uspto3m import load_uspto3m_stream, get_uspto3m_schema
from src.data.load_hupd import load_hupd_stream, get_hupd_schema
from src.data.load_bigpatent import load_bigpatent_stream, get_bigpatent_schema

logger = logging.getLogger(__name__)

NUM_SAMPLES_TO_AUDIT = 100


def audit_dataset(name: str, get_schema_fn, load_stream_fn, config_kwargs: dict = None) -> dict:
    """Audit a single dataset."""
    logger.info(f"--- Auditing Dataset: {name} ---")
    if config_kwargs is None:
        config_kwargs = {}
        
    results = {
        "name": name,
        "schema_info": get_schema_fn(**config_kwargs),
        "columns": [],
        "samples_audited": 0,
        "missing_counts": defaultdict(int),
        "lengths": defaultdict(list),
        "has_cpc_labels": False,
        "error": None
    }
    
    if "error" in results["schema_info"]:
        logger.warning(f"Schema info fetch warning for {name}: {results['schema_info']['error']}. Will infer schema from stream.")

    try:
        ds_stream = load_stream_fn(**config_kwargs)
        
        for i, row in enumerate(ds_stream):
            if i >= NUM_SAMPLES_TO_AUDIT:
                break
                
            if i == 0:
                results["columns"] = list(row.keys())
                logger.info(f"Columns discovered: {results['columns']}")
                
                # Check if obvious CPC label columns exist
                cpc_indicators = ["cpc", "ipc", "label", "class", "code"]
                for col in results["columns"]:
                    if any(ind in col.lower() for ind in cpc_indicators):
                        results["has_cpc_labels"] = True
                        break
            
            results["samples_audited"] += 1
            
            # Analyze lengths and missing values for string columns
            for col, val in row.items():
                if val is None:
                    results["missing_counts"][col] += 1
                elif isinstance(val, str):
                    if val.strip() == "":
                        results["missing_counts"][col] += 1
                    else:
                        results["lengths"][col].append(len(val))
                elif isinstance(val, list):
                    if len(val) == 0:
                        results["missing_counts"][col] += 1
                    
        # Compute length stats
        results["length_stats"] = {}
        for col, lengths in results["lengths"].items():
            if lengths:
                results["length_stats"][col] = {
                    "min": int(np.min(lengths)),
                    "max": int(np.max(lengths)),
                    "mean": float(np.mean(lengths)),
                    "median": float(np.median(lengths))
                }
                
        # Remove raw lists from results for JSON serialization
        del results["lengths"]
        results["missing_counts"] = dict(results["missing_counts"])
        
    except Exception as e:
        logger.error(f"Failed during streaming {name}: {e}")
        results["error"] = str(e)
        
    return results


def main() -> int:
    setup_logging(level="INFO")
    logger.info("Starting Dataset Audit...")
    
    audit_results = {}
    
    # 1. USPTO-3M
    # Note: AI-Growth-Lab/Patent_Classification_USPTO_3M might not stream easily or might have a different name.
    # We will try it. If it fails, we document it.
    audit_results["uspto3m"] = audit_dataset(
        "USPTO-3M", 
        get_uspto3m_schema, 
        load_uspto3m_stream
    )
    
    # 2. HUPD
    audit_results["hupd"] = audit_dataset(
        "HUPD", 
        get_hupd_schema, 
        load_hupd_stream,
        config_kwargs={"name": "sample"}
    )
    
    # 3. BIGPATENT
    audit_results["bigpatent"] = audit_dataset(
        "BIGPATENT", 
        get_bigpatent_schema, 
        load_bigpatent_stream,
        config_kwargs={"name": "all"}
    )
    
    # Save results
    out_dir = _PROJECT_ROOT / "data" / "interim"
    out_dir.mkdir(exist_ok=True, parents=True)
    out_path = out_dir / "dataset_audit_results.json"
    
    with open(out_path, "w", encoding="utf-8") as f:
        # We need to make sure schema features are serializable
        # HuggingFace Features object might not be directly json serializable
        # We convert it to string representation
        for k in audit_results:
            if "features" in audit_results[k].get("schema_info", {}):
                audit_results[k]["schema_info"]["features"] = str(
                    audit_results[k]["schema_info"]["features"]
                )
        json.dump(audit_results, f, indent=2)
        
    logger.info(f"Audit complete. Results saved to {out_path}")
    
    # Print summary
    print("\n" + "="*50)
    print("DATASET AUDIT SUMMARY")
    print("="*50)
    for ds_id, res in audit_results.items():
        print(f"\nDataset: {res['name']}")
        if res.get("error"):
            print(f"  Status: ERROR - {res['error']}")
        else:
            print(f"  Status: SUCCESS")
            print(f"  Samples Audited: {res['samples_audited']}")
            print(f"  Columns: {res['columns']}")
            print(f"  Has Potential CPC Labels: {res['has_cpc_labels']}")
            print("  Missing Values:")
            for c, count in res.get("missing_counts", {}).items():
                print(f"    - {c}: {count}/{res['samples_audited']}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
