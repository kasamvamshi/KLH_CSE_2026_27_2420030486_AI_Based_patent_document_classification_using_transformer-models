#!/usr/bin/env python3
"""
Extract Section-Aware Attention Weights for Explainability.
"""
import sys
import json
import logging
from pathlib import Path
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.models.hierarchical_transformer import PatentClassHAT

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

def run_extraction():
    logger.info("=" * 60)
    logger.info("  EXPLAINABILITY & ATTENTION EXTRACTION")
    logger.info("=" * 60)
    
    device = torch.device("cpu")
    
    # Instantiate the model with a tiny backbone for the test
    hierarchical_dims = {'num_sections': 9, 'num_classes': 130, 'num_subclasses': 600}
    model = PatentClassHAT(
        model_name="prajjwal1/bert-tiny",
        hierarchical_dims=hierarchical_dims,
        chunk_pooling="attention",
        classifier_type="hierarchical"
    )
    model.eval()
    
    # Simulate a batch of 2 patents
    batch_size = 2
    seq_len = 16
    hidden_size = model.hidden_size
    
    # Create dummy inputs that match the collate_hierarchical output format
    # For claims/desc, we simulate having 2 chunks and 4 chunks respectively
    inputs = {
        "title_input_ids": torch.randint(0, 1000, (batch_size, seq_len)),
        "title_attention_mask": torch.ones(batch_size, seq_len),
        
        "abstract_input_ids": torch.randint(0, 1000, (batch_size, seq_len)),
        "abstract_attention_mask": torch.ones(batch_size, seq_len),
        
        "claims_input_ids": torch.randint(0, 1000, (batch_size, 2, seq_len)),
        "claims_attention_mask": torch.ones(batch_size, 2, seq_len),
        
        "desc_input_ids": torch.randint(0, 1000, (batch_size, 4, seq_len)),
        "desc_attention_mask": torch.ones(batch_size, 4, seq_len),
    }
    
    logger.info("Running forward pass to extract attention...")
    with torch.no_grad():
        outputs = model(**inputs)
        
    attn_weights = outputs.get("fusion_attention")
    
    if attn_weights is None:
        logger.error("Failed to extract attention weights! 'fusion_attention' key missing in output.")
        return False
        
    logger.info(f"Successfully intercepted attention weights of shape: {attn_weights.shape}")
    
    # Save the attention weights to JSON for visualization
    # Shape is (batch_size, 4, 4) since there are 4 sections (Title, Abstract, Claims, Description)
    weights_list = attn_weights.cpu().numpy().tolist()
    
    sections = ["Title", "Abstract", "Claims", "Description"]
    
    output_data = []
    for i in range(batch_size):
        patent_attn = {}
        for q_idx, query_sec in enumerate(sections):
            patent_attn[query_sec] = {}
            for k_idx, key_sec in enumerate(sections):
                patent_attn[query_sec][key_sec] = weights_list[i][q_idx][k_idx]
        output_data.append(patent_attn)
        
    save_path = PROJECT_ROOT / "outputs" / "attention_weights.json"
    save_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(save_path, "w") as f:
        json.dump(output_data, f, indent=4)
        
    logger.info(f"Attention Weights successfully extracted and saved to {save_path}")
    
    # Display sample
    logger.info("\nSample Attention Map (Patent 0, Query: Claims):")
    for sec, score in output_data[0]["Claims"].items():
        logger.info(f"  -> Attention to {sec:12}: {score:.4f}")
        
    logger.info("=" * 60)
    logger.info("Attention Weights successfully extracted.")
    return True

if __name__ == "__main__":
    run_extraction()
