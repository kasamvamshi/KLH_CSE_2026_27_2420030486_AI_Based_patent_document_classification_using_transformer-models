#!/usr/bin/env python3
"""Compare experiment logs across model types."""
import json
import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

def main():
    logs_dir = _PROJECT_ROOT / "experiments" / "logs"
    if not logs_dir.exists():
        print("No experiment logs found. Run scripts/train.py first.")
        return

    log_files = sorted(logs_dir.glob("*.json"))
    if not log_files:
        print("No experiment logs found.")
        return

    experiments = []
    for f in log_files:
        with open(f) as fh:
            data = json.load(fh)
            experiments.append(data)

    # Print comparison table
    header = f"{'Experiment':<35} {'Model':<10} {'Epochs':<8} {'Train Loss':<12} {'Val Loss':<10} {'Micro-F1':<10} {'Macro-F1':<10} {'Status':<10}"
    print("=" * len(header))
    print(header)
    print("=" * len(header))

    for exp in experiments:
        name = exp.get("experiment_name", "?")
        run_id = exp.get("run_id", "?")
        model_type = exp.get("hyperparameters", {}).get("model_type", "?")
        status = exp.get("status", "?")

        epochs = exp.get("epochs", [])
        if epochs:
            last = epochs[-1]
            train_loss = f"{last.get('train_loss', 0):.4f}"
            val_loss = f"{last.get('val_loss', 0):.4f}"
            micro_f1 = f"{last.get('micro_f1', 0):.4f}"
            macro_f1 = f"{last.get('macro_f1', 0):.4f}"
            n_epochs = str(len(epochs))
        else:
            train_loss = val_loss = micro_f1 = macro_f1 = "N/A"
            n_epochs = "0"

        label = f"{name}_{run_id}"
        print(f"{label:<35} {model_type:<10} {n_epochs:<8} {train_loss:<12} {val_loss:<10} {micro_f1:<10} {macro_f1:<10} {status:<10}")

    print("=" * len(header))

if __name__ == "__main__":
    main()
