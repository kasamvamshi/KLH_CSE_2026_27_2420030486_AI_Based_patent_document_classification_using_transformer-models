#!/usr/bin/env python3
"""Test the DataLoader and unified dataset wrapping."""
import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import torch
from torch.utils.data import DataLoader
from datasets import Dataset

from src.preprocessing import CPCLabelEncoder, Chunker
from src.data.dataset import PatentDataset

def test_unified_dataloader():
    # 1. Create a dummy huggingface dataset
    hf_ds = Dataset.from_list([
        {
            "id": "123", 
            "text": "ABSTRACT\nThis is a short abstract.\nCLAIMS\n1. A device.\nBACKGROUND OF THE INVENTION\nSome bg.",
            "cpc_ids": "G06N, H04L"
        },
        {
            "id": "124", 
            "text": "ABSTRACT\nSecond abstract.\nCLAIMS\n1. Another device.\nBACKGROUND OF THE INVENTION\nSecond bg.",
            "cpc_ids": "G06N, A01B"
        }
    ])
    
    # HF datasets acts as IterableDataset if we just iterate it, but we can also use stream.
    # To simulate IterableDataset:
    class DummyIterable:
        def __init__(self, ds):
            self.ds = ds
        def __iter__(self):
            for row in self.ds:
                yield row
                
    hf_iter = DummyIterable(hf_ds)

    # 2. Fit label encoder
    encoder = CPCLabelEncoder(min_frequency=1, primary_level="subclass")
    encoder.fit([row["cpc_ids"] for row in hf_ds])
    
    # 3. Create chunker
    chunker = Chunker(max_length=5, overlap=1, use_words=True)
    
    # 4. Wrap in Unified Dataset
    ds = PatentDataset(
        hf_dataset=hf_iter,
        dataset_name="uspto3m",
        label_encoder=encoder,
        chunker=chunker
    )
    
    # 5. Create DataLoader
    def collate_fn(batch):
        # We need a custom collate_fn because chunks are lists of variable length
        # For this test, we just return the batch as a list of dicts.
        return batch
        
    loader = DataLoader(ds, batch_size=2, collate_fn=collate_fn)
    
    # 6. Fetch batch
    batch = next(iter(loader))
    
    print(f"Loaded {len(batch)} items in batch.")
    for i, item in enumerate(batch):
        print(f"\nItem {i+1}:")
        print(f"  Doc ID: {item['doc_id']}")
        print(f"  Abstract: {item['abstract']}")
        print(f"  Abstract Chunks: {item.get('abstract_chunks', [])}")
        print(f"  Labels: {item['labels'].tolist()} (shape: {item['labels'].shape})")
        
if __name__ == "__main__":
    test_unified_dataloader()
