#!/usr/bin/env python3
"""PatentClass-HAT environment validation script.

Checks that the Python environment, required packages, optional packages,
GPU availability, and disk space meet project requirements.

Usage:
    python scripts/validate_env.py

Exit codes:
    0 — All checks passed
    1 — One or more critical checks failed
"""
from __future__ import annotations

import importlib
import os
import platform
import shutil
import sys
from pathlib import Path


# ============================================================
# Color helpers (works on Windows 10+ and Unix terminals)
# ============================================================
def _green(text: str) -> str:
    return f"\033[92m{text}\033[0m"

def _red(text: str) -> str:
    return f"\033[91m{text}\033[0m"

def _yellow(text: str) -> str:
    return f"\033[93m{text}\033[0m"

def _bold(text: str) -> str:
    return f"\033[1m{text}\033[0m"


# ============================================================
# Validation checks
# ============================================================

def check_python_version() -> bool:
    """Verify Python version is 3.10 or 3.11."""
    version = sys.version_info
    ok = (3, 10) <= version < (3, 13)
    status = _green("PASS") if ok else _red("FAIL")
    print(f"  [{status}] Python version: {sys.version}")
    if not ok:
        print(f"         Required: Python 3.10 or 3.11")
    return ok


def check_required_packages() -> bool:
    """Check that critical packages are importable."""
    required = [
        ("yaml", "pyyaml"),
        ("pydantic", "pydantic"),
        ("numpy", "numpy"),
        ("pandas", "pandas"),
    ]
    all_ok = True
    for import_name, pip_name in required:
        try:
            mod = importlib.import_module(import_name)
            version = getattr(mod, "__version__", "unknown")
            print(f"  [{_green('PASS')}] {pip_name} ({version})")
        except ImportError:
            print(f"  [{_red('FAIL')}] {pip_name} — not installed (pip install {pip_name})")
            all_ok = False
    return all_ok


def check_optional_packages() -> dict[str, bool]:
    """Check optional but recommended packages."""
    optional = [
        ("torch", "torch"),
        ("transformers", "transformers"),
        ("sklearn", "scikit-learn"),
        ("matplotlib", "matplotlib"),
        ("seaborn", "seaborn"),
        ("mlflow", "mlflow"),
        ("fastapi", "fastapi"),
        ("captum", "captum"),
    ]
    results = {}
    for import_name, pip_name in optional:
        try:
            mod = importlib.import_module(import_name)
            version = getattr(mod, "__version__", "unknown")
            print(f"  [{_green('OK  ')}] {pip_name} ({version})")
            results[pip_name] = True
        except Exception as e:
            print(f"  [{_yellow('SKIP')}] {pip_name} — import failed ({type(e).__name__})")
            results[pip_name] = False
    return results


def check_gpu() -> None:
    """Check CUDA/GPU availability."""
    try:
        import torch
        if torch.cuda.is_available():
            gpu_name = torch.cuda.get_device_name(0)
            gpu_mem = torch.cuda.get_device_properties(0).total_mem / (1024**3)
            print(f"  [{_green('GPU ')}] {gpu_name} ({gpu_mem:.1f} GB)")
        else:
            print(f"  [{_yellow('CPU ')}] CUDA not available — CPU mode only")
    except Exception as e:
        print(f"  [{_yellow('SKIP')}] PyTorch import failed ({type(e).__name__}) — GPU check skipped")


def check_disk_space() -> None:
    """Check available disk space."""
    project_root = Path(__file__).resolve().parent.parent
    total, used, free = shutil.disk_usage(project_root)
    free_gb = free / (1024**3)
    status = _green("OK  ") if free_gb >= 20 else _yellow("WARN")
    print(f"  [{status}] Disk space: {free_gb:.1f} GB free")
    if free_gb < 20:
        print(f"         Recommended: 20+ GB free for datasets and models")


def check_project_structure() -> bool:
    """Verify critical project directories exist."""
    project_root = Path(__file__).resolve().parent.parent
    required_dirs = [
        "configs",
        "data",
        "src",
        "src/utils",
        "tests",
    ]
    all_ok = True
    for dir_name in required_dirs:
        dir_path = project_root / dir_name
        if dir_path.exists():
            print(f"  [{_green('OK  ')}] {dir_name}/")
        else:
            print(f"  [{_red('MISS')}] {dir_name}/ — directory missing")
            all_ok = False
    return all_ok


# ============================================================
# Main
# ============================================================

def main() -> int:
    """Run all environment validation checks.

    Returns:
        0 if all critical checks pass, 1 otherwise.
    """
    # Enable ANSI colors on Windows
    if platform.system() == "Windows":
        os.system("")

    print()
    print(_bold("=" * 60))
    print(_bold("  PatentClass-HAT — Environment Validation"))
    print(_bold("=" * 60))
    print()

    critical_ok = True

    print(_bold("1. Python Version"))
    if not check_python_version():
        critical_ok = False
    print()

    print(_bold("2. Required Packages"))
    if not check_required_packages():
        critical_ok = False
    print()

    print(_bold("3. Optional Packages"))
    check_optional_packages()
    print()

    print(_bold("4. GPU / Hardware"))
    check_gpu()
    check_disk_space()
    print()

    print(_bold("5. Project Structure"))
    if not check_project_structure():
        critical_ok = False
    print()

    print(_bold("6. System Information"))
    print(f"  OS:       {platform.system()} {platform.release()}")
    print(f"  Machine:  {platform.machine()}")
    print(f"  Python:   {sys.executable}")
    print(f"  CWD:      {os.getcwd()}")
    print()

    # Summary
    print(_bold("=" * 60))
    if critical_ok:
        print(_green("  [PASS] All critical checks passed."))
        print("  The environment is ready for PatentClass-HAT.")
    else:
        print(_red("  [FAIL] Some critical checks failed."))
        print("  Please install missing dependencies before proceeding.")
    print(_bold("=" * 60))
    print()

    return 0 if critical_ok else 1


if __name__ == "__main__":
    sys.exit(main())
