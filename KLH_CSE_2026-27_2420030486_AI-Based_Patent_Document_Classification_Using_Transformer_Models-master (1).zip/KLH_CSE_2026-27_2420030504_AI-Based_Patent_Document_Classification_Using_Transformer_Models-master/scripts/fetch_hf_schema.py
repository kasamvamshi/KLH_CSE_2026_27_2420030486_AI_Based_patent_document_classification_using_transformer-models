#!/usr/bin/env python3
import requests
import sys
import json

def get_first_row(dataset_id, config="default", split="train"):
    # Hugging Face datasets server API
    url = f"https://datasets-server.huggingface.co/first-rows?dataset={dataset_id}&config={config}&split={split}"
    print(f"Fetching: {url}")
    resp = requests.get(url)
    if resp.status_code == 200:
        data = resp.json()
        if data.get("rows") and len(data["rows"]) > 0:
            row = data["rows"][0]["row"]
            print(f"Success for {dataset_id}/{config}/{split}")
            print("Columns:", list(row.keys()))
            return row
    else:
        print(f"Failed to fetch {dataset_id}/{config}: {resp.status_code} {resp.text}")
    return None

def main():
    datasets_to_check = [
        ("MalavP/USPTO-3M", "default", "train"),
        ("HUPD/hupd", "sample", "train"),
        ("big_patent", "all", "train"),
        ("big_patent", "a", "train")
    ]
    
    results = {}
    for ds_id, conf, spl in datasets_to_check:
        row = get_first_row(ds_id, conf, spl)
        if row:
            # truncate strings for display
            display_row = {k: (v[:100] + "..." if isinstance(v, str) and len(v) > 100 else v) for k, v in row.items()}
            results[ds_id] = {"columns": list(row.keys()), "sample": display_row}
            
    with open("data/interim/dataset_audit_results.json", "w") as f:
        json.dump(results, f, indent=2)

if __name__ == "__main__":
    main()
