# Product Requirements Document — PatentClass-HAT

## 1. Product information
- **Name:** PatentClass-HAT
- **Full title:** A Section-Aware Hierarchical Transformer Framework for Explainable Multi-Label Patent Classification
- **Type:** AI research platform and reproducible prototype
- **Domain:** NLP, patent analytics, explainable AI, hierarchical classification

## 2. Vision
Create an intelligent platform that predicts CPC codes from patent documents, explains the prediction, and demonstrates robustness across three patent datasets.

## 3. Problem statement
Patents are long, technical, section-structured, and associated with multiple hierarchical CPC codes. Flat or truncated classifiers may lose context, ignore section importance, struggle with rare labels, and provide weak explanations.

## 4. Goals
- Multi-label CPC prediction
- Long-document support
- Separate title, abstract, claims, and description processing
- Hierarchical CPC modeling
- Explainable predictions
- Cross-dataset generalization
- Reproducible research experiments
- Optional web demonstration

## 5. Non-goals
- Legal advice
- Patent validity decisions
- Patent granting decisions
- Replacing patent professionals
- Treating BIGPATENT as a labeled CPC benchmark without verification

## 6. Datasets
| Dataset | Role |
|---|---|
| USPTO-3M | Main supervised training and testing |
| HUPD | External validation and generalization |
| BIGPATENT | Optional domain-adaptive pretraining |

### Unified schema
`patent_id, title, abstract, claims, description, cpc_codes, source_dataset`

## 7. User stories
- As a researcher, I need reproducible experiments for a paper.
- As a patent analyst, I need CPC predictions with evidence.
- As a student, I need a simple interface for patent text.
- As a developer, I need modular APIs and configuration.

## 8. Functional requirements
- **FR-01:** Load each dataset through a separate adapter.
- **FR-02:** Audit columns, missing values, duplicates, lengths, and labels.
- **FR-03:** Clean text and preserve section boundaries.
- **FR-04:** Chunk long documents within token limits.
- **FR-05:** Support flat multi-label CPC classification.
- **FR-06:** Support hierarchical or coarse-to-fine CPC classification.
- **FR-07:** Return important sections, chunks, confidence, and evidence.
- **FR-08:** Calculate classification and hierarchical metrics.
- **FR-09:** Track configurations, datasets, metrics, and checkpoints.
- **FR-10:** Provide a prediction API.
- **FR-11:** Provide a simple web interface.
- **FR-12:** Support fixed seeds and reproducible runs.

## 9. Non-functional requirements
- GPU acceleration with CPU fallback for small tests
- Checkpointing and resume support
- Input validation and request-size limits
- No default storage of user documents
- Modular, typed, documented code
- Unit and integration tests
- Versioned configurations and dataset records

## 10. Architecture
```text
Patent Input
→ Cleaning and Section Extraction
→ Long-Document Chunking
→ Transformer Encoder
→ Section-Aware Attention
→ Hierarchical Document Representation
→ Multi-Label CPC Classifier
→ Confidence Calibration
→ Explainability Layer
→ Prediction + Evidence
```

## 11. Model requirements
Baselines: TF-IDF + Logistic Regression, TF-IDF + SVM, BERT/DeBERTa, PatentBERT.

Proposed model: PatentBERT or compatible Transformer + chunk aggregation + section-aware attention + hierarchical CPC classifier + imbalance handling + explainability.

## 12. API input
```json
{
  "title": "Patent title",
  "abstract": "Patent abstract",
  "claims": "Patent claims",
  "description": "Patent description"
}
```

## 13. API output
```json
{
  "predictions": [{"cpc_code": "G06N3/08", "confidence": 0.91}],
  "important_sections": [{"section": "claims", "importance": 0.82}],
  "evidence": ["Important text span supporting the prediction"],
  "model_version": "patentclass-hat-v1"
}
```

## 14. Research questions
1. Does section-aware attention improve CPC classification?
2. Does chunking improve long-document performance?
3. Does hierarchy improve fine-grained CPC prediction?
4. Does imbalance handling improve rare-class performance?
5. Does the model generalize from USPTO-3M to HUPD?
6. Are explanations faithful and useful?

## 15. Success metrics
Micro-F1, Macro-F1, precision, recall, Hamming loss, exact match, Top-k recall, hierarchical F1, parent-child consistency, latency, training time, and GPU memory.

## 16. Delivery phases
Setup → dataset audit → preprocessing → baselines → Transformer → long documents → section attention → hierarchy → imbalance → explainability → external evaluation → API/demo → paper package.

## 17. Risks and mitigation
| Risk | Mitigation |
|---|---|
| Schema mismatch | Separate dataset adapters |
| GPU limits | Smaller subsets, accumulation, mixed precision, LoRA |
| Imbalance | Class weights, focal loss, threshold tuning |
| Missing labels | Use verified labeled data only |
| Data leakage | Patent-family/time-aware splits where possible |
| Weak explanations | Faithfulness tests and limitations |

## 18. Acceptance criteria
The project is research-ready when all three datasets are documented, preprocessing is reproducible, baselines and ablations are complete, PatentClass-HAT is trained, HUPD evaluation is reported, explanations are generated, results are logged, the demo works, and reproduction instructions are complete.
