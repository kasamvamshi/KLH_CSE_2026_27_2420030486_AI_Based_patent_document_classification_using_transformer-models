# PatentClass-HAT — Technology Stack

## Recommended stack
| Layer | Technology | Purpose |
|---|---|---|
| Language | Python 3.10/3.11 | Main development |
| Deep learning | PyTorch | Training and inference |
| Transformers | Hugging Face Transformers | BERT, DeBERTa, PatentBERT |
| Tokenization | Hugging Face Tokenizers | Fast tokenization |
| Data | Pandas, NumPy, PyArrow | Cleaning and Parquet processing |
| Dataset loading | Hugging Face Datasets | Dataset access |
| Baselines | Scikit-learn | TF-IDF, Logistic Regression, SVM |
| Metrics | Scikit-learn, TorchMetrics | Evaluation |
| Splitting | Iterative-stratification | Multi-label stratification |
| Explainability | Captum, SHAP | Attribution and explanations |
| Visualization | Matplotlib, Seaborn | Plots and analysis |
| Tracking | MLflow, TensorBoard | Metrics and checkpoints |
| Config | YAML, Pydantic | Settings and validation |
| API | FastAPI, Uvicorn | Inference service |
| Frontend | React, Tailwind CSS | Demo interface |
| Database | PostgreSQL, optional | Metadata and predictions |
| Testing | Pytest | Unit/integration tests |
| Quality | Ruff, Black, MyPy | Linting and formatting |
| Deployment | Docker, Docker Compose | Reproducibility |
| Version control | Git, GitHub | Source management |
| GPU | CUDA/NVIDIA drivers | Acceleration |
| Development | VS Code, Jupyter, Colab | Development and GPU support |

## Installation
```bash
pip install torch transformers tokenizers datasets accelerate sentencepiece
pip install pandas numpy pyarrow beautifulsoup4 scikit-learn
pip install iterative-stratification torchmetrics scipy imbalanced-learn
pip install captum shap lime matplotlib seaborn
pip install mlflow tensorboard pyyaml pydantic
pip install fastapi uvicorn python-multipart
pip install pytest pytest-cov ruff black mypy
```

## requirements.txt
```text
torch
transformers
tokenizers
datasets
accelerate
sentencepiece
pandas
numpy
pyarrow
beautifulsoup4
scikit-learn
iterative-stratification
torchmetrics
scipy
imbalanced-learn
captum
shap
lime
matplotlib
seaborn
mlflow
tensorboard
pyyaml
pydantic
fastapi
uvicorn
python-multipart
pytest
pytest-cov
ruff
black
mypy
```

## Model selection order
1. TF-IDF + Logistic Regression
2. TF-IDF + Linear SVM
3. BERT or DeBERTa
4. PatentBERT
5. PatentBERT + chunking
6. PatentBERT + section-aware attention
7. Full PatentClass-HAT

## Dataset roles
- USPTO-3M: main supervised CPC classification
- HUPD: external evaluation
- BIGPATENT: optional domain adaptation

## Hardware guidance
### Minimum
16 GB RAM, 4-core CPU, 20–50 GB free disk, CPU-compatible PyTorch.

### Recommended
32 GB RAM, NVIDIA GPU with 12–24 GB VRAM, SSD, and 100+ GB storage.

### Limited GPU strategy
Use smaller subsets, gradient accumulation, mixed precision, frozen layers, LoRA, lower batch size, and cached tokenization.

## Engineering standards
- Use `.env` for secrets.
- Do not commit raw datasets or checkpoints.
- Use `data/raw`, `data/interim`, and `data/processed`.
- Set random seeds.
- Log model, dataset, configuration, metrics, and hardware.
- Keep notebooks for exploration and reusable logic in `src/`.

## Commands
```bash
python -m venv .venv
```
Windows:
```bash
.venv\Scripts\activate
```
Linux/macOS:
```bash
source .venv/bin/activate
```

```bash
pip install -r requirements.txt
pytest -q
black src tests
ruff check .
uvicorn api.main:app --reload
```
