# PHASE 12: File Cleanup Report

| File | Reason | Action | Backup Location | Status |
|------|--------|--------|-----------------|--------|
| `scripts/train.py` | Replaced by `src.training.train_patentclass_hat` | MOVE | `_backup_before_cleanup/` | [PASS] |
| `scripts/train_baseline.py` | Replaced by `src.training.train_patentclass_hat` | MOVE | `_backup_before_cleanup/` | [PASS] |
| `scripts/train_hat.py` | Replaced by `src.training.train_patentclass_hat` | MOVE | `_backup_before_cleanup/` | [PASS] |
| `scripts/train_long_doc.py` | Replaced by `src.training.train_patentclass_hat` | MOVE | `_backup_before_cleanup/` | [PASS] |
| `scripts/run_baselines.py` | Outdated dummy-data script | MOVE | `_backup_before_cleanup/` | [PASS] |
| `scripts/test_baseline_transformer.py` | Replaced by unified E2E smoke tests | MOVE | `_backup_before_cleanup/` | [PASS] |
