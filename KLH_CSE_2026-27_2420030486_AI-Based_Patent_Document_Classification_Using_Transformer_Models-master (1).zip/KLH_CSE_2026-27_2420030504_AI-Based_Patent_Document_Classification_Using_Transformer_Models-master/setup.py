"""PatentClass-HAT package setup for editable installation.

Usage:
    pip install -e .

This enables importing the `src` package from anywhere in the project:
    from src.utils.config import load_config
"""
from setuptools import setup, find_packages

setup(
    name="patentclass-hat",
    version="0.1.0",
    description=(
        "PatentClass-HAT: A Section-Aware Hierarchical Transformer Framework "
        "for Explainable Multi-Label Patent Classification"
    ),
    author="PatentClass-HAT Authors",
    python_requires=">=3.10,<3.12",
    packages=find_packages(),
    install_requires=[],  # Dependencies managed via requirements.txt
)
