#!/usr/bin/env python3
"""Run ML Baselines on a simulated dataset."""
import sys
import logging
from pathlib import Path
import numpy as np

# Ensure src is importable
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logging_utils import setup_logging
from src.preprocessing import CPCLabelEncoder
from src.baselines import TFIDFFeaturizer, SklearnBaselineModel
from src.data.dataset import PatentDataset
from datasets import Dataset

logger = logging.getLogger(__name__)

from src.data.load_dataset import load_real_dataset

def main():
    setup_logging(level="INFO")
    logger.info("Starting Baseline Execution...")
    
    # 1. Load Data
    logger.info("Loading real dataset...")
    train_ds, test_ds, _ = load_real_dataset()
    
    # 2. Fit Label Encoder
    logger.info("Fitting CPCLabelEncoder...")
    encoder = CPCLabelEncoder(min_frequency=1, primary_level="subclass")
    encoder.fit([row["cpc_label"] for row in train_ds])
    
    # 3. Create Unified Datasets
    # Iterate as dictionaries to extract text
    class HupdIterator:
        def __init__(self, ds):
            self.ds = ds
        def __iter__(self):
            for row in self.ds:
                yield row
                
    train_patent_ds = PatentDataset(HupdIterator(train_ds), "hupd", encoder, chunker=None)
    test_patent_ds = PatentDataset(HupdIterator(test_ds), "hupd", encoder, chunker=None)
    
    # To use TF-IDF, we need to extract the processed dictionaries
    logger.info("Processing unified dataset stream...")
    train_dicts = list(train_patent_ds)
    test_dicts = list(test_patent_ds)
    
    y_train = np.stack([d["labels"].numpy() for d in train_dicts])
    y_test = np.stack([d["labels"].numpy() for d in test_dicts])
    
    # 4. TF-IDF
    featurizer = TFIDFFeaturizer(max_features=5000) # Memory safe constraint
    featurizer.fit(train_dicts)
    
    X_train = featurizer.transform(train_dicts)
    X_test = featurizer.transform(test_dicts)
    
    # 5. Train & Evaluate Logistic Regression
    clf = SklearnBaselineModel(model_type="logistic", random_state=42)
    clf.fit(X_train, y_train)
    
    target_names = [encoder.idx_to_label[i] for i in range(len(encoder.idx_to_label))]
    logger.info("--- Logistic Regression Metrics ---")
    metrics = clf.evaluate(X_test, y_test, target_names=target_names)
    
    # Save results to a file for reporting
    out_dir = _PROJECT_ROOT / "experiments" / "baselines"
    out_dir.mkdir(parents=True, exist_ok=True)
    
    import json
    with open(out_dir / "logistic_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
        
    logger.info(f"Baseline complete. Metrics saved to {out_dir}")

if __name__ == "__main__":
    main()
