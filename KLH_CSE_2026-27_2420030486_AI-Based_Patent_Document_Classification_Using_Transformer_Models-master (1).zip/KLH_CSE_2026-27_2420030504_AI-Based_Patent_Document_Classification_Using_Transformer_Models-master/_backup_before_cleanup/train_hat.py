#!/usr/bin/env python3
"""Run PatentClass-HAT (Section-Aware) on a simulated dataset."""
import sys
import logging
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from transformers import AutoTokenizer

# Ensure src is importable
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logging_utils import setup_logging
from src.preprocessing import CPCLabelEncoder, Chunker
from src.data.dataset import PatentDataset
from src.models import PatentClassHAT
from src.training import Trainer
from src.evaluation import compute_multilabel_metrics
from datasets import Dataset

logger = logging.getLogger(__name__)

from src.data.load_dataset import load_real_dataset

def main():
    setup_logging(level="INFO")
    logger.info("Starting PatentClass-HAT Execution...")
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Using device: {device}")
    
    train_ds, val_ds, test_ds = load_real_dataset()
    
    encoder = CPCLabelEncoder(min_frequency=1, primary_level="subclass")
    encoder.fit([row["cpc_label"] for row in train_ds])
    
    model_name = "prajjwal1/bert-tiny" 
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    
    # Setup chunker for long sections
    max_chunk_length = 64
    max_chunks = 3
    chunker = Chunker(max_length=max_chunk_length, overlap=8, use_words=True)
    
    model = PatentClassHAT(
        model_name=model_name, 
        num_labels=len(encoder.vocab),
        chunk_pooling="mean"
    )
    
    class HFListIter:
        def __init__(self, ds): self.ds = ds
        def __iter__(self):
            for r in self.ds: yield r
                
    train_patent_ds = PatentDataset(HFListIter(train_ds), "hupd", encoder, chunker=chunker)
    val_patent_ds = PatentDataset(HFListIter(val_ds), "hupd", encoder, chunker=chunker)
    
    def pad_and_tokenize_chunks(chunks_list, max_chk_len, max_chks):
        """Helper to tokenize and pad a list of document chunks."""
        # Truncate
        chunks_list = chunks_list[:max_chks]
        
        if len(chunks_list) > 0:
            enc = tokenizer(
                chunks_list, padding="max_length", truncation=True, 
                max_length=max_chk_len, return_tensors="pt"
            )
            i_ids = enc["input_ids"]
            a_mask = enc["attention_mask"]
        else:
            i_ids = torch.zeros((1, max_chk_len), dtype=torch.long)
            a_mask = torch.zeros((1, max_chk_len), dtype=torch.long)
            
        num_chk = i_ids.size(0)
        if num_chk < max_chks:
            p_ids = torch.zeros((max_chks - num_chk, max_chk_len), dtype=torch.long)
            p_mask = torch.zeros((max_chks - num_chk, max_chk_len), dtype=torch.long)
            p_ids.fill_(tokenizer.pad_token_id)
            i_ids = torch.cat([i_ids, p_ids], dim=0)
            a_mask = torch.cat([a_mask, p_mask], dim=0)
            
        return i_ids, a_mask
    
    def collate_fn(batch):
        titles = [item["title"] for item in batch]
        abstracts = [item["abstract"] for item in batch]
        
        title_enc = tokenizer(titles, padding="max_length", truncation=True, max_length=64, return_tensors="pt")
        abs_enc = tokenizer(abstracts, padding="max_length", truncation=True, max_length=128, return_tensors="pt")
        
        batch_claims_ids, batch_claims_masks = [], []
        batch_desc_ids, batch_desc_masks = [], []
        labels = []
        
        for item in batch:
            c_ids, c_mask = pad_and_tokenize_chunks(item.get("claims_chunks", []), max_chunk_length, max_chunks)
            d_ids, d_mask = pad_and_tokenize_chunks(item.get("description_chunks", []), max_chunk_length, max_chunks)
            
            batch_claims_ids.append(c_ids)
            batch_claims_masks.append(c_mask)
            batch_desc_ids.append(d_ids)
            batch_desc_masks.append(d_mask)
            
            labels.append(item["labels"])
            
        return {
            "title_input_ids": title_enc["input_ids"],
            "title_attention_mask": title_enc["attention_mask"],
            "abstract_input_ids": abs_enc["input_ids"],
            "abstract_attention_mask": abs_enc["attention_mask"],
            "claims_input_ids": torch.stack(batch_claims_ids),
            "claims_attention_mask": torch.stack(batch_claims_masks),
            "desc_input_ids": torch.stack(batch_desc_ids),
            "desc_attention_mask": torch.stack(batch_desc_masks),
            "labels": torch.stack(labels)
        }
        
    train_loader = DataLoader(train_patent_ds, batch_size=2, collate_fn=collate_fn)
    val_loader = DataLoader(val_patent_ds, batch_size=2, collate_fn=collate_fn)
    
    optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
    trainer = Trainer(
        model=model,
        optimizer=optimizer,
        device=device,
        metrics_fn=compute_multilabel_metrics
    )
    
    logger.info("Training 1 epoch for verification...")
    train_loss = trainer.train_epoch(train_loader)
    logger.info(f"Epoch 1 - Train Loss: {train_loss:.4f}")
    
    logger.info("Evaluating...")
    val_metrics = trainer.evaluate(val_loader)
    logger.info(f"Validation Metrics: {val_metrics}")
    
    logger.info("PatentClass-HAT flow completed successfully.")

if __name__ == "__main__":
    main()
