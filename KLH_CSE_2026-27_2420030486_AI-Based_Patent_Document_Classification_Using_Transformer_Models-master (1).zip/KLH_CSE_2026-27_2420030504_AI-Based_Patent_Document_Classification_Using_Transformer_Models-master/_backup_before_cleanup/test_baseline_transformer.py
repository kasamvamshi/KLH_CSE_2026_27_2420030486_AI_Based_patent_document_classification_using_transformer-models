import os
import sys
import torch
import logging
from pathlib import Path
from transformers import AutoTokenizer

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.models.baseline_transformer import FlatTransformerBaseline

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

def test_baseline_transformer():
    logger.info("=== Phase 7: Tokenizer and Transformer Connection ===")
    
    # 1. Device selection
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Target Device: {device}")
    
    # 2. Tokenizer loading
    model_name = "prajjwal1/bert-tiny" # Fast baseline
    logger.info(f"Downloading/Loading Tokenizer: {model_name}")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    logger.info("Tokenizer loaded successfully.")
    
    # 3. Model Configuration & Loading
    num_labels = 12
    logger.info(f"Loading Model: {model_name} with {num_labels} labels...")
    model = FlatTransformerBaseline(model_name=model_name, num_labels=num_labels)
    model.to(device)
    logger.info("Model loaded and moved to device successfully.")
    
    # 4. Dummy input to test forward pass and dimensions
    sample_text = ["This is a patent about a neural network machine learning method."]
    encoded = tokenizer(
        sample_text, 
        padding="max_length", 
        truncation=True, 
        max_length=32, 
        return_tensors="pt"
    )
    
    input_ids = encoded["input_ids"].to(device)
    attention_mask = encoded["attention_mask"].to(device)
    
    logger.info(f"Input IDs shape: {input_ids.shape}")
    logger.info(f"Attention Mask shape: {attention_mask.shape}")
    
    # Random multi-label targets
    dummy_labels = torch.randint(0, 2, (1, num_labels)).float().to(device)
    logger.info(f"Labels shape: {dummy_labels.shape}")
    
    # 5. Forward Pass
    model.eval()
    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=dummy_labels)
        
    logits = outputs["logits"]
    loss = outputs["loss"]
    
    logger.info(f"Output Logits shape: {logits.shape}")
    logger.info(f"BCEWithLogitsLoss value: {loss.item():.4f}")
    
    if logits.shape != (1, num_labels):
        logger.error("Output dimension mismatch!")
        return False
        
    # 6. Save and Load verification
    logger.info("Testing Save/Load capabilities...")
    save_dir = PROJECT_ROOT / "outputs" / "models" / "baseline_test"
    save_dir.mkdir(parents=True, exist_ok=True)
    
    model_path = save_dir / "pytorch_model.bin"
    torch.save(model.state_dict(), model_path)
    logger.info(f"Model saved to {model_path}")
    
    loaded_model = FlatTransformerBaseline(model_name=model_name, num_labels=num_labels)
    loaded_model.load_state_dict(torch.load(model_path, map_location=device))
    loaded_model.to(device)
    logger.info("Model loaded from state dict successfully.")
    
    logger.info("All checks passed successfully.")
    return True

if __name__ == "__main__":
    test_baseline_transformer()
