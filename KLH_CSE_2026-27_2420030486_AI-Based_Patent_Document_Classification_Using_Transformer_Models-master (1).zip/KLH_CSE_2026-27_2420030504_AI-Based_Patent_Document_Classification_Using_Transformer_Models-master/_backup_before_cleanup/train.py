#!/usr/bin/env python3
"""Unified Training Script for PatentClass-HAT project.

Usage:
    python scripts/train.py --model_type flat --epochs 1
    python scripts/train.py --model_type longdoc --epochs 2
    python scripts/train.py --model_type hat --epochs 1
"""
import sys
import argparse
import logging
import random
from pathlib import Path

import torch
import numpy as np
from torch.utils.data import DataLoader
from transformers import AutoTokenizer
from datasets import Dataset

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logging_utils import setup_logging
from src.preprocessing import CPCLabelEncoder, Chunker
from src.data.dataset import PatentDataset
from src.models import FlatTransformerBaseline, LongDocTransformer, PatentClassHAT
from src.training import Trainer, save_checkpoint, ExperimentLogger
from src.evaluation import compute_multilabel_metrics

logger = logging.getLogger(__name__)

from src.data.load_dataset import load_real_dataset

# ── Collate Functions ────────────────────────────────────────────────

def make_flat_collate(tokenizer, max_length=512):
    def collate_fn(batch):
        texts, labels = [], []
        for item in batch:
            t = f"{item['title']} {item['abstract']} {item['claims']} {item['description']}"
            texts.append(t.strip())
            labels.append(item["labels"])
        enc = tokenizer(texts, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
        return {"input_ids": enc["input_ids"], "attention_mask": enc["attention_mask"], "labels": torch.stack(labels)}
    return collate_fn

def make_longdoc_collate(tokenizer, max_chunk_length=64, max_chunks=4):
    def collate_fn(batch):
        batch_ids, batch_masks, labels = [], [], []
        for item in batch:
            all_chunks = item.get("abstract_chunks", []) + item.get("claims_chunks", []) + item.get("description_chunks", [])
            all_chunks = all_chunks[:max_chunks]
            if all_chunks:
                enc = tokenizer(all_chunks, padding="max_length", truncation=True, max_length=max_chunk_length, return_tensors="pt")
                ids, mask = enc["input_ids"], enc["attention_mask"]
            else:
                ids = torch.full((1, max_chunk_length), tokenizer.pad_token_id, dtype=torch.long)
                mask = torch.zeros((1, max_chunk_length), dtype=torch.long)
            n = ids.size(0)
            if n < max_chunks:
                p_ids = torch.full((max_chunks - n, max_chunk_length), tokenizer.pad_token_id, dtype=torch.long)
                p_mask = torch.zeros((max_chunks - n, max_chunk_length), dtype=torch.long)
                ids = torch.cat([ids, p_ids])
                mask = torch.cat([mask, p_mask])
            batch_ids.append(ids); batch_masks.append(mask); labels.append(item["labels"])
        return {"input_ids": torch.stack(batch_ids), "attention_mask": torch.stack(batch_masks), "labels": torch.stack(labels)}
    return collate_fn

def make_hat_collate(tokenizer, max_chunk_length=64, max_chunks=3):
    def _pad_chunks(chunks, mcl, mc):
        chunks = chunks[:mc]
        if chunks:
            enc = tokenizer(chunks, padding="max_length", truncation=True, max_length=mcl, return_tensors="pt")
            ids, mask = enc["input_ids"], enc["attention_mask"]
        else:
            ids = torch.full((1, mcl), tokenizer.pad_token_id, dtype=torch.long)
            mask = torch.zeros((1, mcl), dtype=torch.long)
        n = ids.size(0)
        if n < mc:
            ids = torch.cat([ids, torch.full((mc - n, mcl), tokenizer.pad_token_id, dtype=torch.long)])
            mask = torch.cat([mask, torch.zeros((mc - n, mcl), dtype=torch.long)])
        return ids, mask

    def collate_fn(batch):
        titles = [item["title"] for item in batch]
        abstracts = [item["abstract"] for item in batch]
        t_enc = tokenizer(titles, padding="max_length", truncation=True, max_length=64, return_tensors="pt")
        a_enc = tokenizer(abstracts, padding="max_length", truncation=True, max_length=128, return_tensors="pt")
        c_ids_l, c_mask_l, d_ids_l, d_mask_l = [], [], [], []
        labels = []
        labels_section = []
        labels_class = []
        labels_subclass = []
        
        for item in batch:
            ci, cm = _pad_chunks(item.get("claims_chunks", []), max_chunk_length, max_chunks)
            di, dm = _pad_chunks(item.get("description_chunks", []), max_chunk_length, max_chunks)
            c_ids_l.append(ci); c_mask_l.append(cm); d_ids_l.append(di); d_mask_l.append(dm)
            
            if "labels" in item:
                labels.append(item["labels"])
            if "labels_section" in item:
                labels_section.append(item["labels_section"])
                labels_class.append(item["labels_class"])
                labels_subclass.append(item["labels_subclass"])
                
        result = {
            "title_input_ids": t_enc["input_ids"], "title_attention_mask": t_enc["attention_mask"],
            "abstract_input_ids": a_enc["input_ids"], "abstract_attention_mask": a_enc["attention_mask"],
            "claims_input_ids": torch.stack(c_ids_l), "claims_attention_mask": torch.stack(c_mask_l),
            "desc_input_ids": torch.stack(d_ids_l), "desc_attention_mask": torch.stack(d_mask_l),
        }
        
        if labels:
            result["labels"] = torch.stack(labels)
        if labels_section:
            result["labels_section"] = torch.stack(labels_section)
            result["labels_class"] = torch.stack(labels_class)
            result["labels_subclass"] = torch.stack(labels_subclass)
            
        return result
    return collate_fn

# ── Main ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Unified PatentClass-HAT Training")
    parser.add_argument("--model_type", type=str, default="flat", choices=["flat", "longdoc", "hat"])
    parser.add_argument("--model_name", type=str, default="prajjwal1/bert-tiny")
    parser.add_argument("--dataset", type=str, default="hupd", choices=["real", "hupd"], help="Dataset to use")
    parser.add_argument("--loss", type=str, default="bce", choices=["bce", "focal", "asymmetric"], help="Loss function")
    parser.add_argument("--hierarchical", action="store_true", help="Use Hierarchical Classifier cascade")
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=5e-5)
    parser.add_argument("--patience", type=int, default=3, help="Early stopping patience")
    parser.add_argument("--num_samples", type=int, default=64, help="Mock dataset size (if dataset=mock)")
    args = parser.parse_args()

    setup_logging(level="INFO")
    logger.info(f"=== Training: model_type={args.model_type}, dataset={args.dataset}, loss={args.loss}, epochs={args.epochs}, hierarchical={args.hierarchical} ===")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Data
    if args.dataset == "real":
        train_ds, val_ds, test_ds = load_real_dataset()
    elif args.dataset == "hupd":
        from src.data.load_hupd import load_hupd_stream
        logger.info("Connecting to Hugging Face to stream real HUPD dataset...")
        train_ds = load_hupd_stream("HUPD/hupd", split="train", name="sample")
        val_ds = load_hupd_stream("HUPD/hupd", split="validation", name="sample")

    if args.hierarchical:
        from src.preprocessing.hierarchical_encoder import HierarchicalCPCLabelEncoder
        encoder = HierarchicalCPCLabelEncoder(min_frequency=1)
        
        # We need to fit the encoder. For streaming datasets, we pull a small sample to build the vocabulary.
        logger.info("Fitting encoder on a sample of the training data...")
        sample_labels = []
        for i, row in enumerate(train_ds):
            sample_labels.append(row["cpc_label"])
            if i >= 1000:  # Fit on first 1000 examples
                break
        encoder.fit(sample_labels)
        
        num_labels = None
        hierarchical_dims = {
            "num_sections": len(encoder.encoders["section"].vocab),
            "num_classes": len(encoder.encoders["class"].vocab),
            "num_subclasses": len(encoder.encoders["subclass"].vocab),
        }
    else:
        encoder = CPCLabelEncoder(min_frequency=1, primary_level="subclass")
        
        logger.info("Fitting encoder on a sample of the training data...")
        sample_labels = []
        for i, row in enumerate(train_ds):
            sample_labels.append(row["cpc_label"])
            if i >= 1000:
                break
        encoder.fit(sample_labels)
        
        num_labels = len(encoder.vocab)
        hierarchical_dims = None

    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    chunker = Chunker(max_length=64, overlap=8, use_words=True)

    class HFIter:
        def __init__(self, ds): self.ds = ds
        def __iter__(self):
            for r in self.ds: yield r

    train_pds = PatentDataset(HFIter(train_ds), "hupd", encoder, chunker=chunker)
    val_pds = PatentDataset(HFIter(val_ds), "hupd", encoder, chunker=chunker)

    # Initialize loss
    from src.training.losses import FocalLoss, AsymmetricLoss
    if args.loss == "focal":
        loss_fn = FocalLoss()
    elif args.loss == "asymmetric":
        loss_fn = AsymmetricLoss()
    else:
        loss_fn = None

    # Model & collate
    if args.model_type == "flat":
        model = FlatTransformerBaseline(args.model_name, num_labels, loss_fn=loss_fn)
        collate_fn = make_flat_collate(tokenizer)
    elif args.model_type == "longdoc":
        model = LongDocTransformer(args.model_name, num_labels, pooling_strategy="mean", loss_fn=loss_fn)
        collate_fn = make_longdoc_collate(tokenizer)
    elif args.model_type == "hat":
        ctype = "hierarchical" if args.hierarchical else "flat"
        model = PatentClassHAT(args.model_name, num_labels=num_labels, hierarchical_dims=hierarchical_dims, chunk_pooling="mean", loss_fn=loss_fn, classifier_type=ctype)
        collate_fn = make_hat_collate(tokenizer)

    train_loader = DataLoader(train_pds, batch_size=args.batch_size, collate_fn=collate_fn)
    val_loader = DataLoader(val_pds, batch_size=args.batch_size, collate_fn=collate_fn)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    trainer = Trainer(model=model, optimizer=optimizer, device=device, metrics_fn=compute_multilabel_metrics)

    exp_logger = ExperimentLogger(experiment_name=f"patentclass_{args.model_type}_{args.loss}")
    exp_logger.log_hyperparameters({
        "model_type": args.model_type, "model_name": args.model_name, "dataset": args.dataset, "loss": args.loss,
        "epochs": args.epochs, "batch_size": args.batch_size, "lr": args.lr,
        "num_labels": num_labels
    })

    # Training loop with early stopping
    best_val_loss = float("inf")
    patience_counter = 0
    ckpt_dir = _PROJECT_ROOT / "experiments" / "checkpoints"

    for epoch in range(1, args.epochs + 1):
        # Re-create iterators for each epoch (IterableDataset)
        train_pds_epoch = PatentDataset(HFIter(train_ds), "hupd", encoder, chunker=chunker)
        val_pds_epoch = PatentDataset(HFIter(val_ds), "hupd", encoder, chunker=chunker)
        train_loader = DataLoader(train_pds_epoch, batch_size=args.batch_size, collate_fn=collate_fn)
        val_loader = DataLoader(val_pds_epoch, batch_size=args.batch_size, collate_fn=collate_fn)

        train_loss = trainer.train_epoch(train_loader)
        val_metrics = trainer.evaluate(val_loader)

        logger.info(f"Epoch {epoch}/{args.epochs} — Train Loss: {train_loss:.4f} | Val: {val_metrics}")
        exp_logger.log_epoch(epoch, train_loss, val_metrics)

        # Checkpointing
        val_loss = val_metrics.get("val_loss", float("inf"))
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            save_checkpoint(model, optimizer, epoch, val_metrics,
                            str(ckpt_dir / f"{args.model_type}_best.pt"))
        else:
            patience_counter += 1
            if patience_counter >= args.patience:
                logger.info(f"Early stopping triggered at epoch {epoch}.")
                break

    exp_logger.log_final(val_metrics)
    logger.info("Training complete.")

if __name__ == "__main__":
    main()
