#!/usr/bin/env python3
"""Run Hierarchical Long-Document Transformer on a simulated dataset."""
import sys
import logging
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from transformers import AutoTokenizer

# Ensure src is importable
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logging_utils import setup_logging
from src.preprocessing import CPCLabelEncoder, Chunker
from src.data.dataset import PatentDataset
from src.models import LongDocTransformer
from src.training import Trainer
from src.evaluation import compute_multilabel_metrics
from datasets import Dataset

logger = logging.getLogger(__name__)

from src.data.load_dataset import load_real_dataset

def main():
    setup_logging(level="INFO")
    logger.info("Starting Hierarchical Long-Document Transformer Execution...")
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Using device: {device}")
    
    # 1. Load Data
    train_ds, val_ds, test_ds = load_real_dataset()
    
    # 2. Fit Label Encoder
    encoder = CPCLabelEncoder(min_frequency=1, primary_level="subclass")
    encoder.fit([row["cpc_label"] for row in train_ds])
    
    # 3. Initialize Tokenizer & Model
    model_name = "prajjwal1/bert-tiny" 
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    
    # We use a smaller chunk size to simulate multi-chunk documents easily with few words
    max_chunk_length = 64
    max_chunks = 4
    chunker = Chunker(max_length=max_chunk_length, overlap=8, use_words=True)
    
    model = LongDocTransformer(
        model_name=model_name, 
        num_labels=len(encoder.vocab),
        pooling_strategy="mean"
    )
    
    # 4. Create Unified Datasets
    class HFListIter:
        def __init__(self, ds): self.ds = ds
        def __iter__(self):
            for r in self.ds: yield r
                
    train_patent_ds = PatentDataset(HFListIter(train_ds), "hupd", encoder, chunker=chunker)
    val_patent_ds = PatentDataset(HFListIter(val_ds), "hupd", encoder, chunker=chunker)
    
    def collate_fn(batch):
        # We need to construct tensors of shape (batch_size, max_chunks, max_chunk_length)
        batch_input_ids = []
        batch_attention_mask = []
        labels = []
        
        for item in batch:
            # item has 'description_chunks', etc.
            # Combine all chunks from all sections for this test
            all_chunks = item.get("title_chunks", []) + item.get("abstract_chunks", []) + \
                         item.get("claims_chunks", []) + item.get("description_chunks", [])
            
            # Truncate to max_chunks
            all_chunks = all_chunks[:max_chunks]
            
            # Tokenize all chunks for this document
            if len(all_chunks) > 0:
                encodings = tokenizer(
                    all_chunks, padding="max_length", truncation=True, 
                    max_length=max_chunk_length, return_tensors="pt"
                )
                doc_input_ids = encodings["input_ids"]
                doc_attention_mask = encodings["attention_mask"]
            else:
                doc_input_ids = torch.zeros((1, max_chunk_length), dtype=torch.long)
                doc_attention_mask = torch.zeros((1, max_chunk_length), dtype=torch.long)
                
            # Pad the number of chunks to max_chunks
            num_chunks = doc_input_ids.size(0)
            if num_chunks < max_chunks:
                pad_input = torch.zeros((max_chunks - num_chunks, max_chunk_length), dtype=torch.long)
                pad_mask = torch.zeros((max_chunks - num_chunks, max_chunk_length), dtype=torch.long)
                # For input_ids, pad token is usually 0 (or tokenizer.pad_token_id)
                pad_input.fill_(tokenizer.pad_token_id)
                
                doc_input_ids = torch.cat([doc_input_ids, pad_input], dim=0)
                doc_attention_mask = torch.cat([doc_attention_mask, pad_mask], dim=0)
                
            batch_input_ids.append(doc_input_ids)
            batch_attention_mask.append(doc_attention_mask)
            labels.append(item["labels"])
            
        return {
            "input_ids": torch.stack(batch_input_ids),
            "attention_mask": torch.stack(batch_attention_mask),
            "labels": torch.stack(labels)
        }
        
    train_loader = DataLoader(train_patent_ds, batch_size=4, collate_fn=collate_fn)
    val_loader = DataLoader(val_patent_ds, batch_size=4, collate_fn=collate_fn)
    
    # 5. Train Model
    optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
    trainer = Trainer(
        model=model,
        optimizer=optimizer,
        device=device,
        metrics_fn=compute_multilabel_metrics
    )
    
    logger.info("Training 1 epoch for verification...")
    train_loss = trainer.train_epoch(train_loader)
    logger.info(f"Epoch 1 - Train Loss: {train_loss:.4f}")
    
    logger.info("Evaluating...")
    val_metrics = trainer.evaluate(val_loader)
    logger.info(f"Validation Metrics: {val_metrics}")
    
    logger.info("Hierarchical Long-Document Transformer flow completed successfully.")

if __name__ == "__main__":
    main()
