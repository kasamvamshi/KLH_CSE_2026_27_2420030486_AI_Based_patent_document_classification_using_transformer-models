#!/usr/bin/env python3
"""Run Transformer Baseline on a simulated dataset."""
import sys
import logging
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from transformers import AutoTokenizer

# Ensure src is importable
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logging_utils import setup_logging
from src.preprocessing import CPCLabelEncoder
from src.data.dataset import PatentDataset
from src.models import FlatTransformerBaseline
from src.training import Trainer
from src.evaluation import compute_multilabel_metrics
from datasets import Dataset

logger = logging.getLogger(__name__)

from src.data.load_dataset import load_real_dataset

def main():
    setup_logging(level="INFO")
    logger.info("Starting Transformer Baseline Execution...")
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Using device: {device}")
    
    # 1. Load Data (Real Dataset)
    train_ds, val_ds, test_ds = load_real_dataset()
    
    # 2. Fit Label Encoder
    encoder = CPCLabelEncoder(min_frequency=1, primary_level="subclass")
    encoder.fit([row["cpc_label"] for row in train_ds])
    
    # 3. Initialize Tokenizer & Model
    # Using a tiny model for fast testing
    model_name = "prajjwal1/bert-tiny" 
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = FlatTransformerBaseline(model_name, num_labels=len(encoder.vocab))
    
    # 4. Create Unified Datasets
    class HFListIter:
        def __init__(self, ds): self.ds = ds
        def __iter__(self):
            for r in self.ds: yield r
                
    train_patent_ds = PatentDataset(HFListIter(train_ds), "hupd", encoder, chunker=None)
    val_patent_ds = PatentDataset(HFListIter(val_ds), "hupd", encoder, chunker=None)
    
    # Custom collate function to handle tokenization
    def collate_fn(batch):
        # Flatten patent text (title + abstract + claims + description)
        texts = []
        labels = []
        for item in batch:
            text = f"{item['title']} {item['abstract']} {item['claims']} {item['description']}"
            texts.append(text.strip())
            labels.append(item["labels"])
            
        encodings = tokenizer(
            texts, padding=True, truncation=True, max_length=512, return_tensors="pt"
        )
        
        return {
            "input_ids": encodings["input_ids"],
            "attention_mask": encodings["attention_mask"],
            "labels": torch.stack(labels)
        }
        
    train_loader = DataLoader(train_patent_ds, batch_size=8, collate_fn=collate_fn)
    val_loader = DataLoader(val_patent_ds, batch_size=8, collate_fn=collate_fn)
    
    # 5. Train Model
    optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
    trainer = Trainer(
        model=model,
        optimizer=optimizer,
        device=device,
        metrics_fn=compute_multilabel_metrics
    )
    
    logger.info("Training 1 epoch for verification...")
    train_loss = trainer.train_epoch(train_loader)
    logger.info(f"Epoch 1 - Train Loss: {train_loss:.4f}")
    
    logger.info("Evaluating...")
    val_metrics = trainer.evaluate(val_loader)
    logger.info(f"Validation Metrics: {val_metrics}")
    
    logger.info("Transformer Baseline flow completed successfully.")

if __name__ == "__main__":
    main()
