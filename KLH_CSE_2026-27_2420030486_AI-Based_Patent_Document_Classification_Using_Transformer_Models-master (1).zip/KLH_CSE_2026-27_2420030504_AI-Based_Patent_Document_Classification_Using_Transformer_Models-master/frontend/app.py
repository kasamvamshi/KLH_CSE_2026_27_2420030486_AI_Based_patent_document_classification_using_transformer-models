import streamlit as st
import requests
import pandas as pd
import altair as alt
import json

st.set_page_config(
    page_title="PatentClass-HAT: Explainable Patent Classification",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("PatentClass-HAT 🔬")
st.subheader("Hierarchical Attention Transformer for Explainable Patent Classification")

API_URL = "http://127.0.0.1:8000/predict"

with st.sidebar:
    st.header("Model Settings")
    st.write("Ensure the FastAPI backend is running at `http://127.0.0.1:8000`")
    api_endpoint = st.text_input("API Endpoint", value=API_URL)
    
    st.markdown("---")
    st.info("""
    **How it works:**
    Paste the text of a patent document divided into its core sections.
    The model will chunk the long sections, compute section-aware representations,
    fuse them using self-attention, and generate hierarchical CPC labels.
    """)

# Input form
with st.form("patent_form"):
    st.markdown("### Document Sections")
    col1, col2 = st.columns(2)
    
    with col1:
        title = st.text_input("Title", value="An Artificial Intelligence system for Data Parsing")
        abstract = st.text_area("Abstract", value="A neural network architecture to parse patent documents using NLP.", height=150)
        
    with col2:
        claims = st.text_area("Claims", value="1. A method comprising tokenizing strings. 2. A method of claim 1 where...", height=150)
        
    description = st.text_area("Description", value="The detailed description goes here. It explains everything in depth.", height=200)
    
    submitted = st.form_submit_button("Classify Patent")

if submitted:
    payload = {
        "title": title,
        "abstract": abstract,
        "claims": claims,
        "description": description
    }
    
    with st.spinner("Analyzing document..."):
        try:
            response = requests.post(api_endpoint, json=payload, timeout=30)
            if response.status_code == 200:
                data = response.json()
                
                st.success("Classification successful!")
                
                # --- VISUALIZE PREDICTIONS ---
                st.markdown("---")
                st.header("Hierarchical Predictions")
                
                pred_col1, pred_col2, pred_col3 = st.columns(3)
                
                def render_metric(col, title, preds):
                    col.subheader(title)
                    if not preds:
                        col.write("No confident predictions.")
                    for p in preds:
                        score = p['score']
                        # Color coding based on confidence
                        color = "green" if score > 0.5 else "orange" if score > 0.3 else "red"
                        col.markdown(f"**{p['label']}** : :{color}[{score:.2%}]")
                
                render_metric(pred_col1, "Section", data["predictions"]["section"])
                render_metric(pred_col2, "Class", data["predictions"]["class"])
                render_metric(pred_col3, "Subclass", data["predictions"]["subclass"])
                
                # --- VISUALIZE ATTENTION ---
                st.markdown("---")
                st.header("Explainability: Section-Aware Attention")
                st.write("Which sections did the model focus on when reading a specific part of the document?")
                
                attn = data.get("attention_weights", {})
                if attn:
                    # Convert to DataFrame for Altair
                    records = []
                    for query_sec, targets in attn.items():
                        for target_sec, score in targets.items():
                            records.append({
                                "Query": query_sec,
                                "Target": target_sec,
                                "Attention Score": score
                            })
                    df_attn = pd.DataFrame(records)
                    
                    # Create Heatmap
                    heatmap = alt.Chart(df_attn).mark_rect().encode(
                        x=alt.X("Target:O", title="Attended Section (Target)"),
                        y=alt.Y("Query:O", title="Reading Section (Query)"),
                        color=alt.Color("Attention Score:Q", scale=alt.Scale(scheme="blues")),
                        tooltip=["Query", "Target", "Attention Score"]
                    ).properties(
                        width=600,
                        height=400
                    )
                    
                    # Add text labels on the heatmap
                    text = heatmap.mark_text(baseline='middle').encode(
                        text=alt.Text('Attention Score:Q', format='.2f'),
                        color=alt.condition(
                            alt.datum['Attention Score'] > 0.5,
                            alt.value('white'),
                            alt.value('black')
                        )
                    )
                    
                    st.altair_chart(heatmap + text, use_container_width=True)
                else:
                    st.warning("No attention weights were returned by the model.")
                    
            else:
                st.error(f"Error from API: {response.status_code}")
                st.json(response.text)
                
        except requests.exceptions.ConnectionError:
            st.error("Could not connect to the API. Is FastAPI running on 127.0.0.1:8000?")
        except Exception as e:
            st.error(f"An error occurred: {str(e)}")
